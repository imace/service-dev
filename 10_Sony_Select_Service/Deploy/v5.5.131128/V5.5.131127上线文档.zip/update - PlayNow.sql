/* ���¶�̬���ݼ��ϰ����͸����б� -- By Zhang Bo */
USE [PlayNow]
GO
/****** Object:  StoredProcedure [dbo].[SP_UpdateAppLatestLoop]    Script Date: 09/30/2013 14:44:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        <Author,,Name>
-- Create date: <Create Date,,>
-- Description:   ��ʱ���±�[dbo.PN_AppLatestLoop]
-- =============================================
ALTER PROCEDURE [dbo].[SP_UpdateAppLatestLoop]
      -- Add the parameters for the stored procedure here
      @BeginTime Datetime, 
      @EndTime Datetime
AS
BEGIN
      -- SET NOCOUNT ON added to prevent extra result sets from
      -- interfering with SELECT statements.
      SET NOCOUNT ON;

declare MachinesCursor cursor for
        select Id, Type from [dbo].[PN_Machine]
open MachinesCursor

declare @MachineId int
declare @MachineType nvarchar(50)    

declare @AppLatestLoopCountByMachine int

fetch next from MachinesCursor into @MachineId, @MachineType
while @@fetch_status=0
begin
    set @AppLatestLoopCountByMachine = (select COUNT(APPID) from [dbo].[PN_AppPublish] as AppPub left join [dbo].[PN_AppInfo] as AppInfo
                                            on AppPub.AppId = AppInfo.ID where
                                               AppPub.UpdateTime>=@BeginTime AND
                                               AppPub.UpdateTime<@EndTime AND
                                               (AppInfo.MachineTypes LIKE '%' + @MachineType + ';%' OR AppInfo.MachineTypes LIKE '%' + @MachineType))                                   


    /* ���ĳ�����ڶ�Ӧʱ����û�и���Ӧ�ý�����������һ�εĶ�̬���ݼ�������*/
    if (@AppLatestLoopCountByMachine > 0)
    begin
        /* �������ɱ�ǰɾ�����ж�Ӧ���Ͷ�Ӧʱ��Ķ�̬���ݼ�������*/
        delete from dbo.PN_AppLatestLoop where MachineType = @MachineId
                                   

        /* �������ݵ�PN_AppLatestLoop */
        insert into dbo.PN_AppLatestLoop(
               AppID, AppType, MachineType, OrderTime)
                       /* �����޶�������PN_AppPublish��PN_AppInfo�в�ѯ����Ӧ����Ϣ�ͻ���*/
                       select AppPub.APPID, AppInfo.Type,@MachineId, AppPub.UpdateTime from
                         [dbo].[PN_AppPublish] as AppPub left join [dbo].[PN_AppInfo] as AppInfo on
                             AppPub.APPID=AppInfo.Id where
                                   AppPub.UpdateTime>=@BeginTime AND
                                   AppPub.UpdateTime<@EndTime AND
                                   (MachineTypes LIKE '%' + @MachineType + ';%' OR MachineTypes LIKE '%' + @MachineType)
                   
    end
    
    fetch next from MachinesCursor into @MachineId, @MachineType
    
end

close MachinesCursor
deallocate MachinesCursor

END