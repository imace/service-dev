﻿USE [PlayNowLog]
GO

/**start For CR00034 by Wei,Devin**/
/**start add table PN_Log_Banner by Wei,Devin**/
if exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Log_Banner')
drop table PN_Log_Banner
GO

/****** 对象:  Table [dbo].[PN_Log_Banner]    脚本日期: 10/13/2014 16:58:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PN_Log_Banner](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IMSI] [nvarchar](20) NULL,
	[IMEI] [nvarchar](50) NULL,
	[AndroidVer] [nvarchar](20) NULL,
	[EdreamVer] [nvarchar](50) NULL,
	[ClientVer] [nvarchar](20) NULL,
	[ContentId] [int] NULL,
	[ContentName] [nvarchar](200) NULL,
	[Type] [int] NULL,
	[IsOpened] [int] NULL,
	[CreateTime] [datetime] NULL
 CONSTRAINT [PK_PN_LOG_BANNER] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX IX_CREATE_TIME_PN_LOG_BANNER ON [dbo].[PN_Log_Banner] ([CreateTime])
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'国际移动用户识别码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'IMSI'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'国际移动电话设备识别码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'IMEI'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Android版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'AndroidVer'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Edream平台版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'EdreamVer'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'客户端版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'ClientVer'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容Id，包括：应用Id，专区Id，广告Id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'ContentId'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容名称，包括：应用名称、专区名称、广告名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'ContentName'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'类型,1.应用 2.专区3.广告' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'Type'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Banner位内容是否成功打开（应用详情页面是否成功打开、专区是否成功打开、广告链接是否成功打开)0：不成功1：成功' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'IsOpened'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_Banner', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO
/**end add table PN_Log_Banner by Wei,Devin**/

/**start add table PN_S_Banner by Hu Jingzhi **/
if exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_S_Banner')
drop table PN_S_Banner
GO

/****** Object:  Table [dbo].[PN_S_Banner]    Script Date: 10/16/2014 10:11:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PN_S_Banner](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NULL,
	[ContentName] [nvarchar](200) NULL,
	[ContentType] [int] NULL,
	[HitCount] [int] NULL,
	[OpenCount] [int] NULL,
	[DownCount] [int] NULL,
	[DownCompleteCount] [int] NULL,
	[InstallCount] [int] NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_S_Banner] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容Id，包括：应用Id，专区Id，广告Id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'ContentId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容名称，包括：应用名称、专区名称、广告名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'ContentName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容类型,1.应用 2.专区3.广告' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'ContentType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'点击量' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'HitCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'成功跳转次数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'OpenCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载量' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'DownCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载完成量' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'DownCompleteCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'安装量' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'InstallCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Banner', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

/**end add table PN_S_Banner by Hu Jingzhi **/

/** start For update table PN_Order by Hu Jingzhi **/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Order'))
begin

ALTER TABLE [dbo].[PN_Order]
ADD [Location] [nvarchar](50)

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Location用于标识下载来自页面的具体位置（值为banner表示下载来自页面的banner位置）。' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Order', @level2type=N'COLUMN',@level2name=N'Location'

end
GO
/** end For update table PN_Order by Hu Jingzhi **/

/**start For add Procedure SP_BannerStatistic by Hu Jingzhi **/
if exists(SELECT * FROM INFORMATION_SCHEMA.ROUTINES where ROUTINE_TYPE = 'PROCEDURE' AND ROUTINE_NAME = 'SP_BannerStatistic')
DROP PROCEDURE SP_BannerStatistic
GO

/****** Object:  StoredProcedure [dbo].[SP_BannerStatistic]    Script Date: 10/16/2014 10:33:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: Banner分析，其中在做分析插入之前要做一次删除
-- =============================================
CREATE PROCEDURE [dbo].[SP_BannerStatistic]
 -- Add the parameters for the stored procedure here
 @BeginTime Datetime,
 @EndTime Datetime
AS
BEGIN
 -- SET NOCOUNT ON added to prevent extra result sets from
 -- interfering with SELECT statements.
 SET NOCOUNT ON;
--2013/4/18 Rui 为了保证向下兼容sqlserver 2005, 修改此文件想查看其中变化, 使用文件比较工具与脚本进行对比
-- 变化包括, 变量的定义, 日期的转换日期类型变为datetime, 并全部转换为零点
--declare @errorCount int=0 --错误的累加
declare @errorCount int
set @errorCount=0

begin  tran --开始事务

--declare @BeginTime datetime
--declare @EndTime datetime
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as datetime)) --结束时间

-- 分析前先删除某一时间段的数据
delete from  dbo.PN_S_Banner where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- Banner 分析
insert into dbo.PN_S_Banner(
	[ContentId], [ContentName], [ContentType],
	[HitCount],	[OpenCount],
	[DownCount], [DownCompleteCount], [InstallCount],
	[CreateTime]
)

SELECT

PB.ContentId AS ContentId, max(PB.ContentName) AS ContentName, PB.Type AS ContentType,
SUM(CASE WHEN (PB.IsOpened is null) THEN 1 ELSE 0 END) 点击量,
SUM(CASE WHEN (PB.IsOpened = 1) THEN 1 ELSE 0 END) 跳转成功次数,
(
  select COUNT(*) from [PN_Order] as PO1
  where PB.Type = 1 and cast(PB.ContentId as nvarchar(100))=PO1.AppId and PO1.Location = 'banner' and
  PO1.StartTime >= @BeginTime and PO1.StartTime < @EndTime
)as DownCount,
(
  select COUNT(*) from [PN_Order] as PO2
  where PB.Type = 1 and cast(PB.ContentId as nvarchar(100))=PO2.AppId and PO2.Location = 'banner' and
  PO2.StartTime >= @BeginTime and PO2.StartTime < @EndTime
  and PO2.EndTime is not null
) as DownCompleteCount,
(
  select COUNT(*) from [PN_Order] as PO3
  where PB.Type = 1 and cast(PB.ContentId as nvarchar(100))=PO3.AppId and PO3.Location = 'banner' and
  PO3.InstallTime >= @BeginTime and PO3.InstallTime < @EndTime
  and PO3.IsInstalled = 1
 ) as InstallCount,
--cast(DateTime as date )
cast( convert(varchar(10),CreateTime,120)as datetime)
from dbo.PN_Log_Banner AS PB
where PB.CreateTime>=@BeginTime and  PB.CreateTime<@EndTime
Group by cast( convert(varchar(10), PB.CreateTime,120)as datetime), PB.ContentId, PB.Type

SET @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

 begin

  rollback --如果有错，就回滚事务

 end

else

 begin

  commit tran --如果没有错，就提交事务

 end

END
GO
/**end For add Procedure SP_BannerStatistic by Hu Jingzhi **/

/**end For CR00034  by Wei,Devin**/
/**start For CR00047 by Wei,Devin**/
/**start update table  PN_S_UpdateInfo by Wei,Devin**/

IF EXISTS(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PN_S_UpdateInfo' and COLUMN_NAME = 'ClientVer')
BEGIN
exec sp_rename 'PN_S_UpdateInfo.ClientVer','EdreamVer','column';
alter table PN_S_UpdateInfo alter column  EdreamVer nvarchar(50)
END
GO

IF NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PN_S_UpdateInfo' and COLUMN_NAME = 'ClientVer')
alter table PN_S_UpdateInfo add  ClientVer nvarchar(20) null
GO
/**end update table  PN_S_UpdateInfo by Wei,Devin**/

/**start  update procedure  SP_UpdateInfoStatistic by Wei,Devin**/
/****** 对象:  StoredProcedure [dbo].[SP_UpdateInfoStatistic]    脚本日期: 09/15/2014 04:40:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	升级信息统计 分析 其中在做分析插入之前要做一次删除
-- =============================================
ALTER PROCEDURE [dbo].[SP_UpdateInfoStatistic]
	-- Add the parameters for the stored procedure here
	@BeginTime Datetime, 
	@EndTime Datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



--declare @errorCount int=0 --错误的累加
--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点

declare @errorCount int 
set @errorCount=0 


begin  tran --开始事务


--set @BeginTime=CAST(@BeginTime as date) --开始时间
--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间



-- 分析前先删除 某一时间段的数据
delete from  dbo.PN_S_UpdateInfo where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- 升级信息统计 分析
	insert into dbo.PN_S_UpdateInfo(
	MachineType,EdreamVer, ClientVer, Distribute, CreateTime
	)

	select MachineType,EdreamVer,C.ClientVer,COUNT(IMSI) IMSICount,C.Gdate
	from ( 
			SELECT distinct IMSI, cast( convert(varchar(10),CreateTime,120)as datetime) as Gdate,EdreamVer,ClientVer ,MachineType 
			FROM PN_Log_Message  as A 
			where  CreateTime>=@BeginTime  AND CreateTime<@EndTime
		) AS C group by C.Gdate,EdreamVer,C.ClientVer,MachineType     

set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

	begin

		rollback --如果有错，就回滚事务

	end

else

	begin

		commit tran --如果没有错，就提交事务

	
	end

END
GO
/**end  update procedure  SP_UpdateInfoStatistic by Wei,Devin**/
/**end For CR00047 by Wei,Devin**/