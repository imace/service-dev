﻿USE [PlayNow]
GO

/**start rollback For CR00047 by Wei,Devin**/
/**start delete data from table  PN_Module by Wei,Devin**/

delete from PN_Module where MenuId = 3 and ModuleName = 'SonySelect版本统计' and ModulePath = 'Statistic/ClientVersionStats.aspx'

/**end delete data from table  PN_Module by Wei,Devin**/
/**end rollback For CR00047 by Wei,Devin**/

/**start delete data from table  PN_Module by Hu Jingzhi **/

delete from PN_Module where MenuId = 3 and ModuleName = 'Banner位统计' and ModulePath = 'Statistic/Banner.aspx'

/**end delete data from table  PN_Module by Hu Jingzhi **/

/** start rollback For update table PN_Message by Hu Jingzhi **/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Message'))
begin

ALTER TABLE PN_Message
DROP CONSTRAINT DF_PN_Message_TimeSpanStart,DF_PN_Message_TimeSpanEnd,DF_PN_Message_Priority,DF_PN_Message_IsRefusable

ALTER TABLE PN_Message
DROP COLUMN	TimeSpanStart, TimeSpanEnd, Priority, IsRefusable

end
/** end rollback For update table PN_Message by Hu Jingzhi **/