﻿USE [PlayNow]
GO

/** start For update table PN_Message by Hu Jingzhi **/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Message'))
begin

ALTER TABLE [dbo].[PN_Message]
ADD TimeSpanStart datetime, TimeSpanEnd datetime, Priority int, IsRefusable bit

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'定时发送时间段的开始时间(00:00 - 23:59)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Message', @level2type=N'COLUMN',@level2name=N'TimeSpanStart'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'定时发送时间段的结束时间(00:00 - 23:59)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Message', @level2type=N'COLUMN',@level2name=N'TimeSpanEnd'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'发送权重等级（1-10），1为最低优先级' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Message', @level2type=N'COLUMN',@level2name=N'Priority'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'客户端是否可以拒收该消息。1（true），可以拒收；0（false），不可以拒收。' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Message', @level2type=N'COLUMN',@level2name=N'IsRefusable'

ALTER TABLE [dbo].[PN_Message] ADD  CONSTRAINT [DF_PN_Message_TimeSpanStart]  DEFAULT ('00:00') FOR [TimeSpanStart]

ALTER TABLE [dbo].[PN_Message] ADD  CONSTRAINT [DF_PN_Message_TimeSpanEnd]  DEFAULT ('23:59') FOR [TimeSpanEnd]

ALTER TABLE [dbo].[PN_Message] ADD  CONSTRAINT [DF_PN_Message_Priority]  DEFAULT ((1)) FOR [Priority]

ALTER TABLE [dbo].[PN_Message] ADD  CONSTRAINT [DF_PN_Message_IsRefusable]  DEFAULT ((1)) FOR [IsRefusable]

end
/** end For update table PN_Message by Hu Jingzhi **/	

/**start insert data to table  PN_Module by Hu Jingzhi **/

insert into [PlayNow].[dbo].[PN_Module] (MenuId,ModuleName,ModulePath) values(3,'Banner位统计','Statistic/Banner.aspx')

/**end insert data to table  PN_Module by Hu Jingzhi **/
/**start For CR00047 by Wei,Devin**/
/**start insert data to table  PN_Module by Wei,Devin**/

insert into PN_Module(MenuId,ModuleName,ModulePath) values(3,'SonySelect版本统计','Statistic/ClientVersionStats.aspx')

/**end insert data to table  PN_Module by Wei,Devin**/
/**end For CR00047 by Wei,Devin**/