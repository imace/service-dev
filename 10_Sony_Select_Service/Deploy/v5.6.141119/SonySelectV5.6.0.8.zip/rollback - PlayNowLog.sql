﻿USE [PlayNowLog]
GO

/**start rollback For CR00047 by Wei,Devin**/
/**start rollback update table  PN_S_UpdateInfo by Wei,Devin**/

IF EXISTS(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PN_S_UpdateInfo' and COLUMN_NAME = 'ClientVer')
BEGIN
IF  EXISTS(SELECT * FROM PN_S_UpdateInfo WHERE ClientVer IS  NULL)
ALTER TABLE PN_S_UpdateInfo DROP COLUMN ClientVer
END
IF EXISTS(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PN_S_UpdateInfo' and COLUMN_NAME = 'EdreamVer')
BEGIN
exec sp_rename 'PN_S_UpdateInfo.EdreamVer','ClientVer','column';
alter table PN_S_UpdateInfo alter column  ClientVer nvarchar(50)
END
GO
/**end rollback update table  PN_S_UpdateInfo by Wei,Devin**/
/**start rollback update procedure  SP_UpdateInfoStatistic by Wei,Devin**/
/****** 对象:  StoredProcedure [dbo].[SP_UpdateInfoStatistic]    脚本日期: 09/15/2014 04:40:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	升级信息统计 分析 其中在做分析插入之前要做一次删除
-- =============================================
ALTER PROCEDURE [dbo].[SP_UpdateInfoStatistic]
	-- Add the parameters for the stored procedure here
	@BeginTime Datetime, 
	@EndTime Datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



--declare @errorCount int=0 --错误的累加
--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点

declare @errorCount int 
set @errorCount=0 


begin  tran --开始事务


--set @BeginTime=CAST(@BeginTime as date) --开始时间
--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间



-- 分析前先删除 某一时间段的数据
delete from  dbo.PN_S_UpdateInfo where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- 升级信息统计 分析
	insert into dbo.PN_S_UpdateInfo(
	MachineType, ClientVer, Distribute, CreateTime
	)

	select MachineType,C.ClientVer,COUNT(IMSI) IMSICount,C.Gdate
	from ( 

			--SELECT IMSI, CAST(AddTime as Date) as Gdate,ClientVer ,MachineType 
			
			SELECT IMSI, cast( convert(varchar(10),AddTime,120)as datetime) as Gdate,ClientVer ,MachineType 
			
			FROM PN_Log_UpdateInfo  as A 
			
			where  AddTime>=@BeginTime  AND AddTime<@EndTime

			--group by CAST(AddTime as Date),IMSI,ClientVer,MachineType
			group by cast( convert(varchar(10),AddTime,120)as datetime),IMSI,ClientVer,MachineType
	    
		) AS C group by C.Gdate,C.ClientVer,MachineType    


set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

	begin

		rollback --如果有错，就回滚事务

	end

else

	begin

		commit tran --如果没有错，就提交事务

	
	end

END
GO
/**end rollback update procedure  SP_UpdateInfoStatistic by Wei,Devin**/
/**end rollback For CR00047 by Wei,Devin**/

/**start rollback For CR00034 by Wei,Devin**/

/**start rollback add Procedure SP_BannerStatistic by Hu Jingzhi **/
if exists(SELECT * FROM INFORMATION_SCHEMA.ROUTINES where ROUTINE_TYPE = 'PROCEDURE' AND ROUTINE_NAME = 'SP_BannerStatistic')
DROP PROCEDURE SP_BannerStatistic
GO
/**end rollback add Procedure SP_BannerStatistic by Hu Jingzhi **/

/** start rollback For update table PN_Order by Hu Jingzhi **/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Order'))
begin

ALTER TABLE PN_Order
DROP COLUMN Location

end
/** end rollback For update table PN_Order by Hu Jingzhi **/

/**start rollback add table PN_S_Banner by Hu Jingzhi **/
if exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_S_Banner')
drop table PN_S_Banner
GO
/**end rollback add table PN_S_Banner by Hu Jingzhi **/

/**start rollback add table PN_Log_Banner by Wei,Devin**/
if exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Log_Banner')
drop table PN_Log_Banner
GO
/**end rollback add table PN_Log_Banner by Wei,Devin**/
/**end rollback For CR00034  by Wei,Devin**/