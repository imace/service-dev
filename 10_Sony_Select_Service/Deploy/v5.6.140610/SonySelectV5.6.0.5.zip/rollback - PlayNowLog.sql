﻿USE [PlayNowLog]
GO

/**start For CR00029 by Wei,Devin**/
if(exists(select * from information_schema.tables where TABLE_NAME = 'V_PNL_S_AdHit_Detail' AND TABLE_TYPE = 'VIEW' ))
drop view [dbo].[V_PNL_S_AdHit_Detail]
GO 
/**end For CR00029 by Wei,Devin**/

/**start For CR00026 by Hu,Jingzhi**/
  /**start modify view  V_PN_Message**/
IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'V_PN_Message') 
   DROP View V_PN_Message 
GO
/****** Object:  View [dbo].[V_PN_Message]    Script Date: 04/24/2013 17:35:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[V_PN_Message]
AS
SELECT     Id, Title, Type, [Content], Description, MachineTypes, StartTime, EndTime
FROM         PlayNow.dbo.PN_Message
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "PN_Message (PlayNow.dbo)"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 119
               Right = 187
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'V_PN_Message'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'V_PN_Message'
GO
  /**end modify view  V_PN_Message**/
/**end For CR00026 by Hu,Jingzhi**/
/**start For CR00026 by Wei,Devin**/
	/**start rollback modify procedure  SP_MessageStatistic**/
		/****** Object:  StoredProcedure [dbo].[SP_MessageStatistic]    Script Date: 04/24/2013 17:36:58 ******/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		-- =============================================
		-- Author:		<Author,,Name>
		-- Create date: <Create Date,,>
		-- Description:	消息统计 分析 其中在做分析插入之前要做一次删除
		-- =============================================
		ALTER PROCEDURE [dbo].[SP_MessageStatistic]
			-- Add the parameters for the stored procedure here
			@BeginTime Datetime, 
			@EndTime Datetime
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;


		--declare @errorCount int=0 --错误的累加
		--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
		-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点
		--2013/7/4 jiaoxuhuan 在获取数量时添加MachineType过滤条件（例:and A.MachineType=C.MachineType）

		declare @errorCount int 
		set @errorCount=0 

		begin  tran --开始事务


		--set @BeginTime=CAST(@BeginTime as date) --开始时间
		--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
		set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
		set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间


		-- 分析前先删除 某一时间段的数据
		delete from  dbo.PN_S_Message where CreateTime>=@BeginTime and  CreateTime<@EndTime

		-- 消息统计 分析
			insert into dbo.PN_S_Message(
			 MessageID, MachineType, GetMessage,
			 ReadMessage, DownCount,  
			 DownCompleteCount, CreateTime
			)


				SELECT  MessageId, MachineType, 
						(
						select COUNT(*) from [PN_Log_Message] as A 
						 where C.MessageId=A.MessageId and IsValid=1 and   
						--CAST(A.CreateTime as date)=cast(C.CreateTime as date) ) as GetCount, 
						cast( convert(varchar(10),A.CreateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime) 
						and A.MachineType=C.MachineType
						) as GetCount, 
						(select COUNT(*) from [PN_Log_PageViewInfo] as B 

						where C.MessageId=B.ContentId AND IntentFromId=4 and

						-- CAST(B.DateTime as date)=cast(C.CreateTime as date) ) as PVCount,
						cast( convert(varchar(10),B.DateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
						and B.MachineType=C.MachineType
						 )as PVCount,
						(
						select COUNT(*) from [PN_Order] as D 

						where C.MessageId=D.ContentId and IntentFromId=4 and

						 --CAST(D.StartTime as date)=cast(C.CreateTime as date) ) as DownCount,
						 cast( convert(varchar(10),D.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
						 and D.MachineType=C.MachineType
						  )as DownCount,
						 (select COUNT(*) from [PN_Order] as G 

						   where C.MessageId=G.ContentId and IntentFromId=4 and

						  -- CAST(G.StartTime as date)=cast(C.CreateTime as date)  
							cast( convert(varchar(10),G.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
							and G.MachineType=C.MachineType
						   and EndTime is not null) as DownCompleteCount
						 
						--,CAST(CreateTime as date) dTime
						,cast( convert(varchar(10),CreateTime,120)as datetime) dTime
				FROM [PN_log_Message] as C

				where  CreateTime>=@BeginTime AND CreateTime<@EndTime    
				and MessageId>0 
				AND	IsValid=1 
				--group by CAST(CreateTime as date),MessageId,MachineType	
				  group by cast( convert(varchar(10),CreateTime,120)as datetime),MessageId,MachineType	




		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		if(@errorCount>0)

			begin

				rollback --如果有错，就回滚事务

			end

		else

			begin

				commit tran --如果没有错，就提交事务

			
			end

		END
		GO
	/**end rollback modify procedure  SP_MessageStatistic**/
	/**start rollback modify table  PN_S_Message**/
	IF ( EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_Message' AND COLUMN_NAME = 'InstallCount'))
	alter table [dbo].[PN_S_Message] drop column [InstallCount]
	GO
	/**end rollback modify table  PN_S_Message**/
/**end For CR00026 by Wei,Devin**/
	
/**start RollBack For CR00029 by Wei,Devin**/
	/**start rollback modify procedure  SP_AdHitStatistic**/
		SET ANSI_NULLS ON
		GO

		SET QUOTED_IDENTIFIER ON
		GO

		ALTER PROCEDURE [dbo].[SP_AdHitStatistic]
		 -- Add the parameters for the stored procedure here
		 @BeginTime Datetime,
		 @EndTime Datetime
		AS
		BEGIN
		 -- SET NOCOUNT ON added to prevent extra result sets from
		 -- interfering with SELECT statements.
		SET NOCOUNT ON;

		declare @errorCount int --错误的累加
		set @errorCount=0 

		begin  tran --开始事务

		-- set @BeginTime=CAST(@BeginTime as date) --开始时间
		-- set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
		set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as datetime) --开始时间
		set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as datetime)) --结束时间

		-- 分析前先删除 某一时间段的数据
		delete from  dbo.PNL_S_AdHit where CreateTime>=@BeginTime and  CreateTime<@EndTime

		-- 统计Widget的广告点击
		insert into PNL_S_AdHit(
		  AdId, AdName, IntenetFromId, AdHitCount, CreateTime
		)

		SELECT 
		AdId,
		AdName,
		'1',
		-- cast(DateTime as date ),
		sum(CASE IntenetFromId WHEN '1'     THEN 1 else 0 end),
		cast( convert(varchar(10),CreateTime,120)as datetime)

		 FROM  PNL_Log_AdHit
		WHERE CreateTime>=@BeginTime and  CreateTime<@EndTime 
		 
		 GROUP BY cast( convert(varchar(10),CreateTime,120)as datetime), AdId, AdName

		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		-- 统计Banner的广告点击
		insert into PNL_S_AdHit(
		  AdId, AdName, IntenetFromId, AdHitCount, CreateTime
		)

		SELECT 
		AdId,
		AdName,
		'2',
		-- cast(DateTime as date ),
		sum(CASE IntenetFromId WHEN '2'     THEN 1 else 0 end),
		cast( convert(varchar(10),CreateTime,120)as datetime)

		 FROM  PNL_Log_AdHit
		WHERE CreateTime>=@BeginTime and  CreateTime<@EndTime 
		 
		 GROUP BY cast( convert(varchar(10),CreateTime,120)as datetime), AdId, AdName

		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		if(@errorCount>0)

		 begin

		  rollback --如果有错，就回滚事务

		 end

		else

		 begin

		  commit tran --如果没有错，就提交事务

		 
		 end

		END
		GO
	/**end rollback modify procedure  SP_AdHitStatistic**/
	
	/**start drop table PNL_Log_AdHit**/
		if(exists(select * from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'PNL_S_AdHit_Detail'))
		drop table PNL_S_AdHit_Detail
		GO
	/**end drop table PNL_Log_AdHit**/
	/**start RollBack modify table PNL_Log_AdHit**/
	
		if(exists(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='PNL_Log_AdHit' AND COLUMN_NAME = 'IMEI'  ))
		alter table PNL_Log_AdHit drop column [IMEI]

		if(exists(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='PNL_Log_AdHit' AND COLUMN_NAME = 'IsOpened'  ))
		alter table PNL_Log_AdHit drop column [IsOpened]
		GO
	/**end RollBack modify table PNL_Log_AdHit**/
/**end For CR00029 by Wei,Devin**/

/**start rollback PROCEDURE SP_DownSourceStatistic**/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	-- =============================================
	-- Author:  <Author,,Name>
	-- Create date: <Create Date,,>
	-- Description: 下载来源 分析 包括PlayNow, 百度，其中在做分析插入之前要做一次删除
	-- =============================================
	ALTER PROCEDURE [dbo].[SP_DownSourceStatistic]
	-- Add the parameters for the stored procedure here
	@BeginTime Datetime, 
	@EndTime Datetime
	AS
	BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- declare @errorCount int=0 --错误的累加
	--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
	-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点

	declare @errorCount int 
	set @errorCount=0 

	begin  tran --开始事务

	--set @BeginTime=CAST(@BeginTime as date) --开始时间
	--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
	set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as date) --开始时间
	set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as date)) --结束时间


	-- 分析前先删除 某一时间段的数据
	delete from  PN_S_DownSource where CreateTime>=@BeginTime and  CreateTime<@EndTime

	-- PlayNow 下载来源 分析
	insert into PN_S_DownSource(
	AppName, Publisher, Price, Home, AppDetail, AppRelate,
	SearchResult, Recommend, RankApp, RankGame, ZoneDetail,
	CategoryDetail, WapDown,NewApp,NewGame,UpdateApp, MyApps,
	WidgetApp, WidgetGame, WidgetAppList, WidgetGameList, DownCount, DownCompleteCount,
	ContentSource, MachineType, CreateTime
	)

	SELECT  AppName 应用名称,
	Publisher AS 供应商, 
	Price AS 单价, 
	sum(CASE pageName WHEN '首页'     THEN 1 else 0 end) 首页, 
	sum(CASE pageName WHEN '应用详情'     THEN 1 else 0 end) 应用详情, 
	sum(CASE pageName WHEN '应用相关'     THEN 1 else 0 end) 应用相关, 
	sum(CASE pageName WHEN '搜索结果'     THEN 1 else 0 end) 搜索结果, 
	sum(CASE pageName WHEN '推荐'     THEN 1 else 0 end) 推荐, 
	sum(CASE pageName WHEN '排行应用'     THEN 1 else 0 end) 排行应用, 
	sum(CASE pageName WHEN '排行游戏'     THEN 1 else 0 end) 排行游戏, 
	sum(CASE pageName WHEN '专区详情'     THEN 1 else 0 end) 专区详情, 
	sum(CASE pageName WHEN '分类详情'     THEN 1 else 0 end) 分类详情, 
	sum(CASE pageName WHEN 'Wap下载'     THEN 1 else 0 end) Wap下载,

	sum(CASE pageName WHEN '新品应用'     THEN 1 else 0 end) 新品应用, 
	sum(CASE pageName WHEN '新品游戏'     THEN 1 else 0 end) 新品游戏,
	sum(case pageName WHEN '应用升级'     THEN 1 else 0 end) 应用升级, 
	sum(case pageName WHEN '我的应用'     THEN 1 else 0 end) 我的应用, 
	sum(case pageName WHEN 'Widget应用'   THEN 1 else 0 end) Widget应用,
	sum(case pageName WHEN 'Widget游戏'   THEN 1 else 0 end) Widget游戏,
	sum(case pageName WHEN 'Widget应用列表'   THEN 1 else 0 end) Widget应用列表,
	sum(case pageName WHEN 'Widget游戏列表'   THEN 1 else 0 end) Widget游戏列表,

	COUNT(StartTime) as 下载数,
	sum(CASE  WHEN EndTime is not null   THEN 1 else 0 end) 成功下载数,
	'PlayNow',
	MachineType,
	-- cast(StartTime as date) CreateTime
	cast( convert(varchar(10),StartTime,120)as datetime) CreateTime
	from dbo.PN_Order 

	WHERE  (IntentFromId !=3 or IntentFromId is null )   

	AND StartTime>= @BeginTime  AND StartTime < @EndTime
	AND (ClientVer !='web' or ClientVer is null)
	--and  PageName in('首页','应用详情','应用相关','搜索结果','推荐','排行应用','排行游戏',
	--'专区详情','分类详情','Wap下载')

	-- Group by  cast(StartTime as date), MachineType,AppName,Publisher,Price
	Group by  cast( convert(varchar(10),StartTime,120)as datetime), MachineType,AppName,Publisher,Price

	set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

	--百度下载来源 分析

	insert into PN_S_DownSource(
	Home, AppRelate,
	Recommend, RankApp, RankGame, ZoneDetail,
	CategoryDetail, WapDown, NewApp,NewGame,
	AppName, Publisher, Price,AppDetail, SearchResult,DownCount,DownCompleteCount,
	ContentSource,MachineType, CreateTime
	)
	SELECT 
	0,0,0,0,0,0,0,0,0,0,
	AppName,Publisher,Price,
	SUM(CASE WHEN pageName='应用详情' THEN 1 ELSE 0 END) 应用详情, 
	sum(CASE pageName WHEN '搜索结果'     THEN 1 else 0 end) 搜索结果,

	COUNT(StartTime) as 下载数,
	sum(CASE  WHEN EndTime is null   THEN 1 else 0 end) 成功下载数,

	'百度', 
	MachineType,
	-- cast(StartTime as date )
	cast( convert(varchar(10),StartTime,120)as datetime)
	from dbo.PN_Order 
	where IntentFromId =3  and  StartTime>=@BeginTime and  StartTime<@EndTime
	and  PageName in('应用详情','搜索结果')
	and (ClientVer !='web' or ClientVer is null)
	-- Group by cast(StartTime as date), MachineType,AppName,Publisher,Price
	Group by cast( convert(varchar(10),StartTime,120)as datetime), MachineType,AppName,Publisher,Price
	set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

	if(@errorCount>0)

	begin

	rollback --如果有错，就回滚事务

	end

	else

	begin

	commit tran --如果没有错，就提交事务


	end

	END

	GO
/**end roolback  PROCEDURE SP_DownSourceStatistic**/

/**start rollback table PN_Order**/

	IF (EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_Order' AND COLUMN_NAME = 'IsInstalled'))
	alter table [dbo].[PN_Order] drop column  [IsInstalled]

	IF (EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_Order' AND COLUMN_NAME = 'InstallTime'))
	alter table [dbo].[PN_Order] drop column [InstallTime]
	GO
/**end rollback table PN_Order**/

/**start rollback modify table PN_Log_PageViewInfo**/
	IF ( EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_Log_PageViewInfo' AND COLUMN_NAME = 'AppId'))
	alter table [dbo].[PN_Log_PageViewInfo] drop column  [AppId]
	GO
/**start rollback modify table PN_Log_PageViewInfo**/

/**start rollback table PN_S_DownSource**/
	
	IF (EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_DownSource' AND COLUMN_NAME = 'AllAppDetailPV'))
	alter table [dbo].[PN_S_DownSource] drop column  [AllAppDetailPV]

	IF (EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_DownSource' AND COLUMN_NAME = 'AllInstallCount'))
	alter table [dbo].[PN_S_DownSource] drop column [AllInstallCount]
	
	IF ( EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_DownSource' AND COLUMN_NAME = 'AppId'))
	alter table [dbo].[PN_S_DownSource] drop column  [AppId]
	GO
/**end rollback table PN_S_DownSource**/