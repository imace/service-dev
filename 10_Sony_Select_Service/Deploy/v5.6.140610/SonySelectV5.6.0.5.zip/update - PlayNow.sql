﻿USE [PlayNow]
GO

if(not exists(select * from [PN_Module] where ModulePath = 'Statistic/AdHitDetail.aspx'))
INSERT INTO [PN_Module]
           ([MenuId]
           ,[ModuleName]
           ,[ModulePath])
     VALUES
           (3
           ,'广告详细统计'
           ,'Statistic/AdHitDetail.aspx')
GO