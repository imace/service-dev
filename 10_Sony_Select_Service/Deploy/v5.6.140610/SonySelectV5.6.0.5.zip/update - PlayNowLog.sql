﻿USE [PlayNowLog]
GO
/**start For CR00024 by Wei,Devin**/
	
/**start modify table PN_S_DownSource**/
IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_DownSource' AND COLUMN_NAME = 'AllAppDetailPV'))
begin
alter table [dbo].[PN_S_DownSource] add  [AllAppDetailPV] [int]
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'应用详情PV' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_DownSource', @level2type=N'COLUMN',@level2name=N'AllAppDetailPV'
end

IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_DownSource' AND COLUMN_NAME = 'AllInstallCount'))
begin
alter table [dbo].[PN_S_DownSource] add [AllInstallCount] [int]
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'安装成功次数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_DownSource', @level2type=N'COLUMN',@level2name=N'AllInstallCount'
end

IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_DownSource' AND COLUMN_NAME = 'AppId'))
begin
alter table [dbo].[PN_S_DownSource] add  [AppId] [nvarchar](20)
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'应用详情ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_DownSource', @level2type=N'COLUMN',@level2name=N'AppId'
end

GO

/**end modify table PN_S_DownSource**/

/**start modify table PN_Log_PageViewInfo**/
IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_Log_PageViewInfo' AND COLUMN_NAME = 'AppId'))
begin
alter table [dbo].[PN_Log_PageViewInfo] add  [AppId] [nvarchar](20)
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'应用ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo', @level2type=N'COLUMN',@level2name=N'AppId'
end
GO
/**end modify table PN_Log_PageViewInfo**/


/**start modify table PN_Order**/
IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_Order' AND COLUMN_NAME = 'IsInstalled'))
begin
alter table [dbo].[PN_Order] add  [IsInstalled] [int]
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'应用安装是否成功:0 不成功;1 成功' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Order', @level2type=N'COLUMN',@level2name=N'IsInstalled'
end

IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_Order' AND COLUMN_NAME = 'InstallTime'))
begin
alter table [dbo].[PN_Order] add [InstallTime] [datetime]
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'应用安装时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Order', @level2type=N'COLUMN',@level2name=N'InstallTime'
end

GO
/**end modify table PN_Order**/

/**start modify PROCEDURE SP_DownSourceStatistic**/

	/****** 对象:  StoredProcedure [dbo].[SP_DownSourceStatistic]    脚本日期: 05/22/2014 06:56:49 ******/
	
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
	-- =============================================
	-- Author:  <Author,,Name>
	-- Create date: <Create Date,,>
	-- Description: 下载来源 分析 包括PlayNow, 百度，其中在做分析插入之前要做一次删除
	-- =============================================
	Alter PROCEDURE [dbo].[SP_DownSourceStatistic]
	 -- Add the parameters for the stored procedure here
	 @BeginTime Datetime, 
	 @EndTime Datetime
	AS
	BEGIN
	 -- SET NOCOUNT ON added to prevent extra result sets from
	 -- interfering with SELECT statements.
	 SET NOCOUNT ON;

	-- declare @errorCount int=0 --错误的累加
	--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
	-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点

	declare @errorCount int 
	set @errorCount=0 

	begin  tran --开始事务

	--set @BeginTime=CAST(@BeginTime as date) --开始时间
	--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
	set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as date) --开始时间
	set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as date)) --结束时间


	-- 分析前先删除 某一时间段的数据
	delete from  PN_S_DownSource where CreateTime>=@BeginTime and  CreateTime<@EndTime

	-- PlayNow 下载来源 分析
	insert into PN_S_DownSource(
	  AppName, Publisher, Price, AppId,Home, AppDetail, AppRelate,
	  SearchResult, Recommend, RankApp, RankGame, ZoneDetail,
	  CategoryDetail, WapDown,NewApp,NewGame,UpdateApp, MyApps,
	  WidgetApp, WidgetGame, WidgetAppList, WidgetGameList, DownCount, DownCompleteCount,
	  ContentSource, MachineType, CreateTime
	)

	SELECT  pa.Name 应用名称,
	  pa.Publisher AS 供应商, 
	  pa.Price AS 单价,
	  AppId, 
	  sum(CASE pageName WHEN '首页'     THEN 1 else 0 end) 首页, 
	  sum(CASE pageName WHEN '应用详情'     THEN 1 else 0 end) 应用详情, 
	  sum(CASE pageName WHEN '应用相关'     THEN 1 else 0 end) 应用相关, 
	  sum(CASE pageName WHEN '搜索结果'     THEN 1 else 0 end) 搜索结果, 
	  sum(CASE pageName WHEN '推荐'     THEN 1 else 0 end) 推荐, 
	  sum(CASE pageName WHEN '排行应用'     THEN 1 else 0 end) 排行应用, 
	  sum(CASE pageName WHEN '排行游戏'     THEN 1 else 0 end) 排行游戏, 
	  sum(CASE pageName WHEN '专区详情'     THEN 1 else 0 end) 专区详情, 
	  sum(CASE pageName WHEN '分类详情'     THEN 1 else 0 end) 分类详情, 
	  sum(CASE pageName WHEN 'Wap下载'     THEN 1 else 0 end) Wap下载,
	  
	  sum(CASE pageName WHEN '新品应用'     THEN 1 else 0 end) 新品应用, 
	  sum(CASE pageName WHEN '新品游戏'     THEN 1 else 0 end) 新品游戏,
	  sum(case pageName WHEN '应用升级'     THEN 1 else 0 end) 应用升级, 
	  sum(case pageName WHEN '我的应用'     THEN 1 else 0 end) 我的应用, 
	  sum(case pageName WHEN 'Widget应用'   THEN 1 else 0 end) Widget应用,
	  sum(case pageName WHEN 'Widget游戏'   THEN 1 else 0 end) Widget游戏,
	  sum(case pageName WHEN 'Widget应用列表'   THEN 1 else 0 end) Widget应用列表,
	  sum(case pageName WHEN 'Widget游戏列表'   THEN 1 else 0 end) Widget游戏列表,
	  
	  COUNT(StartTime) as 下载数,
	  sum(CASE  WHEN EndTime is not null   THEN 1 else 0 end) 成功下载数,
	  'PlayNow',
	  MachineType,
	 -- cast(StartTime as date) CreateTime
		cast( convert(varchar(10),StartTime,120)as datetime) CreateTime
	from dbo.PN_Order,[PlayNow].[dbo].[PN_AppInfo] pa

	WHERE  (IntentFromId !=3 or IntentFromId is null )   

	AND StartTime>= @BeginTime  AND StartTime < @EndTime
	AND (ClientVer !='web' or ClientVer is null)
	AND AppId = pa.Id
	AND IsInstalled is null
	--and  PageName in('首页','应用详情','应用相关','搜索结果','推荐','排行应用','排行游戏',
	--'专区详情','分类详情','Wap下载')

	-- Group by  cast(StartTime as date), MachineType,AppName,Publisher,Price
	 Group by  cast( convert(varchar(10),StartTime,120)as datetime), MachineType,AppId,pa.Name,pa.Publisher,pa.Price

	--playnow 成功安装次数 统计 start

	 create table #T_PN_Order_AllInstallCount(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllInstallCount] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL,
	)

	insert into #T_PN_Order_AllInstallCount(MachineType,CreateTime,AllInstallCount,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),InstallTime,120)as datetime) CreateTime
		  ,count(InstallTime) AllInstallCount
		  ,'PlayNow'
		  ,AppId
	  FROM [PN_Order] where IsInstalled =1 and (InstallTime >= @BeginTime and InstallTime < @EndTime)
	and (IntentFromId !=3 or IntentFromId is null ) 
	and (ClientVer !='web' or ClientVer is null)
	Group by  cast( convert(varchar(10),InstallTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllInstallCount = tpoa.AllInstallCount
	from #T_PN_Order_AllInstallCount tpoa, PN_S_DownSource
	where tpoa.CreateTime = PN_S_DownSource.CreateTime and tpoa.MachineType = PN_S_DownSource.MachineType 
	and tpoa.AppId = PN_S_DownSource.AppId and tpoa.ContentSource = PN_S_DownSource.ContentSource

	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllInstallCount,ContentSource,AppId,Price)
	select pa.Name,poa.MachineType,pa.Publisher,poa.CreateTime,poa.AllInstallCount,poa.ContentSource,poa.AppId,pa.Price
	from #T_PN_Order_AllInstallCount poa,[PlayNow].[dbo].[PN_AppInfo] pa
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poa.CreateTime = psd.CreateTime and poa.MachineType = psd.MachineType 
	and poa.AppId = psd.AppId and poa.ContentSource = psd.ContentSource )
	and  poa.AppId = pa.Id

	drop table #T_PN_Order_AllInstallCount

	--playnow 成功安装次数 统计 end

	--playnow 应用详情PV 统计 start
	create table #T_PN_Order_AllAppDetailPV(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllAppDetailPV] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL,
	)

	insert into #T_PN_Order_AllAppDetailPV(MachineType,CreateTime,AllAppDetailPV,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),DateTime,120)as datetime) CreateTime
		  ,count(DateTime) AllAppDetailPV
		  ,'PlayNow'
		  ,AppId
	  FROM [PN_Log_PageViewInfo] 
	where (DateTime >= @BeginTime and DateTime < @EndTime)
	and (IntentFromId!='1' and IntentFromId !=3 or IntentFromId is null)  
	and (ContentName is not null and ContentName !='')
	Group by  cast( convert(varchar(10),DateTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllAppDetailPV = tpoa.AllAppDetailPV
	from #T_PN_Order_AllAppDetailPV tpoa ,PN_S_DownSource
	where tpoa.CreateTime = PN_S_DownSource.CreateTime and tpoa.MachineType = PN_S_DownSource.MachineType 
	and tpoa.AppId = PN_S_DownSource.AppId and tpoa.ContentSource = PN_S_DownSource.ContentSource

	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllAppDetailPV,ContentSource,AppId,Price)
	select pa.Name,poa.MachineType,pa.Publisher,poa.CreateTime,poa.AllAppDetailPV,poa.ContentSource,poa.AppId,pa.Price
	from #T_PN_Order_AllAppDetailPV poa,[PlayNow].[dbo].[PN_AppInfo] pa
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poa.CreateTime = psd.CreateTime and poa.MachineType = psd.MachineType 
	and poa.AppId = psd.AppId and poa.ContentSource = psd.ContentSource )
	and  poa.AppId = pa.Id

	drop table #T_PN_Order_AllAppDetailPV

	--playnow 应用详情PV 统计 end

	set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

	--百度下载来源 分析

	insert into PN_S_DownSource(
	  Home, AppRelate,
	  Recommend, RankApp, RankGame, ZoneDetail,
	  CategoryDetail, WapDown, NewApp,NewGame,
	 AppName, Publisher, Price,AppId,AppDetail, SearchResult,DownCount,DownCompleteCount,
	 ContentSource,MachineType, CreateTime
	)
	SELECT 
	0,0,0,0,0,0,0,0,0,0,
	  pb.Name,pb.Publisher,pb.Price,pb.AppId,
	  SUM(CASE WHEN pageName='应用详情' THEN 1 ELSE 0 END) 应用详情, 
	  sum(CASE pageName WHEN '搜索结果'     THEN 1 else 0 end) 搜索结果,

	  COUNT(StartTime) as 下载数,
	  sum(CASE  WHEN EndTime is not null   THEN 1 else 0 end) 成功下载数,

	  '百度', 
	  MachineType,
	 -- cast(StartTime as date )
	cast( convert(varchar(10),StartTime,120)as datetime)
	from dbo.PN_Order ,[PlayNow].[dbo].[PN_BaiduDownloadList] pb
	where IntentFromId =3  and  StartTime>=@BeginTime and  StartTime<@EndTime
	and  PageName in('应用详情','搜索结果')
	and (ClientVer !='web' or ClientVer is null)
	and PN_Order.AppId = pb.AppId
	AND IsInstalled is null
	-- Group by cast(StartTime as date), MachineType,AppName,Publisher,Price
	Group by cast( convert(varchar(10),StartTime,120)as datetime), MachineType,pb.AppId,pb.Name,pb.Publisher,pb.Price

	--baidu 成功安装次数 统计 start

	create table #T_PN_Order_AllInstallCount_BD(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllInstallCount] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL
	)

	insert into #T_PN_Order_AllInstallCount_BD(MachineType,CreateTime,AllInstallCount,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),InstallTime,120)as datetime) CreateTime
		  ,count(InstallTime) AllInstallCount
		  ,'百度' 
		  ,AppId
	  FROM [PN_Order] where IsInstalled =1 and (InstallTime >= @BeginTime and InstallTime < @EndTime)
	and IntentFromId =3 
	and  PageName in('应用详情','搜索结果')
	and (ClientVer !='web' or ClientVer is null)
	Group by  cast( convert(varchar(10),InstallTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllInstallCount = tpoabd.AllInstallCount
	from #T_PN_Order_AllInstallCount_BD tpoabd 
	where tpoabd.CreateTime = PN_S_DownSource.CreateTime 
	and tpoabd.MachineType = PN_S_DownSource.MachineType 
	and tpoabd.AppId = PN_S_DownSource.AppId
	and tpoabd.ContentSource = PN_S_DownSource.ContentSource


	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllInstallCount,ContentSource,AppId,Price)
	select pb.Name,poabd.MachineType,pb.Publisher,poabd.CreateTime,poabd.AllInstallCount,poabd.ContentSource,poabd.AppId,pb.Price
	from #T_PN_Order_AllInstallCount_BD poabd,[PlayNow].[dbo].[PN_BaiduDownloadList] pb
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poabd.CreateTime = psd.CreateTime 
	and poabd.MachineType = psd.MachineType 
	and poabd.AppId = psd.AppId 
	and poabd.ContentSource = psd.ContentSource 
	)

	--baidu 成功安装次数 统计 end

	--baidu 应用详情PV 统计 start

		create table #T_PN_Order_AllAppDetailPV_BD(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllAppDetailPV] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL
	)

	insert into #T_PN_Order_AllAppDetailPV_BD(MachineType,CreateTime,AllAppDetailPV,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),DateTime,120)as datetime) CreateTime
		  ,count(DateTime) AllAppDetailPV
		  ,'百度'
		  ,AppId
	  FROM [PN_Log_PageViewInfo] 
	where (DateTime >= @BeginTime and DateTime < @EndTime)
	and IntentFromId =3
	and PageName in('应用详情','搜索结果') 
	and (ContentName is not null and ContentName !='')
	Group by  cast( convert(varchar(10),DateTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllAppDetailPV = tpoadb.AllAppDetailPV
	from #T_PN_Order_AllAppDetailPV_BD tpoadb 
	where tpoadb.CreateTime = PN_S_DownSource.CreateTime and tpoadb.MachineType = PN_S_DownSource.MachineType 
	and tpoadb.AppId = PN_S_DownSource.AppId and tpoadb.ContentSource = PN_S_DownSource.ContentSource

	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllAppDetailPV,ContentSource,AppId,Price)
	select pb.Name,poadb.MachineType,pb.Publisher,poadb.CreateTime,poadb.AllAppDetailPV,poadb.ContentSource,poadb.AppId,pb.Price
	from #T_PN_Order_AllAppDetailPV_BD poadb,[PlayNow].[dbo].[PN_BaiduDownloadList] pb
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poadb.CreateTime = psd.CreateTime and poadb.MachineType = psd.MachineType 
	and poadb.AppId = psd.AppId and poadb.ContentSource = psd.ContentSource ) 
	and poadb.AppId = pb.AppID
	--baidu 应用详情PV 统计 end

	set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

	if(@errorCount>0)

	 begin

	  rollback --如果有错，就回滚事务

	 end

	else

	 begin

	  commit tran --如果没有错，就提交事务

	 
	 end

	END
GO
/**end modify PROCEDURE SP_DownSourceStatistic**/

/**end For CR00024 by Wei,Devin**/

/**start For CR00029 by Wei,Devin**/
	/**start modify table PNL_Log_AdHit**/
		if(not exists(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='PNL_Log_AdHit' AND COLUMN_NAME = 'IMEI'  ))
		begin
		alter table PNL_Log_AdHit add [IMEI] [nvarchar](50) NULL
		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'国际移动电话设备识别码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_Log_AdHit', @level2type=N'COLUMN',@level2name=N'IMEI'
		end

		if(not exists(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='PNL_Log_AdHit' AND COLUMN_NAME = 'IsOpened'  ))
		begin
		alter table PNL_Log_AdHit add  [IsOpened] [int] NULL
		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'广告链接是否成功打开;0,不成功;1,成功' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_Log_AdHit', @level2type=N'COLUMN',@level2name=N'IsOpened'
		end
		GO
	/**end modify table PNL_Log_AdHit**/
	
	/**start create table PNL_S_AdHit_Detail**/
	SET ANSI_NULLS ON
	GO
	SET QUOTED_IDENTIFIER ON
	GO
	if(not exists(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='PNL_S_AdHit_Detail'))
	begin
	CREATE TABLE [dbo].[PNL_S_AdHit_Detail](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[AdId] [int] NOT NULL,
		[AdName] [nvarchar](50) NULL,
		[IntentFromId] [int] NOT NULL,
		[AdHitCount] [int] NULL,
		[UV] [int] NULL,
		[OpenCount] [int] NULL,
		[CreateTime] [datetime] NULL,
	 CONSTRAINT [PK_PNL_S_AdHit_Detail] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'广告ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'AdId'
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'广告名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'AdName'

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'广告点击来源：1，Widget   2，Banner' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'IntentFromId'

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'广告点击次数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'AdHitCount'

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'独立用户数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'UV'

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'成功跳转次数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'OpenCount'

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'记录创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PNL_S_AdHit_Detail', @level2type=N'COLUMN',@level2name=N'CreateTime'
	end
	GO
	/**end create table PNL_S_AdHit_Detail**/
	
	/**start modify procedure  SP_AdHitStatistic**/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		
		Alter PROCEDURE [dbo].[SP_AdHitStatistic]
		 -- Add the parameters for the stored procedure here
		 @BeginTime Datetime,
		 @EndTime Datetime
		AS
		BEGIN
		 -- SET NOCOUNT ON added to prevent extra result sets from
		 -- interfering with SELECT statements.
		SET NOCOUNT ON;

		declare @errorCount int --错误的累加
		set @errorCount=0 

		begin  tran --开始事务

		-- set @BeginTime=CAST(@BeginTime as date) --开始时间
		-- set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
		set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as datetime) --开始时间
		set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as datetime)) --结束时间

		-- 分析前先删除 某一时间段的数据
		delete from  dbo.PNL_S_AdHit where CreateTime>=@BeginTime and  CreateTime<@EndTime
		delete from  dbo.PNL_S_AdHit_Detail where CreateTime>=@BeginTime and  CreateTime<@EndTime

		-- 统计Widget的广告点击
		insert into PNL_S_AdHit(
		  AdId, AdName, IntenetFromId, AdHitCount, CreateTime
		)

		SELECT 
		AdId,
		AdName,
		'1',
		-- cast(DateTime as date ),
		sum(CASE IntenetFromId WHEN '1'     THEN 1 else 0 end),
		cast( convert(varchar(10),CreateTime,120)as datetime)

		 FROM  PNL_Log_AdHit
		WHERE CreateTime>=@BeginTime and  CreateTime<@EndTime 
		 
		 GROUP BY cast( convert(varchar(10),CreateTime,120)as datetime), AdId, AdName

		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		-- 统计Banner的广告点击
		insert into PNL_S_AdHit(
		  AdId, AdName, IntenetFromId, AdHitCount, CreateTime
		)

		SELECT 
		AdId,
		AdName,
		'2',
		-- cast(DateTime as date ),
		sum(CASE IntenetFromId WHEN '2'     THEN 1 else 0 end),
		cast( convert(varchar(10),CreateTime,120)as datetime)

		 FROM  PNL_Log_AdHit
		WHERE CreateTime>=@BeginTime and  CreateTime<@EndTime 
		 
		 GROUP BY cast( convert(varchar(10),CreateTime,120)as datetime), AdId, AdName

		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		--统计Push Message,Widget,Banner的广告点击start
		insert into PNL_S_AdHit_Detail(
			AdId,IntentFromId,AdHitCount,UV,OpenCount,CreateTime
		)
		select AdId,IntenetFromId,
		sum(case when IsOpened is NULL then 1 else 0 end) as AdHitCount,
		count(distinct(IMEI)) as UV,
		sum(case IsOpened when 1 then 1 else 0 end) as OpenCount,
		cast( convert(varchar(10),CreateTime,120)as datetime)
		from PNL_Log_AdHit
		WHERE CreateTime>=@BeginTime and  CreateTime<@EndTime 
		GROUP BY cast( convert(varchar(10),CreateTime,120)as datetime), AdId,IntenetFromId

		--统计Push Message,Widget,Banner的广告点击end

		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		if(@errorCount>0)

		 begin

		  rollback --如果有错，就回滚事务

		 end

		else

		 begin

		  commit tran --如果没有错，就提交事务

		 
		 end

		END
		GO
	/**end modify procedure  SP_AdHitStatistic**/
	
/**end For CR00029 by Wei,Devin**/
/**start For CR00026 by Wei,Devin**/
	/**start modify table  PN_S_Message**/
		IF ( NOT EXISTS(select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME ='PN_S_Message' AND COLUMN_NAME = 'InstallCount'))
		begin
		alter table [dbo].[PN_S_Message] add [InstallCount] [int]
		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'安装成功次数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message', @level2type=N'COLUMN',@level2name=N'InstallCount'
		end
	/**end modify table  PN_S_Message**/
	/**start modify procedure  SP_MessageStatistic**/
		/****** 对象:  StoredProcedure [dbo].[SP_MessageStatistic]    脚本日期: 05/29/2014 04:28:26 ******/
		SET ANSI_NULLS ON
		GO
		SET QUOTED_IDENTIFIER ON
		GO
		-- =============================================
		-- Author:		<Author,,Name>
		-- Create date: <Create Date,,>
		-- Description:	消息统计 分析 其中在做分析插入之前要做一次删除
		-- =============================================
		ALTER PROCEDURE [dbo].[SP_MessageStatistic]
			-- Add the parameters for the stored procedure here
			@BeginTime Datetime, 
			@EndTime Datetime
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;


		--declare @errorCount int=0 --错误的累加
		--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
		-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点
		--2013/7/4 jiaoxuhuan 在获取数量时添加MachineType过滤条件（例:and A.MachineType=C.MachineType）

		declare @errorCount int 
		set @errorCount=0 

		begin  tran --开始事务


		--set @BeginTime=CAST(@BeginTime as date) --开始时间
		--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
		set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
		set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间


		-- 分析前先删除 某一时间段的数据
		delete from  dbo.PN_S_Message where CreateTime>=@BeginTime and  CreateTime<@EndTime

		-- 消息统计 分析
			insert into dbo.PN_S_Message(
			 MessageID, MachineType, GetMessage,
			 ReadMessage, DownCount,  
			 DownCompleteCount, InstallCount, CreateTime
			)


				SELECT  MessageId, MachineType, 
						(
						select COUNT(*) from [PN_Log_Message] as A 
						 where C.MessageId=A.MessageId and IsValid=1 and   
						--CAST(A.CreateTime as date)=cast(C.CreateTime as date) ) as GetCount, 
						cast( convert(varchar(10),A.CreateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime) 
						and A.MachineType=C.MachineType
						) as GetCount, 
						(select COUNT(*) from [PN_Log_PageViewInfo] as B 

						where C.MessageId=B.ContentId AND IntentFromId=4 and

						-- CAST(B.DateTime as date)=cast(C.CreateTime as date) ) as PVCount,
						cast( convert(varchar(10),B.DateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
						and B.MachineType=C.MachineType
						 )as PVCount,
						(
						select COUNT(*) from [PN_Order] as D 

						where C.MessageId=D.ContentId and IntentFromId=4 and

						 --CAST(D.StartTime as date)=cast(C.CreateTime as date) ) as DownCount,
						 cast( convert(varchar(10),D.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
						 and D.MachineType=C.MachineType
						  )as DownCount,
						 (select COUNT(*) from [PN_Order] as G 

						   where C.MessageId=G.ContentId and IntentFromId=4 and

						  -- CAST(G.StartTime as date)=cast(C.CreateTime as date)  
							cast( convert(varchar(10),G.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
							and G.MachineType=C.MachineType
						   and EndTime is not null) as DownCompleteCount
						,
						 (select COUNT(*) from [PN_Order] as H
						   where C.MessageId=H.ContentId and IntentFromId=4 and 
							cast( convert(varchar(10),H.InstallTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
							and H.MachineType=C.MachineType
						   and IsInstalled = 1) as InstallCount
						,cast( convert(varchar(10),CreateTime,120)as datetime) dTime
				FROM [PN_log_Message] as C

				where  CreateTime>=@BeginTime AND CreateTime<@EndTime    
				and MessageId>0 
				AND	IsValid=1 
				--group by CAST(CreateTime as date),MessageId,MachineType	
				  group by cast( convert(varchar(10),CreateTime,120)as datetime),MessageId,MachineType	




		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

		if(@errorCount>0)

			begin

				rollback --如果有错，就回滚事务

			end

		else

			begin

				commit tran --如果没有错，就提交事务

			
			end

		END
		GO
	/**end modify procedure  SP_MessageStatistic**/
/**end For CR00026 by Wei,Devin**/

/**start For CR00026 by Hu,Jingzhi**/
  /**start modify view  V_PN_Message**/

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'V_PN_Message') 
   DROP View V_PN_Message 
GO
/****** 对象:  View [dbo].[V_PN_Message]    脚本日期: 05/27/2014 23:29:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[V_PN_Message]
AS
SELECT     msg.Id, msg.Title, msg.Type, msg.[Content], msg.Description, msg.MachineTypes, msg.StartTime, msg.EndTime, app.Name
FROM         PlayNow.dbo.PN_Message AS msg LEFT OUTER JOIN
                      PlayNow.dbo.PN_AppInfo AS app ON msg.[Content] = app.Id
WHERE msg.Type = 1
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "msg"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 119
               Right = 187
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "app"
            Begin Extent = 
               Top = 6
               Left = 225
               Bottom = 125
               Right = 383
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'V_PN_Message'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'V_PN_Message'
GO

  /**end modify view  V_PN_Message**/
/**end For CR00026 by Hu,Jingzhi**/

/**start For CR00029 by Wei,Devin**/

if(not exists(select * from information_schema.tables where TABLE_NAME = 'V_PNL_S_AdHit_Detail' AND TABLE_TYPE = 'VIEW' ))
Begin 
	declare @view_sql varchar(500)
	set @view_sql ='
		create view [dbo].[V_PNL_S_AdHit_Detail] 
		as 
		SELECT ROW_NUMBER() OVER(ORDER BY CreateTime DESC,AdName DESC) AS ROWNUM, 
				ID,AdId,IntentFromId,AdHitCount,UV,OpenCount,CreateTime,AdName 
		FROM ( 
		SELECT psad.ID,psad.AdId,psad.IntentFromId,psad.AdHitCount,psad.UV,psad.OpenCount,psad.CreateTime,pa.Name as AdName
		FROM PNL_S_AdHit_Detail psad,[PlayNow].[dbo].[PN_AdInfo] pa 
		WHERE pa.ID = psad.AdId
		) AS A'
	execute(@view_sql)
End
GO