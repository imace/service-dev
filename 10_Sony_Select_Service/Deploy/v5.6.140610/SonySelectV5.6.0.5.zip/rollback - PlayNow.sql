﻿USE [PlayNow]
GO

delete from [PN_Module] where ModulePath = 'Statistic/AdHitDetail.aspx'
GO