﻿USE [PlayNow]
GO

/** start For update table PN_Album by Hu, Jingzhi **/
alter table [PlayNow].[dbo].[PN_Album] alter column [SmallIcon] nvarchar(300)

alter table [PlayNow].[dbo].[PN_Album] alter column [LargeIcon] nvarchar(300)
/** end For update table PN_Album by Hu, Jingzhi **/