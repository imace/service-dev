﻿USE [PlayNow]
GO

/** start Rollback For update table PN_Album by Hu, Jingzhi **/
IF EXISTS(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PN_Album' and COLUMN_NAME = 'SmallIcon')
BEGIN
alter table [PlayNow].[dbo].[PN_Album] alter column [SmallIcon] nvarchar(150)
END

IF EXISTS(select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'PN_Album' and COLUMN_NAME = 'LargeIcon')
BEGIN
alter table [PlayNow].[dbo].[PN_Album] alter column [LargeIcon] nvarchar(150)
END
/** end Rollback For update table PN_Album by Hu, Jingzhi **/