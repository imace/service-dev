﻿function Scroller(beginToScrollDistance) {
    if (typeof beginToScrollDistance == 'undefined') {
        this.beginToScrollDistance = 1;
    } else {
        this.beginToScrollDistance = beginToScrollDistance;
    }
    if (typeof this._reCalculate != 'function') {
        this._reCalculate = function () {
            var scrollHeight = document.body.scrollHeight;
            var toTopHeight = document.body.scrollTop;
            var windowHeight = window.screen.height;
            this.distance = scrollHeight - toTopHeight - windowHeight;
            this.notToScroll = scrollHeight <= windowHeight;
        }
    }
    this._reCalculate();
    if (typeof this.scroll != 'function') {
        ///
        //onScrollToBottom 到达底部时回调的函数
        //isLoadingBusy 判断是否为loading时的回调函数
        //onBeforeScroll scroll开始前的回调函数
        //param 上诉回调函数的的参数
        ///
        this.scroll = function (onScrollToBottom, isLoadingBusy, onBeforeScroll,param) {
            if (typeof onBeforeScroll == 'function') {
                onBeforeScroll(param);
            }
            this._reCalculate();
            if (typeof isLoadingBusy == 'function') {
                var isBusy = isLoadingBusy(param);
                if ((this.notToScroll || this.distance < this.beginToScrollDistance) && !isBusy) {
                    if (typeof onScrollToBottom == 'function') {
                        onScrollToBottom(param);
                    } else {
                        alert('scroll参数不合法');
                        return false;
                    }
                }
            } else {
                alert('scroll参数不合法');
                return false;
            }
           
        }
    }

    if (typeof this.reset != 'function') {
        this.reset = function () {
            this._reCalculate();
        }
    }
}