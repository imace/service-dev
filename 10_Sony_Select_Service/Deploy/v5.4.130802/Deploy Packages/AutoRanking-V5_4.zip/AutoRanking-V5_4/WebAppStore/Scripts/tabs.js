﻿(function ($) {
    var TabHelper = {
        initTab: function (objAttr, onHeaderTabClicked) {
            $(objAttr).each(function (index, ele) {
                var content = $('#' + ele.content);
                $('#' + ele.header).unbind('click');
                content.html('');
                $(content).data('no_need_scroll', 0);
                content.data('hasLoadedFromLocal', false);
                content.data('hasLoadedByNull', false);
                if (index == 0) {
                    $('#' + ele.header).addClass('active');
                    $('div.border-active', $('#' + ele.header)).show();
                    $('body').data('currentContentId', ele.content);
                    content.show();
                } else {
                    $('#' + ele.header).removeClass('active');
                    $('div.border-active', $('#' + ele.header)).hide();
                    content.hide();
                }
                var header = $('#' + ele.header);
                header.bind('click', function (event) {
                    onHeaderTabClicked(this);
                });
            });
        },
        //切换显示
        toggleShowContent: function (clickedHId, objAttr) {
            var unClickedObjs = $(objAttr).map(function () {
                if (this.header == clickedHId) {
                    return null;
                } else {
                    return this.content;
                }
            });
            var clickedObjs = $(objAttr).map(function () {
                if (this.header == clickedHId) {
                    return this.content;
                } else {
                    return null;
                }
            });
            var unclickedObjsHeaders = $(objAttr).map(function () {
                if (this.header == clickedHId) {
                    return null;
                } else {
                    return this.header;
                }
            });
            $(unclickedObjsHeaders).each(function (index, e) {
                $('#' + e).removeClass('active');
            });
            var clickedObjHeaders = $(objAttr).map(function () {
                if (this.header == clickedHId) {
                    return this.header;
                } else {
                    return null;
                }
            });
            $(unclickedObjsHeaders).each(function (index, e) {
                $('#' + e).removeClass('active');
                $('div.border-active', $('#' + e)).hide();
            });
            $(clickedObjHeaders).each(function (index, e) {
                $('#' + e).addClass('active');
                $('div.border-active', $('#' + e)).show();
            });
            $(unClickedObjs).each(function (index, e) {
                $('#' + e).hide();
            });
            $(clickedObjs).each(function (index, e) {
                $('body').data('currentContentId', e);
                $('#' + e).show();
            });
        },
        getLoadingUrl: function (objArray, contentId) {
            var urls = $(objArray).map(function () {
                if (this.content == contentId) {
                    return this.url;
                }
            });
            return urls[0];
        },
        getCachedData: function (id) {
            //alert(id);
            var data = window.sessionStorage.getItem('data' + id);
            if (data == null) return null;
            if (data.indexOf('$$$') != -1) {
                var datas = data.split('$$$');
                //alert(datas.length);
                var objs = [];
                $(datas).each(function (index, row) {
                    //alert(row);
                    var objArr = $.parseJSON(row);
                    $(objArr).each(function (i, obj) {
                        objs.push(obj);
                    });
                });
                return objs;
            } else {
                return $.parseJSON(data);
            }
        },

        clearData : function (id) {
            window.sessionStorage.removeItem('data' + id);
            window.sessionStorage.removeItem('isLoaded' + id);

        },

        unbind: function () {
            $(window).unbind('scroll');
        },

        unbindClick: function (id) {
            $('#' + id).unbind('click');
        },

        clearTag: function (id) { window.sessionStorage.removeItem('isLoaded' + id); },

        loadData: function (boundData, objAttr, contentId, renderView, pageIndex,pageSize) {
            if (typeof pageIndex == 'undefined' || pageIndex==null) {
                pageIndex = 0;
            }
            if (typeof pageSize == 'undefined' || pageSize == null) {
                pageSize = boundData.pageSize;
            }
            var isLoaded = window.sessionStorage.getItem('isLoaded' + contentId);
            var content = $('#' + contentId);
            var loadingCount = content.data('loadingCount');
            if (loadingCount == null) {
                loadingCount = 0;
            }
            //alert("isLoaded:" + isLoaded + " pageIndex:" + pageIndex + " loadingCount:" + loadingCount);
            if (isLoaded == null || isLoaded == 'false' || pageIndex == 0) {
                this.realLoadData(objAttr, contentId, pageIndex, boundData, loadingCount, renderView,pageSize);
            } else if (pageIndex > 0 && pageIndex > loadingCount) {
                this.realLoadData(objAttr, contentId, pageIndex, boundData, loadingCount, renderView, pageSize);
            } else {
                $('#' + contentId).data('isLoading', false);
            }
        },

        realLoadData: function (objAttr, contentId, pageIndex, boundData, loadingCount, renderView, pageSize) {
            var data = [];
            var content = $('#' + contentId);
            if (boundData.loading == 'remote') {//加载远程数据
                var ps = [];
                ps.push('pageIndex=' + pageIndex);
                ps.push('pageSize=' + pageSize);
                var params = ps.join('&');
                var loadingUrl = this.getLoadingUrl(objAttr, contentId);
                boundData.onBeforeLoadData();
                content.data('isLoading', true);
                $.Process({
                    loading: 'remote',
                    id: contentId,
                    params: params,
                    url: loadingUrl,
                    iframe:boundData.iframe,
                    convertData: function (id, data) { return boundData.convertData(id, data); },
                    onSuccess: function (id, data) {
                        content.data('loadingCount', pageIndex);
                        content.data('pageIndex', parseInt(pageIndex) + 1);
                        if (data == null || data.length == 0) {
                            boundData.onSuccess(data);
                            //没有数据了
                            content.data('isLoading', false);
                            $('#' + id).data('no_need_scroll', 1);
                            //alert($('#' + id).data('no_need_scroll'))
                            return;
                        }

                        var localData = window.sessionStorage.getItem('data' + id);;
                        var localDataStr = '';
                        if (localData != null) {
                            localDataStr = localData;
                            localDataStr +='$$$';
                        }
                        //alert(localDataStr)
                        boundData.onSuccess(data);
                        window.sessionStorage.setItem('data' + contentId, localDataStr+JSON.stringify(data));
                        window.sessionStorage.setItem('isLoaded' + contentId, 'true');
                        content.data('isLoading', false);
                    },
                    onError: function () {   boundData.onError(); content.data('isLoading', false); },
                    onRender: function (id, data) {
                        renderView(id, data, pageIndex == 0);
                    }
                });
            } else { //
                data = boundData.getData(contentId);
                var hasLoadedFromLocal = $('#' + contentId).data('hasLoadedFromLocal');
                //alert(data==null?"null":data.length +" "+hasLoadedFromLocal );
                if (data == null || data.length == 0 || hasLoadedFromLocal==true) {
                    var ps = [];
                    ps.push('pageIndex=' + pageIndex);
                    ps.push('pageSize=' + pageSize);
                    var params = ps.join('&');
                    var loadingUrl = this.getLoadingUrl(objAttr, contentId);
                    //alert(loadingUrl + "&" + params);
                    boundData.onBeforeLoadData();
                    content.data('isLoading', true);
                    $.Process({
                        loading: 'remote',
                        id: contentId,
                        params: params,
                        url: loadingUrl,
                        iframe: boundData.iframe,
                        convertData: function (id, newData) { return boundData.convertData(id, newData); },
                        onSuccess: function (id, newData) {
                            //alert(data.length)
                            content.data('hasLoadedByNull', true);
                            content.data('loadingCount', pageIndex);
                            content.data('pageIndex', parseInt(pageIndex) + 1);
                            if (newData == null || newData.length == 0) {
                                //没有数据了
                                $('#' + id).data('no_need_scroll', 1);
                                content.data('isLoading', false);
                                boundData.onSuccess(newData);
                                return;
                            }
                            var localData = window.sessionStorage.getItem('data' + id);
                            var localDataStr = "";
                            if (localData != null) {
                                localDataStr = localData;
                                localDataStr += '$$$';
                            }
                            boundData.onSuccess(newData);
                            window.sessionStorage.setItem('data' + contentId, localDataStr + JSON.stringify(newData));
                            window.sessionStorage.setItem('isLoaded' + contentId, 'true');
                            content.data('isLoading', false);
                        },
                        onError: function () { boundData.onError(); content.data('isLoading', false); },
                        onRender: function (id, newData) {
                            //alert(newData.length)
                            //alert(data);
                            renderView(id, newData, data == null || data.length == 0);
                        }
                    });
                } else {
                    //alert(contentId+' '+$('#' + contentId).data('hasLoadedFromLocal'));
                    if ($('#' + contentId).data('hasLoadedFromLocal') == false && content.data('hasLoadedByNull') == false) {
                        $('#' + contentId).data('hasLoadedFromLocal', true);
                        //content.data('pageIndex', parseInt(pageIndex) + 1);
                        content.data('isLoading', false);
                        renderView(contentId, data, true);
                        window.sessionStorage.setItem('isLoaded' + contentId, 'true');
                        boundData.onSuccess();
                    }
                }

            }
        },

        buildTemplate: function () {
            var lis = [];
            lis.push('<div class="left item color1 item-__INDEX__">');
            //lis.push('<b class="b1"></b><b class="b2"></b><b class="b3"></b><b class="b4"></b>');
            lis.push('<div>');
            lis.push('<div class="download"><img class="download-__INDEX__"  src="images/download_btn.png" />');
            lis.push('<p>__TOTAL_GAME_SIZE__ M</p>');
            lis.push('</div>');
            lis.push('<div class="left game-img"><img class="detail-__INDEX__" onerror="javascript:this.src=\'Images/apk_default80x80.png\';" src="Images/apk_default80x80.png" alt="__GAME_NAME__"  /></div>');
            lis.push('<div class="left game-content game-content-__INDEX__">');
            lis.push('<h3 class="detail-__INDEX__">__GAME_NAME__</h3>');
            lis.push('<div class="good-star left good-__INDEX__"></div>');
            lis.push('<div class="bad-star left bad-__INDEX__"></div>');
            lis.push('<div class="clean"></div>');
            lis.push('<div class="description">__DESCRIPTION__</div>');
            lis.push('</div>');
            lis.push('</div>');
            //lis.push('<b class="b5"></b><b class="b6"></b><b class="b7"></b><b class="b8"></b>');
            lis.push('</div>');
            lis.push('<div class="hiddendiv clean" style="display:none;"></div>');
            var template = $('<div>' + lis.join('') + '</div>');
            
            return template;
        },

    };
    $.Tab = function (objAttr, option) {
        var _option = {
            loading: 'local',
            pageSize: 20,
            firstPageSize: 20,
            buildTemplate: function () {
                return TabHelper.buildTemplate();
            },
            onDownloadBtnClicked: function (row) { },
            onGameDetailClicked: function (row) { },
            onNoDataLoading: function (contentId) { },
            onLoadingData: function (contentId) { },
            onBeforeLoadData: function () { },
            onCompleted: function (contentId) { },
            getData: function (contentId) {
                return []
            },
            onSuccess: function () { },
            onError: function () { },
            convertData: function (contendId, data) {
                return data;
            }
        };
        

        $.extend(_option, option || {});
        //创建全局模板
        var template = _option.buildTemplate();
        var sc = new Scroller();
        var currentContentId = objAttr[0].content;
        function scroll(contentId) {
            if ($('#'+contentId).data('no_need_scroll') == 1) {
                if (typeof _option.onNoDataLoading == 'function') {
                    _option.onNoDataLoading(contentId);
                }
                return;
            }
            sc.scroll(function (contentId) {
                loadDataByHitBottom(contentId);
            }, function (contentId) {
                return isAjaxBusy(contentId);
            }, function (contentId) {
                onBeforeScroll(contentId);
            }, contentId);
        }
        
        $(window).bind('scroll',function () {
            winScroll();
       });
        function winScroll() {
            var currentContentId = $('body').data('currentContentId');
            if (currentContentId == null) {
                currentContentId = objAttr[0].content;
            }
            scroll(currentContentId);
        }
        //work around for low version of apple webkit
        document.body.onscroll = winScroll;
        //alert(window.onscroll);
        function loadDataByHitBottom(contentId) {
            if ($('#' + contentId).data('isLoading') == true) {
                return false;
            }
            if ($('#' + contentId).data('no_need_scroll') == 1) {
                if (typeof _option.onNoDataLoading == 'function') {
                    _option.onNoDataLoading(contentId);
                }
                return;
            }
            var pageIndex = $('#' + contentId).data('pageIndex');
            if (pageIndex == null) {
                pageIndex = 0;
            }
            $('#' + contentId).data('isLoading', true);
            TabHelper.loadData(_option, objAttr, contentId, function (id, data, newItem) {
                $('#' + contentId).data('isLoading', false);
                renderView(id, data, newItem);
                if (typeof _option.onCompleted == 'function') {
                    _option.onCompleted(id);
                }
            }, parseInt(pageIndex));
        }

        function isAjaxBusy(contentId) {
            return $('#' + contentId).data('isLoading') == true;
        }

        function onBeforeScroll(contentId) {
            //_option.onBeforeLoadData(contentId);
        }

        //初始化tab
        TabHelper.initTab(objAttr, function (header) {
            sc.reset();
            process($(header).attr('id'));
        });
        var pageIndex = $('#' + objAttr[0].content).data('pageIndex');
        //加载默认的tab页
        TabHelper.loadData(_option, objAttr, objAttr[0].content, function (id,data,newItem) {
            renderView(id, data, newItem);
            if (typeof _option.onCompleted == 'function') {
                _option.onCompleted(id);
            }
        }, pageIndex,_option.firstPageSize);

        function process(headerId) {
            TabHelper.toggleShowContent(headerId, objAttr);
            var contentIds = $(objAttr).map(function () {
                if (headerId == this.header) {
                    return this.content;
                }
                return null;
            });
            var pageIndex = $('#' + contentIds[0]).data('pageIndex');
            TabHelper.loadData(_option, objAttr, contentIds[0], function (id, data, newItem) {
                renderView(id, data, newItem);
                if (typeof _option.onCompleted == 'function') {
                    _option.onCompleted(id);
                }
            }, pageIndex,_option.firstPageSize);
        }

        //渲染
        function renderView(id, data, newItem) {
            //alert(newItem);
            var parent = $('#' + id);
            var ul = $('<ul></ul>');
            if (newItem == true) {
                parent.append(ul);
            }
            var html = $('ul', parent);
            var row;
            for (i = 0; i < data.length; i++) {
                if (!DeviceHelper.Browser().isMobile) {
                    if (i % 2 == 0) {
                        row = $('<li class="row li' + i + '">');
                    }
                } else {
                    row = $('<li class="row li' + i + '">');
                }
                var templateHtml = template.clone().html();
                templateHtml = templateHtml.replace(/__TOTAL_GAME_SIZE__/g, data[i].size).replace(/__INDEX__/g, i).replace(/__GAME_IMGAGE__/g, data[i].image).replace(/__GAME_NAME__/g, data[i].name).replace(/__DESCRIPTION__/g, data[i].description);
                row.append(templateHtml);
                var goodStar = 11 * data[i].goodstart;
                $('.good-' + i, row).css('width', goodStar + 'px');
                var badStar = 11 * data[i].badstart;
                $('.bad-' + i, row).css('width', badStar + 'px');
                $('.download-' + i, row).data('index', i);
                $('.item-' + i, row).data('data', data[i]);
                $('.download-' + i, row).bind('click', function (event) {
                    var index = $(this).data('index');
                    _option.onDownloadBtnClicked($(event.target).closest('.item-' + index).data('data'));
                });
                $('.game-content-'+i, row).data('index', i);
                $('.game-content-'+i, row).data('data', data[i]);
                $('.game-content-'+i, row).bind('click', function (event) {
                    var index = $(this).data('index');
                    _option.onGameDetailClicked($(this).data('data'));
                });
                $('img.detail-' + i, row).data('index', i);
                $('img.detail-' + i, row).bind('click', function (event) {
                    var index = $(event.target).data('index');
                    option.onGameDetailClicked($(event.target).closest('.item-' + index).data('data'));
                });
                $('img.detail-' + i, row).preLoadImg(data[i].image, {
                    loaded: function (ele, src) {
                        ele.attr('src', src);
                    },
                    error: function (ele) {
                        ele.attr('src', 'Images/apk_default80x80.png');
                    }
                });
                //alert(DeviceHelper.Browser().isMobile);
                if (DeviceHelper.Browser().isMobile) {
                    $('.item', row).css('width', '100%');
                    $('.item', row).css('float', 'none'); 
                    $('.hiddendiv', row).css('display','block');
                    html.append(row);
                    html.append('<div class="clean"></div>');
                    
                } else {
                    if (DeviceHelper.isDeviceLanscape()) {
                        $('.item', row).css('width', '49%');
                    } else {
                        $('.item', row).css('width', '48.2%');
                    }

                    if (i % 2 == 1) {
                        $('.item-' + i, row).css('float', 'right');
                        html.append(row);
                    } else {
                        if (i == data.length - 1) {
                            html.append(row);
                        }
                    }
                }
                
            }
            
        }
    };
    $.clearData = function (id) {
        TabHelper.clearData(id);
        
    };

    $.getCachedData = function (id) {
        return TabHelper.getCachedData(id);
    };

    $.clearTag = function (id) {
        TabHelper.unbind();
        TabHelper.unbindClick(id);
        TabHelper.clearTag(id);
        
    };
})(jQuery);