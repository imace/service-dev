/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * @Athor Chris Cheng（程天亮）
 */

var DeviceHelper = {
    isDeviceLanscape: function () {
        //alert(window.orientation)
        if (this.Browser().isMobile)
        {
            switch (window.orientation) {
                case 90:
                    return true;
                case 0:
                    return false;
                case -90:
                    return true;
                case 180:
                    return false;
            }
        }
        else
        {
            switch (window.orientation) {
                case -90:
                case 90:
                    return false;
                case 0:
                    if (document.body.clientWidth > document.body.clientHeight) {
                        return true;
                    } else {
                        return false;
                    }
                case 180:
                    return true;
            }
        }
        
    },
    Browser: function () {
        var u = navigator.userAgent, app = navigator.appVersion;
        //alert(u)
        return {//移动终端浏览器版本信息 
            trident: u.indexOf('Trident') > -1, //IE内核
            isPresto: u.indexOf('Presto') > -1, //opera内核
            isWebKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            isGecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            isMobile: u.indexOf('Mobile') > -1, //是否为手机移动终端
            isChrome: u.indexOf('AppleWebKit') > -1 && u.indexOf('Chrome') > -1
        };
    },    Device: function () {
        var u = navigator.userAgent;        return {
            isS1: u.indexOf("Sony Tablet S") > -1,
            isS2: u.indexOf("Sony Tablet P") > -1
        }
    },
    AndroidVersion: function () {//判断Android系统版本
        var u = navigator.userAgent;        return { isAnroid3x: u.indexOf("Android 3.") > -1 }
    },
    Html5History: function () {//判断浏览器是否支持history.pushstate()        return { supportPushState: "pushState" in history }
    }
};

var HtmlEncoding =  {
    REGX_HTML_ENCODE : /"|&|'|<|>|[\x00-\x20]|[\x7F-\xFF]|[\u0100-\u2700]/g,
    removeHtmlTag: function encodeHtml(s) {
    return (typeof s != "string") ? s :
        s.replace(this.REGX_HTML_ENCODE, ' ');

    }
};

(function($){
    $.fn.cutString = function(option){
        var self = this;
        var _option = {
            limit:58
        };
        $.extend(_option,option || {});
        $(self).each(function(){
            var objString = $(this).text(); 
            var objLength = $(this).text().length; 
            var num = _option.limit;
            
            if(objLength > num){ 
                $(this).attr("title",objString); 
                objString = $(this).text(objString.substring(0,num) + "..."); 
            } 
        });
    };
})(jQuery);
