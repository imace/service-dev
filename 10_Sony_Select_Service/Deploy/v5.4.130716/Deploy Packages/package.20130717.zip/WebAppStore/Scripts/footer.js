﻿var toggleFootSize = function(){
    if(DeviceHelper.isDeviceLanscape()){
        $('footer').removeClass('portrait_fz');
        $('footer').addClass('landscape_fz');
    }else{
        $('footer').removeClass('landscape_fz');
        $('footer').addClass('portrait_fz');
    }
};

var fixFooter = function () { 
    toggleFootSize();
};
$(function () {
    fixFooter();
    window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", function () {
        fixFooter();
    }, false);
});
