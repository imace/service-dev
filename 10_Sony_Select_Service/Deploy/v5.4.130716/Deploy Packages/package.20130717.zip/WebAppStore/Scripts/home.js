﻿var TabsLoader = {
    InitTabs: function (listUrl, detailUrl, downloadUrl) {
        if (window.sessionStorage.getItem('hasOritent') == '1') {
            window.sessionStorage.removeItem('hasOritent');
            $.clearTag('hot-app-content');
            $.clearTag('hot-game-content');
            this._loadTabs(listUrl, detailUrl, downloadUrl,true);
        } else {
            this._loadTabs(listUrl, detailUrl, downloadUrl,false);
        }
    },
    ConvertData: function (contentId,data) {
        var returnData = [];
        $(data).each(function (index, e) {
            var obj = {};
            //alert(e.id);
            if (typeof e.Id != 'undfined') {
                obj.id = e.Id;
            } else {
                obj.id = e.id;
            }
            if (typeof e.Name != 'undfined') {
                obj.name = e.Name;
            } else {
                obj.name = e.name;
            }
            if (typeof e.Size != 'undfined') {
                obj.size = e.Size;
            } else {
                obj.size = e.size;
            }
            if (typeof e.SmallIcon != 'undfined') {
                obj.image = e.SmallIcon;
            } else {
                obj.image = e.image;
            }
            if (typeof e.Description != 'undfined') {
                obj.description = e.Description == null ? '' : e.Description;
            } else {
                obj.description = e.description;
            }
            if (typeof e.Grade != 'undfined') {
                obj.goodstart = parseInt(e.Grade);
                obj.badstart = 5 - obj.goodstart;
                obj.downLoadURL = e.DownLoadURL;
            } else {
                obj.goodstart = e.goodstart;
                obj.badstart = e.badstart;
                obj.downLoadURL = e.downLoadURL;
            }
            obj.contentId = contentId;
            returnData.push(obj);
        });
        return returnData;
    },

    _loadTabs: function (baseUrl, detailUrl, downloadUrl,isLocal) {
        $.Tab(
         [
            { header: 'hot-app', content: 'hot-app-content', url: baseUrl + '?type=app' },
            { header: 'hot-game', content: 'hot-game-content', url: baseUrl + '?type=game' }
         ],
        {
            loading: isLocal==true?'local':'remote',
            getData: function (contentId) {
                if (isLocal == true) {
                    var obj = $.getCachedData(contentId);
                    return obj;
                }
            },
            convertData: function (contentId, data) {
                return TabsLoader.ConvertData(contentId,data);
            },
            onDownloadBtnClicked: function (row) {
                //row为转换后的data
                var contentId = row.contentId;
                pageName = "首页游戏";
                if (contentId == 'hot-app-content') {
                    pageName = "首页应用";
                }
                /*if ($("#hot-app-content").css("display") == "none"); {
                    pageName = "WebHomeGame";
                }*/
                var url = downloadUrl;
                var data = { appId: row.id, pageName: pageName };
                download(url, data);
            },
            onNoDataLoading: function () {
                $('#loading').hide();
                $('#nodata').hide();
            },
            onError: function () {
                $('#loading').hide();
                $('#nodata').show();
            },
            onNoDataLoading: function () {
                $('#loading').hide();
                $('#nodata').hide();
            },
            onSuccess: function () {
                $('.list-content .description').cutString();
                $('#loading').hide();
            },
            onCompleted: function (id) {
                 
            },
            onBeforeLoadData: function () {
                if (isLocal == false) { 
                    $('#loading').show();
                    $('#nodata').hide();
                }
            },
            onGameDetailClicked: function (row) {
                var contentId = row.contentId;
                var type;
                if (contentId == 'hot-app-content') {
                    type = 'WebHomeApp';
                } else {
                    type = 'WebHomeGame';
                }
                window.location.href = detailUrl + "?appId=" + row.id + '&referrerType=' + type;
            },
            iframe: true
        });
    }
}
