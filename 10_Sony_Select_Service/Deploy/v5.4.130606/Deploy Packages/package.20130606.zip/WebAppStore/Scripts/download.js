﻿function download(url, data) {  
    $.ajax({
        url: url,
        data: data,
        cache: false,
        async: false,
        type: "POST",
        dataType: 'text',
        error: function () { 
        },
        success: function (result) {
            window.location.href = result;
        }
    });
}