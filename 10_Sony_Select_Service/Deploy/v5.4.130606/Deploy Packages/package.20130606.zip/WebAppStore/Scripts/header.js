/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

(function ($) {
    $.SearcherBox = {
        version: '1.0',
        init: function () { /**初始化box**/
            if (DeviceHelper.Browser().isMobile) {
                $('#phone').show();
                $('#tablet').remove();
                if ($('.main-search .search-txt').val() != '') {
                    $('.main-search span').hide();
                    $('#search-txt-phone').removeClass('input_search');
                    $('.main-search .clear-search').show();
                }
            } else {
                $('#header .header .logo div').show();
                $('#phone').remove();
                $('#tablet').show();
                if ($('.main-search .search-txt').val() != '') {
                    $('.main-search span').hide();
                    $('#search-txt-tablet').removeClass('input_search');
                    $('.main-search .clear-search').show();
                }
            }
           
        },
        clickSeachInput: function () {
            var mainSearchId = 'main-search';
            var seacherTxtId = 'search-txt';
            if (DeviceHelper.Browser().isMobile) {
                mainSearchId += '-phone';
                seacherTxtId += '-phone';
            } else {
                seacherTxtId += '-tablet';
                mainSearchId += '-tablet';
            }
            $(document).unbind('click');
            $(document).bind('click',function (event) {
                var mx1 = $('#'+mainSearchId).offset().left;
                var my1 = $('#' + mainSearchId).offset().top;
                var width = $('#' + mainSearchId).width();
                var height = $('#' + mainSearchId).height();
                var x = event.pageX;
                var y = event.pageY;
                if (x >= mx1 && x <= parseFloat(mx1 + width) && y >= my1 && y <= my1 + height) {
                    //在点击范围内
                    $('#' + mainSearchId+' span', this).hide();
                    $('#' + mainSearchId+' .search-txt', this).get(0).focus();
                    $('#'+seacherTxtId).removeClass('input_search');
                } else {
                    if ($('#'+mainSearchId+' .search-txt').val() == '') {
                        $('#'+mainSearchId+' span').show();
                        $('#' + seacherTxtId).addClass('input_search');
                    }
                }
            });
        },
        
        showBg: function () {
            
            if (DeviceHelper.Browser().isMobile) {
                //alert($('#phone .search-input').is(':hidden'));
                if ($('#phone .search-input').is(':hidden') == true) {
                    $('#phone .search-input').show(100);
                    $('#header .header .logo div').hide();
                    $('#phone .show_control div.contrl-img').removeClass('searchbg');
                    $('#phone .show_control div.contrl-img').addClass('backbg');
                } else {
                    $('#phone .search-input').hide();
                    $('#header .header .logo div').show();
                    $('#phone .show_control div.contrl-img').removeClass('backbg');
                    $('#phone .show_control div.contrl-img').addClass('searchbg');
                }
            }
        },
        show: function () {
            $('#phone .search-input').show(0);
            if (DeviceHelper.Browser().isMobile){
                $('#header .header .logo div').hide();
            }
            $('#phone .show_control div.contrl-img').removeClass('searchbg');
            $('#phone .show_control div.contrl-img').addClass('backbg');
        },
        bindSeachClick: function () {
            if (DeviceHelper.Browser().isMobile) {
                //alert(DeviceHelper.isDeviceLanscape())
               
                $('#phone .show_control div').bind('click', function (event) {
                    $.SearcherBox.showBg();
                });
            }
            $('.main-search .clear-search').bind('click', function (event) {
                $('.search-txt').val('');
                $('.main-search' + ' span').show();
                $('.search-txt').addClass('input_search');
                $(this).hide();
            });
        },
        changeSize: function () {
            if (DeviceHelper.isDeviceLanscape()) {
                /*$('input.search-txt').css('width', '380px');
                $('div.searcher .main-search').css('width', '420px');*/
                $('div.searcher .main-search').removeClass('main-search-width');
                $('div.searcher .main-search').addClass('main-search-width-landscape');
            } else {
                $('div.searcher .main-search').removeClass('main-search-width-landscape');
                $('div.searcher .main-search').addClass('main-search-width');
            }
        },

        submitForm: function () {
            var seacherTxtId = 'search-txt';
            if (DeviceHelper.Browser().isMobile) {
                seacherTxtId += '-phone';
            } else {
                seacherTxtId += '-tablet';
            }
            var keywords = $('#' + seacherTxtId).val();
            keywords = HtmlEncoding.removeHtmlTag(keywords);
            $('#' + seacherTxtId).val(keywords);
            if (keywords.trim() != "" && keywords != "输入应用或游戏名称搜索")
            {
                var forwardKey = $("#ForwardKeyValue").val();
                $("#SearchKeyValue").val(keywords);
                $(function () {
                    setTimeout(function () {
                        $('#' + seacherTxtId).val(forwardKey);
                    }, 1000);
                })
                document.forms["searchForm"].submit();
            } else
            {
                return false;
            }
          

            return true;
        }

    }
})(jQuery);
function check(event) {
    //alert('');
    if (event.keyCode == 13)
    {

        $.SearcherBox.submitForm();
    }
}



//function checkcomplete()
//{
//    if ($("#search-txt-tablet").attr("autocomplete") != "on")
//    {
//        $("#search-txt-tablet").attr("autocomplete", "on")
//    }
//}



$(function () {
    //alert(window.screen.width + ' ' + window.screen.height + ' ' + window.devicePixelRatio);
    $.SearcherBox.init();
    $.SearcherBox.bindSeachClick();
    $.SearcherBox.clickSeachInput();
    $.SearcherBox.changeSize();
    window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", function () {
        $.SearcherBox.clickSeachInput();
        $.SearcherBox.changeSize();
        
    }, false);

    if ($(".search-btn").length > 0) {
        $(".search-btn").click(function ()
        {
            $.SearcherBox.submitForm();
        });
    }
   
});
