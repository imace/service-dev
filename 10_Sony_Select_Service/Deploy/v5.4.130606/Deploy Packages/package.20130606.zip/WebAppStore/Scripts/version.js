﻿var Version = {
    version: '5.4.130606(5.4.A.0.4)'
};

$(function () {
    $('footer').append('<div class="right">' + Version.version + '</div>');
});