/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 封装所有交易公共库
 * @Author:Chris Cheng（程天亮）
 */

//模板渲染类，渲染模板，嵌套模板
function Renderer(templateId, data) {
    this.templateId = templateId;
    this.data = data;
    if (typeof this._getNestTemplateId != 'function') {
        this._getNestTemplateId = function () {
            var tmplate = $('#' + templateId).html();
            var reg = /#(\w+?)#/;
            var templateIds = reg.exec(tmplate);
            if (templateIds && templateIds != null) {
                if (templateIds.length > 1) {
                    return templateIds[1];
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    if (typeof this.renderOnlyNest != 'function') {
        this.renderOnlyNest = function (onPostRender, onRowRendered) {
            var nestTemplateId = this._getNestTemplateId();
            var tid;
            if (nestTemplateId == false) {
                tid = this.templateId;
            } else {
                tid = nestTemplateId;
            }
            //alert(tid);
            var html = this._render(tid, onRowRendered);
            if (typeof onPostRender == 'function') {
                onPostRender(this.data,html);
            }
        }
    }

    if (typeof this._nestRender != 'function') {
        this._nestRender = function (nestTemplateId, onPostRender, onRowRendered) {
            var templateHtml = $('#' + templateId).clone().html();
            var nestHtml = this._render(nestTemplateId, onRowRendered);
            templateHtml = templateHtml.replace(new RegExp('#' + nestTemplateId + '#'), nestHtml);
            if (typeof onPostRender == 'function') {
                onPostRender(this.data, templateHtml);
            }
        }
    }
    if (typeof this._render != 'function') {
        //渲染模板，返回渲染后的值
        this._render = function (tid, onRowRendered) {
            //使用模板渲染
            /***
             * 约定：如果使用template渲染时，模板参数必须是__DATA的大写名字__
             * 
             */
            var docArray = [];
            $(data).each(function (index, row) {
                if(row && row!=null){
                    var html = $('#' + tid).clone().html();
                    for (var attribute in row) {
                        var regPattern = '__' + attribute.toUpperCase() + '__';
                        var regObj = new RegExp(regPattern, 'g');
                        var value = row[attribute];
                        if(value=='null' || value==null){
                            value = '';
                        }
                        html = html.replace(regObj, value);
                    }
                    html = html.replace(/__INDEX__/,index);
                    if (typeof onRowRendered == 'function') {
                        html = onRowRendered(html,row);
                    }
                    docArray.push(html);
                }
            });
            var doc = docArray.join('');
            return doc;
        }
    }
    if (typeof this.render != 'function') {
        this.render = function (onPostRender,onRowRendered) {
            var nestTemplateId = this._getNestTemplateId();
            if (nestTemplateId != false) {
                this._nestRender(nestTemplateId, onPostRender, onRowRendered);
            } else {
                var html = this._render(this.templateId, onRowRendered);
                if (typeof onPostRender == 'function') {
                    onPostRender(this.data, html);
                }
            }
        }
    }
}


(function($){
    $.Process = function(option){
        
        /**
         * 默认属性
         */
        var _option = {
            loading: 'local',
            id:"",/*id为特定标志*/
            params: "",
            url: '',
            cache:false,
            iframe: false,
            templateId:'',
            useJsonContentType:false,
            timeout:500,
            getData: function (id) {/*id为特定标志*/
                return []
            },
            onSuccess:function(id,data){},/*渲染成功后调用*/
            onError: function (id) { },
            beforeRender:function(data){},/*渲染之前回调*/
            onRender: function (id, data) { },/*渲染回调*/
            onRowRendered: function (html, rowData) { },
            async : false,
            convertData: function (id, data) {
                return data;
            }
        };
        $.extend(_option, option || {});

        if (_option.loading == 'local') {
            loadByLocal();
        } else if (_option.loading == 'remote') {
            _option.iframe == true ? loadByFrame() : loadByAjax();
        }

        function loadByAjax(){
            var pObj = {
                url: _option.url,
                type: "POST",
                dataType: 'json',
                timeout:_option.timeout,
                error:function(){
                    _option.onError(_option.id)
                },
                success:function(data){
                    data = _option.convertData(_option.id, data);
                   
                    render(data);
                    _option.onSuccess(_option.id, data);
                }

            };
            if(_option.params){
                pObj.data=_option.params;
            }
            if(_option.useJsonContentType == true){
                pObj.contentType="application/json; charset=utf-8";
            }
            pObj.cache = _option.cache;
            pObj.async = _option.async;
            //alert(pObj.data);
            $.ajax(pObj);
        }
        
        function loadByFrame(){
            var loadingUrl = _option.url;
            var index = loadingUrl.indexOf('?');
            if (index != -1) {
                //loadingUrl.replace('?', '?' + (new Date()).valueOf()+'&');
                loadingUrl += "&" + _option.params;
            } else {
                loadingUrl += '?' + _option.params;
            }
            loadingUrl += '&timed=' + (new Date()).valueOf();
            var idname = (new Date()).valueOf();
            $('body').data('iframe-id', idname);
            //alert(loadingUrl)
            var iframe = $('<iframe>',{
                src: loadingUrl,
                id: 'load-iframe-' + idname,
                name: 'iframe_' + idname
            });
            iframe.css('display', 'none');
            var frame = iframe.get(0);
            if (frame.attachEvent){ 
                frame.attachEvent("onload", function () {
                    loadFrameContent();
                }); 
            } else { 
                frame.onload = function(){
                    loadFrameContent();
                }; 
            }
            iframe.appendTo('body');
        }
        
        function loadByLocal(){
            var data = _option.getData(_option.id);
            render(data);
            _option.onSuccess(_option.id, data);
        }
        
        function render(data){
            if(_option.templateId){
                //使用模板渲染
                /***
                * 约定：如果使用template渲染时，模板参数必须是__DATA的大写名字__
                * 
                */
                var renderer = new Renderer(_option.templateId, data);
                renderer.render(function (html) {
                    _option.onRender(_option.id, html);
                }, function (rowHtml,rowData) {
                    _option.onRowRendered(rowHtml,rowData);
                });
               
            } else {
                _option.onRender(_option.id, data);
            }
        }
        
        /**
         * 加载iframe中的内容
         */
        function loadFrameContent() {
            var idname = $('body').data('iframe-id');
            var dataStr = $(document.getElementById('load-iframe-' + idname).contentWindow.document.body).html();
            //alert(dataStr);
            try{
                var data = $.parseJSON(dataStr);
                data = _option.convertData(_option.id, data);
                render(data);
                _option.onSuccess(_option.id, data);
            }catch(e){
                _option.onError(_option.id);
            }
            
            $('#load-iframe-' + idname).remove();
        }
    };
})(jQuery);


