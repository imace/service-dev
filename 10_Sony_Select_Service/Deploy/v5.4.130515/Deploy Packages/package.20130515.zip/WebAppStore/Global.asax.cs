﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using PlayNow.Models.Utils;

namespace PlayNow
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            log4net.Config.DOMConfigurator.Configure();
            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            CacheSyncScheduler.LoadCache();
            CacheSyncScheduler.Start(Configuration.GetCacheScheduleAbsoluteMin(), Configuration.GetCacheScheduleTriggerHour()
                , Configuration.GetCacheScheduleIntervalMin());
        }

        protected void Application_PreRequestHandlerExecute(object sender, EventArgs e)
        {
            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("zh-cn");
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("zh-cn");
        }

        protected void Application_End(Object sender, EventArgs e)
        {
            CacheSyncScheduler.Stop();
        }
    }
}