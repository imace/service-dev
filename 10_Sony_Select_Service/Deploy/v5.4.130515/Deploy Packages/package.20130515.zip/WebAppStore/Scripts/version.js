﻿var Version = {
    version:'v1.2.10.0'
};

$(function () {
    $('footer').append('<div class="right">' + Version.version + '</div>');
});