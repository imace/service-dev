﻿(function ($) {
    $.ScreenShot = {
        Run: function () {
            if (arguments.length < 2) {
                return false;
            }
            var args = Array.prototype.slice.call(arguments);
            var obj = args[0];
            var option = args[1];
            $(obj).css('overflow-x', 'hidden');
            $(obj).css('position','relative');
            var template = option.template.call(obj);
            $(obj).append(template);
            this.preRender.apply(this, args);

            $(obj).get(0).addEventListener('touchstart', function (event) {
                $.ScreenShot.touchstart(event,obj,option.data.length);
            }, false);
            $(obj).get(0).addEventListener('touchmove', function (event) {
                $.ScreenShot.touchmove(event, obj,option.data.length);
            }, false);
            $(obj).get(0).addEventListener('touchend', function (event) {
                $.ScreenShot.touchend(event, obj, option.data.length);
            }, false);
            $('img', obj).each(function (index, ele) {
                var index = $(this).attr('index');
                $(this).preLoadImg($(this).attr('data'), {
                    loaded: function (ele, src, width, height) {
                        ele.attr('src', src);
                        if (typeof option.onImageLoaded == 'function') {
                            option.onImageLoaded(ele, width, height);
                        }
                    }
                });
            });

        },
        touchstart: function (event, obj) {
            var imgWidth = $('img', obj).css('width');
            if (imgWidth == null) {
                imgWidth = $('img', obj).width();
            }
            var length = $('img', obj).length;
            //alert(imgWidth + ' width=' + $(obj).width());
            if (length * parseInt(imgWidth)+10 <= $(obj).width()) {
                return false;
            }
            var innerObj = $('#inner-screen', obj);
            $(obj).data('startx', event.touches[0].pageX);

        },
        touchmove: function (event, obj, len) {
            var innerObj = $('#inner-screen', obj);
            var beginX = $(obj).data('startx');
            if (beginX == null || beginX == undefined) {
                return false;
            }
            var movePx = event.touches[0].pageX;
            var duration = movePx - beginX;
            var innerLeft = $(innerObj).css('left');
            var imgWidth = $('img', obj).width();
            var position = parseInt(innerLeft) + parseInt(imgWidth) * len;
            if (position < $(obj).width()) {
                //alert($(obj).width() - imgWidth)
                //$(innerObj).css('left', innerLeft + $(obj).width()-imgWidth );
                //alert(position);
                var pp = $(obj).width() - position;
                $(innerObj).css('left', parseInt(innerLeft) + parseInt(pp));
                $(obj).data('stop', 1);
                return false;
            } else {
                if (parseInt(innerLeft) + duration > 0) {
                    $(innerObj).css('left',0);
                    $(obj).data('stop', 1);
                    return false;
                }
            }
            $(innerObj).css('left', parseInt(innerLeft) + parseInt(duration));
            $(obj).data('startx', movePx);
        },
        touchend: function (event, obj, len) {
            if (beginX == null || beginX == undefined) {
                return false;
            }
            if ($(obj).data('stop') == 1) {
                $(obj).removeData('startx');
                $(obj).removeData('stop');
                return false;
            }
            var innerObj = $('#inner-screen', obj);
            var beginX = $(obj).data('startx');
            var movePx = beginX;
            if (event.touches[0] != undefined) {
                movePx = event.touches[0].pageX;
            }
            //var movePx = event.touches[0].pageX== || (movePx=beginX);
            if (movePx != beginX) {
                var duration = movePx - beginX;
                var innerLeft = $(innerObj).css('left');
                $(innerObj).css('left', parseInt(innerLeft) + parseInt(duration));
            }
            $(obj).removeData('startx');
        },
        preRender: function () {
            var obj = arguments[0];
            var option = arguments[1];
            var data = option.data;
            var imgs = [];
            $(data).each(function (index, ele) {
                imgs.push('<img src="' + option.defaultImg + '" onerror="javascript:this.src=\''+option.defaultImg+'\'" index="'+index+'"  id="screenshot_'+index+'" class="'+option.cls+'" data="'+ele+'" style="display:inline-block"/>');
            });
            var imgss = imgs.join('');
            $('#inner-screen', obj).append(imgss);
            //alert(obj.html());
        },
        template: function () {
            return '<div id="inner-screen" style="width:900%;position:absolute;left:0"></div>';
        }
    }
    $.fn.screenShot = function (option) {
        var _option = $.extend({
            data: [],
            cls: 'screen-shot-bannerImgCls',
            imgStyle: 'screen-img',
            defaultImg: '',
            template:$.ScreenShot.template,
            onImageLoaded: function () { },
        }, option || {});
        var self = this;
        
        $.ScreenShot.Run(self, _option);
    }
})(jQuery);