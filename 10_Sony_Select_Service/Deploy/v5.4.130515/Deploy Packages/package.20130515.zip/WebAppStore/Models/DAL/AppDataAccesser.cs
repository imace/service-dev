﻿using PlayNow.Models;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;


namespace PlayNow.Models.DAL
{
    public class AppDataAccesser : IAppDataAccesser
    {

        private String playNowServiceUrl = Configuration.GetPlayNowServiceUrl();

        private log4net.ILog log = log4net.LogManager.GetLogger("testApp.Logging");

        public string GetAppDetail(string appId, string machineType)
        {
            Dictionary<string, object> paramsDic = new Dictionary<string, object>();
            paramsDic.Add("method", "app.getDetail");
            paramsDic.Add("appId", appId);
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);

            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            return RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);
        }

         
        public string GetAppList(string machineType, int startIndex, int returnNum)
        {
            Dictionary<string, object> paramsDic = new Dictionary<string, object>();
            paramsDic.Add("method", "app.getList");
            paramsDic.Add("appRecommendationId", 100);
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("startIndex", startIndex);
            paramsDic.Add("returnNum", returnNum);
            paramsDic.Add("withDesc", "1");
            paramsDic.Add("withType", "1");
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            string sig = DigitalSignature.GenerateSignature(paramsDic);//签名字符串
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);
            return json;
        }

         
        public string GetBannerList(string machineType)
        {
            Dictionary<string, object> paramsDic = new Dictionary<string, object>();
            paramsDic.Add("method", "app.getBannerList");//接口方法app.getBannerList
            //paramsDic.Add("count", count);//输入参数
            paramsDic.Add("machineType", machineType);//输入参数
            //paramsDic.Add("IMSI", IMSI);//输入参数
            paramsDic.Add("PlatformType", "web");
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            paramsDic.Add("version", "1");
            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);
            return json;
        }

        public AppListResult GetRecommendedAppList(int appType, string machineType, int startIndex, int returnNum)
        {
            AppListResult appList = new AppListResult();

            Dictionary<string, object> paramsDic = new Dictionary<string, object>();
            paramsDic.Add("method", "app.getFreeAppList");
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("appType", appType);
            paramsDic.Add("order", "desc");
            paramsDic.Add("startIndex", startIndex);
            paramsDic.Add("returnNum", returnNum);
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            paramsDic.Add("withDesc", "1");
            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;

            log.Info(DateTime.Now.ToString() + "_GetRecommendedAppList_paramsBytes : " + postdata);

            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);

            log.Info(DateTime.Now.ToString() + "_GetRecommendedAppList_json : " + json);

            appList = JSONHelper.JsonDeserialize_JsonTo<AppListResult>(json);

            log.Info(DateTime.Now.ToString() + "_GetRecommendedAppList_AppListResult : ResultCode/TotalCount = " + appList.ResultCode + "/" + appList.TotalCount);
            
            return appList;
        }

        public SearchAppListResult GetAppListByKeyword(string keyword, string machineType, int startIndex, int returnNum, int baiduCacheIndex)
        {
            SearchAppListResult appList = new SearchAppListResult();

            Dictionary<string, object> paramsDic = new Dictionary<string, object>();

            paramsDic.Add("method", "app.getNewSearchContent");
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("keyword", keyword);
            paramsDic.Add("startIndex", startIndex);
            paramsDic.Add("returnNum", returnNum);
            paramsDic.Add("IMSI", "");
            paramsDic.Add("IMEI", "");
            paramsDic.Add("AndroidVer", "4.1.1");
            paramsDic.Add("EdreamVer", "10.1.C.0.172");
            paramsDic.Add("ClientVer", "5.2.1");
            paramsDic.Add("BaiduCacheIndex", baiduCacheIndex);
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            paramsDic.Add("withDesc", "1");
            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;

            log.Info(DateTime.Now.ToString() + "_GetAppListByKeyword_paramsBytes : " + postdata);

            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);

            log.Info(DateTime.Now.ToString() + "_GetAppListByKeyword_json : " + json);

            appList = JSONHelper.JsonDeserialize_JsonTo<SearchAppListResult>(json);

            log.Info(DateTime.Now.ToString() + "_GetAppListByKeyword_SearchAppListResult : ResultCode/TotalCount/BaiduStartIndex = " + appList.ResultCode + "/" + appList.TotalCount + "/" + appList.BaiduStartIndex);

            return appList;
        }

        public DownloadParam GetDownloadParam(string appId, string machineType, string pageName, string intentFromId, string contendId, string userName)
        {
            DownloadParam downloadParam = new DownloadParam();

            Dictionary<string, object> paramsDic = new Dictionary<string, object>();

            paramsDic.Add("ContentId", contendId);
            paramsDic.Add("IntentFromId", intentFromId);
            paramsDic.Add("androidver", "");
            paramsDic.Add("appId", appId);
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            paramsDic.Add("clientVer", "web");
            paramsDic.Add("edreamver", "");
            paramsDic.Add("imei", "");
            paramsDic.Add("imsi", "null");
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("method", "app.getNewDownUrl");
            paramsDic.Add("pageName", pageName);
            paramsDic.Add("userName", userName); 
            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);

            log.Info(DateTime.Now.ToString() + "params={"+postdata + "}  _GetAppListByKeyword_json : " + json);

            downloadParam = JSONHelper.JsonDeserialize_JsonTo<DownloadParam>(json);

            return downloadParam;
        } 

        public LawClause GetLawClause(string machineType)
        {
            LawClause lawClause = new LawClause();
            Dictionary<string, object> paramsDic = new Dictionary<string, object>();
            paramsDic.Add("method", "clause.getLaw");
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);
            lawClause = JSONHelper.JsonDeserialize_JsonTo<LawClause>(json);

            return lawClause;
        }

        public String[] GetSupportedMachineTypes()
        {
            Dictionary<string, object> paramsDic = new Dictionary<string, object>();

            paramsDic.Add("imei", "");
            paramsDic.Add("imsi", "null");
            paramsDic.Add("clientVer", "WEB");
            paramsDic.Add("edreamver", "");
            paramsDic.Add("androidver", "");
            paramsDic.Add("method", "app.getAllMachineTypes");

            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);

            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            string json = RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);
            MachineType machineType = JSONHelper.JsonDeserialize_JsonTo<MachineType>(json);
            return machineType.MachineTypes.ToArray<string>();
        }

        public string WriteLogInfo(string machineType, string logType, string message)
        {
            if (!Configuration.WriteLog())
            {
                return "";
            }
            Dictionary<string, object> paramsDic = new Dictionary<string, object>();
            paramsDic.Add("method", "log.addInfo");
            paramsDic.Add("machineType", machineType);
            paramsDic.Add("appkey", DigitalSignature.CONFIG_APPKEY);
            paramsDic.Add("type", logType);
            paramsDic.Add("message", message);
            string sig = DigitalSignature.GenerateSignature(paramsDic);
            string postdata = "";
            foreach (string key in paramsDic.Keys)
            {
                postdata += key + "=" + HttpUtility.UrlEncode(paramsDic[key].ToString(), Encoding.UTF8) + "&";
            }
            postdata += "sig=" + sig;
            byte[] paramsBytes = Encoding.UTF8.GetBytes(postdata);
            return RequestHttp.RequestAPIData(playNowServiceUrl, paramsBytes);
        }
    }
}