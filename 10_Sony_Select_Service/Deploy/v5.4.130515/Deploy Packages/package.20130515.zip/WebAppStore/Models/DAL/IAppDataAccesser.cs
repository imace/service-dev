﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.DAL
{
    public interface IAppDataAccesser
    {
        /// <summary>
        /// 获取商品详情
        /// </summary>
        /// <param name="intAppId">商品Id</param>
        /// <returns>Json</returns>
        string GetAppDetail(string appId, string machineType);

        /// <summary>
        /// Gets the app list.
        /// </summary>
        /// <param name="appRecommendationId">The app recommendation id.</param>
        /// <param name="machineType">Type of the machine.</param>
        /// <param name="startIndex">The start index.</param>
        /// <param name="endIndex">The end index.</param>
        /// <returns></returns>
        /// <remarks>
        /// </remarks>
        string GetAppList(string machineType, int startIndex, int returnNum);

        /// <summary>
        /// Gets the banner list.
        /// </summary>
        /// <param name="machineType">Type of the machine.</param>
        /// <returns></returns>
        /// <remarks>
        /// </remarks>
        string GetBannerList(string machineType);

        /// <summary>
        /// Search app list by keyword from baidu and playnow
        /// </summary>
        /// <param name="keyword">search keyword</param>
        /// <param name="machineType">Type of the machine.</param>
        /// <param name="startIndex">The start index.</param>
        /// <param name="returnNum">Limit the number of returned result</param>
        /// <returns>AppListResult</returns>
        /// <remarks>
        /// </remarks>
        SearchAppListResult GetAppListByKeyword(string keyword, string machineType, int startIndex, int returnNum, int baiduCacheIndex);

        /// <summary>
        /// Search recommended app list by keyword from playnow
        /// </summary>
        /// <param name="appType">app's type</param>
        /// <param name="machineType">Type of the machine.</param>
        /// <param name="startIndex">The start index.</param>
        /// <param name="returnNum">Limit the number of returned result</param>
        /// <returns>AppListResult</returns>
        /// <remarks>
        /// </remarks>
        AppListResult GetRecommendedAppList(int appType, string machineType, int startIndex, int returnNum);

        /// <summary>
        /// Get Download Param by appId
        /// </summary> 
        /// <param name="intAppId">商品Id</param>
        /// <param name="machineType">Type of the machine.</param>
        /// <param name="pageName">页面名称</param>
        /// <param name="intentFromId">下载来源入口标志，
        ///       1 表示widget
        ///       2 表示playnow
        ///       3 表示百度
        ///       4 表示消息推送
        ///</param>
        /// <param name="contendId">当IntentFromId为消息推送时，赋值MessageId，否则置为0</param> 
        /// <returns>DownloadParam</returns>
        /// <remarks>
        /// </remarks>
        DownloadParam GetDownloadParam(string appId, string machineType, string pageName, string intentFromId, string contendId, string userName);

        /// <summary>
        /// Get Clause of law.
        /// </summary>
        /// <param name="machineType">Type of the machine.</param>
        /// <returns></returns>
        /// <remarks>
        /// </remarks>
        LawClause GetLawClause(string machineType);

        /// <summary>
        /// Get Supported Machine Types
        /// </summary>
        /// <returns>Machine Type Array</returns>
        String[] GetSupportedMachineTypes();

        /// <summary>
        /// 记录页面访问日志
        /// </summary>
        /// <param name="machineType">Type of the machine.</param>
        /// <param name="logType">日志的类型
        /// 1、	页面访问日志
        /// 2、	消息获取日志
        /// 3、	升级管理日志
        /// 4、	下载日志
        /// 21、Default Web Page页面访问日志
        /// </param>
        /// <param name="message">日志的信息</param>
        /// <returns></returns>
        string WriteLogInfo(string machineType, string logType, string message);
    }
}