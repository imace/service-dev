﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class SearchContent
    {
        public string ResultCode { get; set; }
        public int TotalCount { get; set; }
        public int BaiduCacheIndex { get; set; }
        public List<AppInfo> PlayNowAppInfoList { get; set; }
        public List<AppInfo> BaiduAppInfoList { get; set; }
        public List<AppInfo> RecommendedAppInfoList { get; set; }
    }
}
