﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class AppListResult
    {
        public string ResultCode { get; set; }
        public int TotalCount { get; set; }
        public List<AppInfo> AppInfoList { get; set; }
    }
}
