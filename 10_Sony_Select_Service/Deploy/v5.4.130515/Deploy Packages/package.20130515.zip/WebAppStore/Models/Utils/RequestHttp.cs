﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

namespace PlayNow.Models.Utils
{
    public class RequestHttp
    {
        /// <summary>
        /// Post请求远程API返回XML字符串
        /// </summary>
        /// <param name="strApiUrl">API地址</param>
        /// <param name="bytData">参数</param>
        /// <returns>string</returns>
        public static string RequestAPIData(string strApiUrl, byte[] bytData)
        {
            try
            {
                //HTTP请求
                HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(strApiUrl);
                if (Configuration.IsNeedProxy())
                {
                    System.Net.WebProxy proxy = new WebProxy(Configuration.GetProxy(), Configuration.GetProxyPort());
                    httpRequest.Proxy = proxy;
                    
                }
                httpRequest.Method = "POST";
                httpRequest.ContentType = "application/x-www-form-urlencoded";

                if (bytData != null && bytData.Length > 0)
                {
                    //填充要post的内容
                    httpRequest.ContentLength = bytData.Length;
                    Stream requestStream = httpRequest.GetRequestStream();
                    requestStream.Write(bytData, 0, bytData.Length);
                    requestStream.Close();
                }

                //HTTP响应
                HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                //HTTP响应字符流
                StreamReader srReader = new StreamReader(httpResponse.GetResponseStream(), Encoding.UTF8);
                string strContent = srReader.ReadToEnd();
                httpResponse.Close();

                return strContent;
            }
            catch (Exception ex)
            {
                //Utility.LogHelper.LogError("操作:BLL.RequestAPIData获取接口XML.方法名:RequestAPIData.错误:" + ex.Message);
                // return ex.Message;
                throw ex;
            }
        }

        /// <summary>
        /// Get请求远程API返回XML字符串
        /// </summary>
        /// <param name="strApiUrl">API地址</param>
        /// <returns>string</returns>
        public static string RequestAPIData(string strApiUrl)
        {
            try
            {
                //HTTP请求
                HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(strApiUrl);
                httpRequest.Method = "GET";
                httpRequest.ContentType = "application/x-www-form-urlencoded";

                //HTTP响应
                HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                //HTTP响应字符流
                StreamReader srReader = new StreamReader(httpResponse.GetResponseStream(), Encoding.UTF8);
                string strContent = srReader.ReadToEnd();
                httpResponse.Close();

                return strContent;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 获取请求返回的内容的长度(文件大小bit)
        /// </summary>
        /// <param name="strUrl">请求地址</param>
        /// <returns>long</returns>
        public static long RequestLength(string strUrl)
        {
            try
            {
                //HTTP头信息请求
                HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(strUrl);
                httpRequest.Method = "HEAD";
                httpRequest.Timeout = 3000;
                httpRequest.ContentType = "application/x-www-form-urlencoded";

                //HTTP响应
                HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                long lngContent = httpResponse.ContentLength;
                httpResponse.Close();

                if (lngContent < 0)
                {
                    return 0;
                }

                return lngContent;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        /// <summary>
        /// 参数ascii转义字节数组
        /// </summary>
        /// <param name="strData">地址参数</param>
        /// <returns>byte[]</returns>
        public static byte[] ConverData(string strData)
        {
            Encoding encoding = Encoding.GetEncoding("ascii");
            byte[] bytTopost = encoding.GetBytes(strData);
            return bytTopost;
        }

    }
}
