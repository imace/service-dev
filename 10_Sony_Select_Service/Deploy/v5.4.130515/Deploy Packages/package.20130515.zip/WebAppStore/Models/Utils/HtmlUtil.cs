﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.Utils
{
    public class HtmlUtil
    {
        private const String LT = "<";
        private const String GT = ">";
        private const String ENTER = "\n";
        private const String ENTERFULL = "\n\r";
        private const String SPACE = " ";

        private const String LTHTML = "&lt;";
        private const String GTHTML = "&gt;";
        private const String ENTERHTML = "<br/><br/>";
        private const String SPACEHTML = "&nbsp;";

        public static string TextTohtml(string chr)
        {
            if (chr == null)
                return "";
            chr = chr.Replace(LT, LTHTML);
            chr = chr.Replace(GT, GTHTML);
            chr = chr.Replace(ENTER, ENTERHTML);
            chr = chr.Replace(ENTERFULL, ENTERHTML);
            chr = chr.Replace(SPACE, SPACEHTML);
            return (chr);
        }

    }
}