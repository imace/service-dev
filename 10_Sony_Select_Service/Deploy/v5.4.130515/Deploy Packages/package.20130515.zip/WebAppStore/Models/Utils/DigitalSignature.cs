﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.IO.Compression;
using System.Web;

namespace PlayNow.Models.Utils
{
    /// <summary>
    /// 数字签名
    /// </summary>
    /// <remarks>
    /// </remarks>
    public class DigitalSignature
    { 
        public const string CONFIG_APPKEY = "4d51779a91f16c3b";

        public const string CONFIG_SECURITYKEY = "705582a3db9bd2ee";

        /// <summary>
        /// 生成数字签名
        /// </summary>
        /// <param name="paramsDic">参数值数据字典</param>
        public static string GenerateSignature(Dictionary<string, object> paramsDic)
        {
            string[] keyArr = new string[paramsDic.Count];
            paramsDic.Keys.CopyTo(keyArr, 0);
            LetterSort(ref keyArr);
            string str = "";
            for (int i = 0; i < keyArr.Length; i++)
            {
                str += keyArr[i] + paramsDic[keyArr[i]].ToString();
            }
            str = System.Web.HttpUtility.UrlEncode(str, Encoding.UTF8);
            str = str.Replace("!", "%21");
            str = str.Replace("(", "%28");
            str = str.Replace(")", "%29");
            str += CONFIG_SECURITYKEY;
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();

            byte[] data = sha1.ComputeHash(Encoding.UTF8.GetBytes(str));
            StringBuilder sb = new StringBuilder();
            foreach (byte @byte in data)
            {
                sb.AppendFormat("{0:x2}", @byte);
            }
            return sb.ToString();



        } 

        /// <summary>
        /// 字典排序
        /// </summary>
        /// <param name="keyArr">待排序数组</param>
        public static void LetterSort(ref string[] keyArr)
        {
            for (int j = 0; j < keyArr.Length; j++)
            {
                for (int i = 0; i < keyArr.Length - j - 1; i++)
                {
                    if (string.CompareOrdinal(keyArr[i], keyArr[i + 1]) > 0)
                    {
                        string temp = keyArr[i];
                        keyArr[i] = keyArr[i + 1];
                        keyArr[i + 1] = temp;
                    }
                }
            }
        }
         
    }
     
}

