﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.Utils
{
    public class Configuration
    {

        public static bool IsNeedProxy() {
            return bool.Parse(GetValue("proxy"));
        }

        public static String GetProxy()
        {
            return GetValue("proxyaddress");
        }

        public static int GetProxyPort()
        {
            return int.Parse(GetValue("proxyport"));
        }

        public static String GetPlayNowServiceUrl()
        {
            return GetValue("playnowserviceurl");
        }

        public static int GetCacheScheduleAbsoluteMin()
        {
            return Convert.ToInt32(GetValue("cache_schedule_absolute_minute"));
        }

        public static String GetCacheScheduleTriggerHour()
        {
            return GetValue("cache_schedule_trigger_hour");
        }

        public static bool WriteLog()
        {
            return bool.Parse(GetValue("writeLog"));
        }

        public static int GetCacheScheduleIntervalMin()
        {
            return Convert.ToInt32(GetValue("cache_schedule_interval_minute"));
        }

        private static String GetValue(String key) {
            return System.Configuration.ConfigurationManager.AppSettings[key].ToString();
        }
    }
}