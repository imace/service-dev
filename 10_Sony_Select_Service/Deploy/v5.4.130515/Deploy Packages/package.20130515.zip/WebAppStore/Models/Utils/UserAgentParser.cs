﻿using PlayNow.Models.BLL;
using System;
using System.Text.RegularExpressions;
using System.Web;

namespace PlayNow.Models.Utils
{
    public class UserAgentParser
    {
        private static String DEFAULT_MACHINE_TYPE = "LT26i";

        /*Used to test*/
        // private static string agent = "Mozilla/5.0 (Linux;U;Android 4.1.1;en-us;Sony4dp06g Build/10.1.C.0.172) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30";

        public static String GetMachineType(String ua)
        {
            if (String.IsNullOrEmpty(AppCache.MachineTypes))
            {
                PlayNowManagerCreator.GetCacheLoader().LoadMachineTypes();
            }
            Regex regex = new Regex(AppCache.MachineTypes, RegexOptions.IgnoreCase);
            if (String.IsNullOrEmpty(ua)) return DEFAULT_MACHINE_TYPE;
            Match match = regex.Match(ua);
            return match.Success ? match.Value : DEFAULT_MACHINE_TYPE;
        }
       
    }
}