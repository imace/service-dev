﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class AppCache
    {
        private static Dictionary<string, List<AppInfo>> appCache = new Dictionary<string, List<AppInfo>>();

        private static Dictionary<string, List<AppInfo>> gameCache = new Dictionary<string, List<AppInfo>>();

        private static Dictionary<string, List<AppInfo>> recommendedAppCache = new Dictionary<string, List<AppInfo>>();

        private static Dictionary<string, List<BannerInfo>> bannerCache = new Dictionary<string, List<BannerInfo>>();

        private static LawClause lawClauseCache = null;

        public static string MachineTypes { get; set; }

        public static void PutAppList(string machineType, List<AppInfo> appList)
        {
            if (appCache.ContainsKey(machineType))
            {
                appCache.Remove(machineType);
            }
            appCache.Add(machineType, appList);
        }

        public static List<AppInfo> GetAppList(string machineType)
        {
            return appCache.ContainsKey(machineType) ? appCache[machineType] : new List<AppInfo>();
        }

        public static void PutGameList(string machineType, List<AppInfo> appList)
        {
            if (gameCache.ContainsKey(machineType))
            {
                gameCache.Remove(machineType);
            }
            gameCache.Add(machineType, appList);
        }

        public static List<AppInfo> GetGameList(string machineType)
        {
            return gameCache.ContainsKey(machineType) ? gameCache[machineType] : new List<AppInfo>();
        }

        public static void PutBannerList(string machineType, List<BannerInfo> appList)
        {
            if (bannerCache.ContainsKey(machineType))
            {
                bannerCache.Remove(machineType);
            }
            bannerCache.Add(machineType, appList);
        }

        public static List<BannerInfo> GetBannerList(string machineType)
        {
            return bannerCache.ContainsKey(machineType) ? bannerCache[machineType] : new List<BannerInfo>();
        }

        public static void PutRecommendedAppList(string machineType, List<AppInfo> appList)
        {
            if (recommendedAppCache.ContainsKey(machineType))
            {
                recommendedAppCache.Remove(machineType);
            }
            recommendedAppCache.Add(machineType, appList);
        }

        public static List<AppInfo> GetRecommendedAppList(string machineType)
        {
            return recommendedAppCache.ContainsKey(machineType) ? recommendedAppCache[machineType] : new List<AppInfo>();
        }

        public static void PutLawClause(LawClause lawClause)
        {
            lawClauseCache = lawClause;
        }

        public static LawClause GetLawClause()
        {
            return lawClauseCache!=null ? lawClauseCache : new LawClause();
        }


        public static void Clear()
        {
            appCache.Clear();
            gameCache.Clear();
            bannerCache.Clear();
            lawClauseCache = null;
        }
    }
}