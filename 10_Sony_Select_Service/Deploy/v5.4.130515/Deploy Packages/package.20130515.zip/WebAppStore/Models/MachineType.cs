﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class MachineType
    {
        public List<string> MachineTypes { get; set; }
    }
}