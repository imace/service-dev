﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class AppInfoResult
    {
        public string ResultCode { get; set; }
        public AppInfo AppInfo { get; set; }
    }
}