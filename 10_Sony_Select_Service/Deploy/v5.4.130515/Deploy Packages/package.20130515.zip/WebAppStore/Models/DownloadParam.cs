﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class DownloadParam
    {
        public string Url { get; set; }
        public string OrderId { get; set; }
        public string AppName { get; set; }
        public string ResultCode { get; set; } 
    }
}