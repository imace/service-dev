﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.MessageQueue
{
    public abstract class MessageHandler
    {
        public void SendMessage(Message msg)
        {
            HandleMessage(msg);
        }

        public abstract void HandleMessage(Message msg);
    }
}