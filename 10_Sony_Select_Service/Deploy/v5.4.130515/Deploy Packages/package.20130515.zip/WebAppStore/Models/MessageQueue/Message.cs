﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.MessageQueue
{
    public class Message
    {
        public int Type { get; set; }
        public Object Obj { get; set; }  
    }
}