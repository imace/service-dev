﻿using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class LawClause
    {
        private String resultCode;
        private String content;
        public string ResultCode { 
            get { return resultCode; } 
            set {
                this.resultCode = value;
            } 
        }

        public string Content
        {
            get { return content; }
            set
            {
                this.content = HtmlUtil.TextTohtml(value);
            } 
        }
    }
}