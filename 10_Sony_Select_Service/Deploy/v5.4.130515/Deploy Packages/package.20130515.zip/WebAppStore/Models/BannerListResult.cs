﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class BannerListResult
    {
        public int ResultCode { get; set; }
        public List<BannerInfo> BannerList { get; set; }
    }
}