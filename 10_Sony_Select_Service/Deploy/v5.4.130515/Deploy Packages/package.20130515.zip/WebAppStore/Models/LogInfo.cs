﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models
{
    public class LogInfo
    {
        public const string TYPE_LOGINFO = "21";

        public string IP { get; set; }
        public string Time { get; set; }
        public string PageType { get; set; }
        public string AppID { get; set; }
        public string AppName { get; set; }
        public string MachineType { get; set; }

        public override string ToString() {
            return "WebEndUserIP=" + IP + "|Time=" + Time + "|PageType=" + PageType +
                (String.IsNullOrEmpty(AppID) ? "" : ("|AppID=" + AppID)) +
                (String.IsNullOrEmpty(AppName) ? "" : ("|AppName=" + AppName));
        }

        public static LogInfo CreateHomePageLog(String machineType, string ip)
        {
            LogInfo logInfo = CreateLogInfo(machineType, ip);
            logInfo.PageType = "首页";
            return logInfo;
        }

        public static LogInfo CreateSearchPageLog(String machineType, string ip)
        {
            LogInfo logInfo = CreateLogInfo(machineType, ip);
            logInfo.PageType = "搜索页面";
            return logInfo;
        }

        public static LogInfo CreateAppDetailPageLog(String machineType, string ip, string appId, string appName)
        {
            LogInfo logInfo = CreateLogInfo(machineType, ip);
            logInfo.PageType = "详细页面";
            logInfo.AppID = appId;
            logInfo.AppName = appName;
            return logInfo;
        }

        private static LogInfo CreateLogInfo(string machineType, string ip)
        {
            LogInfo logInfo = new LogInfo();
            logInfo.MachineType = machineType;
            logInfo.IP = ip;
            logInfo.Time = (DateTime.Now.ToFileTime() / 1000L).ToString();
            logInfo.AppID = "";
            logInfo.AppName = "";
            logInfo.PageType = "";
            return logInfo;
        }
    }
}