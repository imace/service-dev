﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.BLL
{
    public class AppCountRestriction
    {
        public const int TRY_FETCH_APP_COUNT = 300;

        public const int BANNER_COUNT_MAX = 10;
        public const int APP_COUNT_MAX = 100;
        public const int GAME_COUNT_MAX = 100;
        public const int RECOMMENDED_APP_COUNT_MAX = 10;
        public const int SEARCHED_APP_COUNT_MAX = 99;
    }
}