﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlayNow.Models.BLL
{
    public interface ISearchManager
    {
        /// <summary>
        /// Search app by keyword
        /// </summary>
        /// <param name="keyword">search keyword</param>
        /// <param name="machineType">machine type</param>
        /// <param name="startIndex">The start index.</param>
        /// <param name="returnNum">Limit the number of returned result</param>
        /// <param name="machineType">Type of the machine.</param>
        /// <returns>SearchContent</returns>
        /// <remarks>
        /// </remarks>
        SearchContent GetSearchList(string searchKey, string machineType, int startIndex, int returnNum, int baiduCacheIndex);
    }
}
