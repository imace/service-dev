﻿using PlayNow.Models.MessageQueue;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.BLL
{
    public class LogHandler : MessageHandler
    {
        private static LogHandler s_LogHandler;

        public override void HandleMessage(Message msg)
        {
            PlayNowManagerCreator.GetLogWriter().WriteLog((LogInfo)msg.Obj);
        }

        public static LogHandler GetInstance()
        {
            if (s_LogHandler == null)
            {
                s_LogHandler = new LogHandler();
            }
            return s_LogHandler;
        }

        public void SendHomePageMessage(String machineType, string ip) 
        {
            Message logMsg = new Message();
            logMsg.Obj = LogInfo.CreateHomePageLog(machineType, ip);
            SendMessage(logMsg);
        }

        public void SendDetailPageMessage(String machineType, string ip, string appId, string appName)
        {
            Message logMsg = new Message();
            logMsg.Obj = LogInfo.CreateAppDetailPageLog(machineType, ip, appId, appName);
            SendMessage(logMsg);
        }

        public void SendSearchPageMessage(String machineType, string ip)
        {
            Message logMsg = new Message();
            logMsg.Obj = LogInfo.CreateSearchPageLog(machineType, ip);
            SendMessage(logMsg);
        }
    }
}