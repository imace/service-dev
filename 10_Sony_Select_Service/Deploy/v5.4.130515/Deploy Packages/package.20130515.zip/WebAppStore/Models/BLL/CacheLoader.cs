﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PlayNow.Models.DAL;
using PlayNow.Models.Utils;

namespace PlayNow.Models.BLL
{
    public class CacheLoader : ICacheLoader
    {
        private static BannerInfo s_playNowClientInfo;

        private IAppDataAccesser appDataAccesser;

        public CacheLoader(IAppDataAccesser appDataAccesser)
        {
            this.appDataAccesser = appDataAccesser;
        }

        public void LoadCache()
        {
            string[] machineTypes = LoadMachineTypes();
            if (machineTypes == null || machineTypes.Length <= 0)
            {
                return;
            }
            foreach (string machineType in machineTypes)
            {
                LoadCache(machineType);
            }
        }

        public void LoadCache(string machineType)
        {
            LoadAppList(machineType);
            LoadBanner(machineType);
            LoadRecommendedAppList(machineType);
            LoadLawClause(machineType);
        }

        public void UnloadCache()
        {
            AppCache.Clear();
        }

        public string[] LoadMachineTypes()
        {
            string[] machineTypes = appDataAccesser.GetSupportedMachineTypes();
            AppCache.MachineTypes = string.Join("|", machineTypes);
            return machineTypes;
        }

        private void LoadAppList(string machineType)
        {
            string appListJson = appDataAccesser.GetAppList(machineType, 0, AppCountRestriction.TRY_FETCH_APP_COUNT);
            AppSorter appSorter = new AppSorter(appListJson);
            appSorter.sort();
            if (appSorter.GetAppList().Count > 0)
            {
                if (appSorter.GetAppList().Count > AppCountRestriction.APP_COUNT_MAX)
                {
                    AppCache.PutAppList(machineType, appSorter.GetAppList().GetRange(0, AppCountRestriction.APP_COUNT_MAX));
                }
                AppCache.PutAppList(machineType, appSorter.GetAppList());
            }
            if (appSorter.GetGameList().Count > 0)
            {
                if (appSorter.GetAppList().Count > AppCountRestriction.GAME_COUNT_MAX)
                {
                    AppCache.PutGameList(machineType, appSorter.GetGameList().GetRange(0, AppCountRestriction.GAME_COUNT_MAX));
                }
                AppCache.PutGameList(machineType, appSorter.GetGameList());
            }
        }

        private void LoadRecommendedAppList(string machineType)
        {
            AppListResult appListResult = appDataAccesser.GetRecommendedAppList(1, machineType, 0, AppCountRestriction.RECOMMENDED_APP_COUNT_MAX);
            AppCache.PutRecommendedAppList(machineType, appListResult.AppInfoList);
        }

        private void LoadBanner(string machineType)
        {
            string appBannerListJson = appDataAccesser.GetBannerList(machineType);
            BannerListResult bannerListResult = JSONHelper.JsonDeserialize_JsonTo<BannerListResult>(appBannerListJson);
            if (bannerListResult.ResultCode == 1 && bannerListResult.BannerList.Count > 0)
            {
                if (bannerListResult.BannerList.Count > AppCountRestriction.BANNER_COUNT_MAX)
                {
                    bannerListResult.BannerList = bannerListResult.BannerList.GetRange(0, AppCountRestriction.BANNER_COUNT_MAX);
                }
                bannerListResult.BannerList.Add(CreateOrCreatePlayNowClientInfo());
                AppCache.PutBannerList(machineType, bannerListResult.BannerList);
            }
        }

        private void LoadLawClause(string machineType)
        {
            LawClause lawClause = appDataAccesser.GetLawClause(machineType);
            if (lawClause != null && lawClause.ResultCode.Equals("1"))
            {
                AppCache.PutLawClause(lawClause);
            }
        }

        private BannerInfo CreateOrCreatePlayNowClientInfo()
        {
            if (s_playNowClientInfo == null)
            {
                s_playNowClientInfo = new BannerInfo();
                s_playNowClientInfo.BannerIcon = "images/playnow_client.jpg";
                s_playNowClientInfo.ContentId = "PlayNowClient";
                s_playNowClientInfo.Name = "PlayNow";
                s_playNowClientInfo.Type = "2";
            }
            return s_playNowClientInfo;
        }
    }
}