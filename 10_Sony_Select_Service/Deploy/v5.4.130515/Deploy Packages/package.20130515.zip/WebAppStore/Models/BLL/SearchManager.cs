﻿using PlayNow.Models.DAL;
using PlayNow.Models.MessageQueue;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.BLL
{
    public class SearchManager:ISearchManager
    {
        private ICacheLoader cacheLoader;

        private IAppDataAccesser appDataAccesser;

        public SearchManager(IAppDataAccesser appDataAccesser, ICacheLoader cacheLoader)
        {
            this.appDataAccesser = appDataAccesser;
            this.cacheLoader = cacheLoader;
        }

        private SearchContent GetRecommendedAppList(string machineType)
        {
            SearchContent searchContent = new SearchContent();
            List<AppInfo> recommendedAppList = AppCache.GetRecommendedAppList(machineType);
            int count = recommendedAppList.Count;
            if (recommendedAppList == null || recommendedAppList.Count <= 0)
            {
                AppListResult appListResult = appDataAccesser.GetRecommendedAppList(1, machineType, 0, AppCountRestriction.RECOMMENDED_APP_COUNT_MAX);
                recommendedAppList = appListResult.AppInfoList;
                count = appListResult.TotalCount;
            }
            searchContent.RecommendedAppInfoList = recommendedAppList;
            searchContent.TotalCount = recommendedAppList.Count;
            return searchContent;
        }

        public SearchContent GetSearchList(string searchKey, string machineType, int startIndex, int returnNum, int baiduCacheIndex)
        { 
            SearchContent searchContent = new SearchContent();
            if (startIndex > AppCountRestriction.SEARCHED_APP_COUNT_MAX)
            {
                return searchContent;
            }

            SearchAppListResult searchAppListResult = appDataAccesser.GetAppListByKeyword(searchKey, machineType, startIndex, returnNum, baiduCacheIndex);
            // if none search reseach, return the recommended app list
            if (searchAppListResult.TotalCount == 0 && startIndex == 0)
            {
                return GetRecommendedAppList(machineType);
            }
            
            if (startIndex < searchAppListResult.TotalCount)
            {
                searchContent.BaiduCacheIndex = searchAppListResult.BaiduCacheIndex;

                if (((startIndex + returnNum) < searchAppListResult.BaiduStartIndex)
                    || (searchAppListResult.BaiduStartIndex == -1))
                {
                    searchContent.PlayNowAppInfoList = searchAppListResult.AppInfoList;
                }
                else if (startIndex >= searchAppListResult.BaiduStartIndex)
                {
                    searchContent.BaiduAppInfoList = searchAppListResult.AppInfoList;
                }
                else if ((startIndex < searchAppListResult.BaiduStartIndex) && ((startIndex + returnNum) > searchAppListResult.BaiduStartIndex))
                {
                    int baiduIndex = searchAppListResult.BaiduStartIndex % returnNum;
                    searchContent.PlayNowAppInfoList = new List<AppInfo>();
                    searchContent.BaiduAppInfoList = new List<AppInfo>();
                    for (int i = 0; i < searchAppListResult.AppInfoList.Count; i++)
                    {
                        AppInfo appInfo = searchAppListResult.AppInfoList.ElementAt(i);
                        if (appInfo == null)
                        {
                            continue;
                        }
                        if (i < baiduIndex)
                        {
                            searchContent.PlayNowAppInfoList.Add(appInfo);
                        }
                        else
                        {
                            searchContent.BaiduAppInfoList.Add(appInfo);
                        }
                    }
                }
                searchContent.TotalCount = searchAppListResult.AppInfoList.Count;
            }
            return searchContent;
        }
    }
}