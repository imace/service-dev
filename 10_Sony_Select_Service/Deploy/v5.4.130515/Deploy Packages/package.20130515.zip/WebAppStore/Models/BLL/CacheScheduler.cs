﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using PlayNow.Models.BLL;

namespace PlayNow.Models.Utils
{
    public class CacheSyncScheduler
    {
        private static string TAG = "CacheSyncScheduler";

        private static log4net.ILog log = log4net.LogManager.GetLogger("testApp.Logging");

        public static int AbsoluteMinute { get; set; }

        public static string TriggerHour { get; set; }

        public static int IntervalMinute { get; set; }

        private static Timer GlobalTimer = new Timer(new TimerCallback(SyncTask), null, Timeout.Infinite, Timeout.Infinite);

        private static void SyncTask(object obj)
        {
            int syncHour = Convert.ToInt32(TriggerHour);
            int nowHour = Convert.ToInt32(DateTime.Now.Hour.ToString());
            int nowMinute = Convert.ToInt32(DateTime.Now.Minute.ToString());

            log.Info(DateTime.Now.ToString() + " [" + TAG + "] Start sync task; syncHour : " + syncHour + "; nowhour : " + nowHour + "; nowMinute : " + nowMinute + ";");
            if (((nowHour == syncHour - 1) && (nowMinute >= 60 - AbsoluteMinute)) || ((nowHour == syncHour) && (nowMinute <= AbsoluteMinute)))
            {
                log.Info(DateTime.Now.ToString() + " [" + TAG + "] Start LoadCache");
                LoadCache();
            }
        }

        public static void Start(int absoluteMinute, string triggerHour, int intervalMinute)
        {
            AbsoluteMinute = absoluteMinute;
            TriggerHour = triggerHour;
            GlobalTimer.Change(0, intervalMinute * 60 * 1000);
        }

        public static void Stop()
        {
            GlobalTimer.Change(Timeout.Infinite, Timeout.Infinite);
        }

        public static void LoadCache()
        {
            ICacheLoader cacheLoader = PlayNowManagerCreator.GetCacheLoader();
            cacheLoader.LoadCache();
        }
    }
}