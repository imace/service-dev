﻿using PlayNow.Models.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.BLL
{
    public class LogWriter
    {
        private IAppDataAccesser appDataAccesser;

        public LogWriter(IAppDataAccesser appDataAccesser)
        {
            this.appDataAccesser = appDataAccesser;
        }

        public void WriteLog(LogInfo logInfo)
        {
            appDataAccesser.WriteLogInfo(logInfo.MachineType, LogInfo.TYPE_LOGINFO, logInfo.ToString()); 
        }
    }
}