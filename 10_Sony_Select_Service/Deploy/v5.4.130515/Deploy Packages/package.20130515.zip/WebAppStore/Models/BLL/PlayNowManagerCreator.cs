﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PlayNow.Models.DAL;

namespace PlayNow.Models.BLL
{
    public class PlayNowManagerCreator
    {
        private static IAppInfoManager appInfoManager;

        private static ISearchManager searchManager;

        private static ICacheLoader cacheLoader;

        private static LogWriter logWriter;

        public static IAppInfoManager GetAppInfoManager()
        {
            if (appInfoManager == null)
            {
                appInfoManager = new AppInfoManager(new AppDataAccesser(), GetCacheLoader());
            }
            return appInfoManager;
        }

        public static ISearchManager GetSearchManager()
        {
            if (searchManager == null)
            {
                searchManager = new SearchManager(new AppDataAccesser(), GetCacheLoader());
            }
            return searchManager;
        }

        public static ICacheLoader GetCacheLoader()
        {
            if (cacheLoader == null)
            {
                cacheLoader = new CacheLoader(new AppDataAccesser());
            }
            return cacheLoader;
        }

        public static LogWriter GetLogWriter()
        {
            if (logWriter == null)
            {
                logWriter = new LogWriter(new AppDataAccesser());
            }
            return logWriter;
        }
    }
}