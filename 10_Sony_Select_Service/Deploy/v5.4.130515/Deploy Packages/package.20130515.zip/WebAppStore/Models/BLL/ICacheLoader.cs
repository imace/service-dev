﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlayNow.Models.BLL
{
    public interface ICacheLoader
    {
        void LoadCache();
        string[] LoadMachineTypes();
        void LoadCache(string machineType);
        void UnloadCache();
    }
}
