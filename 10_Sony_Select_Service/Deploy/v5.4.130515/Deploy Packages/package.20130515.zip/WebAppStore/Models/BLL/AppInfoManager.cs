﻿using Newtonsoft.Json.Linq;
using PlayNow.Models.DAL;
using PlayNow.Models.MessageQueue;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.BLL
{
    public class AppInfoManager : IAppInfoManager
    {
        private IAppDataAccesser appDataAccesser;

        private ICacheLoader cacheLoader;

        public AppInfoManager(IAppDataAccesser appDataAccesser, ICacheLoader cacheLoader)
        {
            this.appDataAccesser = appDataAccesser;
            this.cacheLoader = cacheLoader;
        }

        public string GetBannerList(string machineType)
        {
            List<BannerInfo> bannerList = AppCache.GetBannerList(machineType);
            if (bannerList == null || bannerList.Count <= 0)
            {
                cacheLoader.LoadCache(machineType);
            }
            return JSONHelper.JsonSerializer_to_Json<List<BannerInfo>>(AppCache.GetBannerList(machineType)); 
        }

        public string GetAppList(string appType, string machineType, int pageIndex, int pageSize)
        {
            List<AppInfo> appList = GetAppListFromCache(machineType, appType);
            if (appList == null || appList.Count <= 0)
            {
                cacheLoader.LoadCache(machineType);
                appList = GetAppListFromCache(machineType, appType);
            }
            if (pageIndex * pageSize > appList.Count)
            {
                return JSONHelper.JsonSerializer_to_Json<List<AppInfo>>(new List<AppInfo>());
            }
            if ((pageIndex + 1) * pageSize > appList.Count)
            {
                return JSONHelper.JsonSerializer_to_Json<List<AppInfo>>(appList.GetRange(pageIndex * pageSize, appList.Count - pageIndex * pageSize));
            }
            return JSONHelper.JsonSerializer_to_Json<List<AppInfo>>(appList.GetRange(pageIndex * pageSize, pageSize));
        }

        public AppInfo GetAppInfo(string appId, string machineType)
        {
            string appDetailJson = appDataAccesser.GetAppDetail(appId, machineType);
            if (String.IsNullOrEmpty(appDetailJson))
            {
                return null;
            }
            AppInfoResult appInfo = JSONHelper.JsonDeserialize_JsonTo<AppInfoResult>(appDetailJson); 
            return appInfo.AppInfo;
        }

        public LawClause GetLawClause(string machineType)
        {
            LawClause lawClause = AppCache.GetLawClause();
            if (String.IsNullOrEmpty(lawClause.ResultCode))
            {
                cacheLoader.LoadCache(machineType);
            }
            return lawClause;
        }

        public string GetDownloadUrl(string appId, string machineType, string pageName, string intentFromId, string contendId, string userName)
        {
            if (appId == "PlayNowClient")
            {
                return "http://mob.cn-playnow.com.cn/installpackage?model=" + machineType + "&platform=&from=defaultwebpage";
            }
            DownloadParam downloadParam = appDataAccesser.GetDownloadParam(appId, machineType, pageName, intentFromId, contendId, userName);
            return (downloadParam != null) ? downloadParam.Url : "";
        }

        private List<AppInfo> GetAppListFromCache(string machineType, string appType)
        {
            if (AppInfo.TYPE_APPLICATION.Equals(appType))
            {
                return AppCache.GetAppList(machineType);
            }
            else if (AppInfo.TYPE_GAME.Equals(appType))
            {
                return AppCache.GetGameList(machineType);
            }
            return new List<AppInfo>();
        }
    }
}