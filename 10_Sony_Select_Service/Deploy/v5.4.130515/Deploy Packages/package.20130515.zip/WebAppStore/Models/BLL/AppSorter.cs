﻿using PlayNow.Models.DAL;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlayNow.Models.BLL
{
    public class AppSorter
    {
        private string appListJson;

        private List<AppInfo> appList = new List<AppInfo>();

        private List<AppInfo> gameList = new List<AppInfo>();

        public AppSorter(String appListJson)
        {
            this.appListJson = appListJson;
        }

        public void sort()
        {
            AppListResult appListRst = JSONHelper.JsonDeserialize_JsonTo<AppListResult>(appListJson);
            // MockAppType(appListRst.AppInfoList);
            foreach (AppInfo appInfo in appListRst.AppInfoList)
            {
                if (AppInfo.TYPE_APPLICATION.Equals(appInfo.Type))
                {
                    appList.Add(appInfo);
                }
                else if (AppInfo.TYPE_GAME.Equals(appInfo.Type))
                {
                    gameList.Add(appInfo);
                }
            }
        }

        public List<AppInfo> GetAppList()
        {
            return appList;
        }

        public List<AppInfo> GetGameList()
        {
            return gameList;
        }

        private List<AppInfo> MockAppType(List<AppInfo> allAppList)
        {
            int i = 0;
            foreach (AppInfo appInfo in allAppList)
            {
                if (i % 2 == 0)
                {
                    appInfo.Type = AppInfo.TYPE_APPLICATION;
                    i++;
                    continue;
                }
                appInfo.Type = AppInfo.TYPE_GAME;
                i++;
            }
            return allAppList;
        }
    }
}