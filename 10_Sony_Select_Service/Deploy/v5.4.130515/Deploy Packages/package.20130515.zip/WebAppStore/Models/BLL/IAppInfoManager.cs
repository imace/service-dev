﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlayNow.Models.BLL
{
    public interface IAppInfoManager
    {
        string GetBannerList(string machineType);

        string GetAppList(string type, string machineType, int pageIndex, int pageSize);

        AppInfo GetAppInfo(string appId, string machineType);

        /// <summary>
        /// Get the clause of law.
        /// </summary>
        /// <param name="userAgent">User Agent</param>
        /// <returns></returns>
        LawClause GetLawClause(string machineType);

        /// <summary>
        /// Get Download url.
        /// </summary> 
        /// <param name="intAppId">商品Id</param>
        /// <param name="machineType">Type of the machine.</param>
        /// <param name="pageName">页面名称</param>
        /// <param name="intentFromId">下载来源入口标志，
        ///       1 表示widget
        ///       2 表示playnow
        ///       3 表示百度
        ///       4 表示消息推送
        ///</param>
        /// <param name="contendId">当IntentFromId为消息推送时，赋值MessageId，否则置为0</param> 
        /// <returns>DownloadParam</returns>
        /// <remarks>
        /// </remarks>
        string GetDownloadUrl(string appId, string machineType, string pageName, string intentFromId, string contendId, string userName);
    }
}
