﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PlayNow.Models;
using PlayNow.Models.BLL;
using PlayNow.Models.DAL;
using PlayNow.Models.MessageQueue;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PlayNow.Controllers
{
    public class HomeController : Controller
    {
        // GET: /Home/
        [Compress]
        public ActionResult Index()
        {
            string machineType = UserAgentParser.GetMachineType(HttpContext.Request.UserAgent);
            string ip = Request.ServerVariables.Get("Remote_Addr").ToString();
            LogHandler.GetInstance().SendHomePageMessage(machineType, ip);

            return View();
        }

        [Compress]
        public String getAppList(string type, int pageIndex = 0, int pageSize = 10)
        {
			HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
            HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Buffer = true;
            Response.ExpiresAbsolute = System.DateTime.Now.AddSeconds(-1);
            Response.Expires = 0;
            Response.CacheControl = "no-cache";
            Response.AddHeader("Pragma", "No-Cache");
            IAppInfoManager appInfoMgr = PlayNowManagerCreator.GetAppInfoManager();
            string machineType = UserAgentParser.GetMachineType(HttpContext.Request.UserAgent);
            return appInfoMgr.GetAppList(type, machineType, pageIndex, pageSize);
        }

        [Compress]
        public String getBannerList()
        {
			HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
            IAppInfoManager appInfoMgr = PlayNowManagerCreator.GetAppInfoManager();
            string machineType = UserAgentParser.GetMachineType(HttpContext.Request.UserAgent);
            return appInfoMgr.GetBannerList(machineType);
        }
    }
}
