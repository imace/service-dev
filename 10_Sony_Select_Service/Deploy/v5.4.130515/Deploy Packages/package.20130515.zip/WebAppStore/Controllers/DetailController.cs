﻿using PlayNow.Models;
using PlayNow.Models.BLL;
using PlayNow.Models.MessageQueue;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PlayNow.Controllers
{
    public class DetailController : Controller
    {
        //
        // GET: /Detail/
       // [Compress]
        public ActionResult Index(String appId)
        {
            IAppInfoManager appInfoMgr = PlayNowManagerCreator.GetAppInfoManager();
            string machineType = UserAgentParser.GetMachineType(HttpContext.Request.UserAgent);
            AppInfo appInfo = appInfoMgr.GetAppInfo(appId, machineType);

            string ip = Request.ServerVariables.Get("Remote_Addr").ToString();
            LogHandler.GetInstance().SendDetailPageMessage(machineType, ip, appInfo.Id, appInfo.Name);

            return View(appInfo);
        }
    }
}
