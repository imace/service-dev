﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PlayNow.Models.BLL;
using PlayNow.Models;
using PlayNow.Models.Utils;
using PlayNow.Models.MessageQueue;

namespace PlayNow.Controllers
{
    public class SearchController : Controller
    {
        private static string DEFAULT_SERACH_KEY = "输入应用或游戏名称搜索";

        private static string SEARCH_KEY_ID = "SearchKey";

        //
        // GET: /Search/
        [Compress]
        public ActionResult Index()
        {
            string searchKey = Request.Form[SEARCH_KEY_ID];
            if ((searchKey != null) && (searchKey.Trim().Length > 0))
            {
                ViewData[SEARCH_KEY_ID] = searchKey;
            }
            else
            {
                ViewData[SEARCH_KEY_ID] = DEFAULT_SERACH_KEY;
            }

            string ip = Request.ServerVariables.Get("Remote_Addr").ToString();
            LogHandler.GetInstance().SendSearchPageMessage(UserAgentParser.GetMachineType(HttpContext.Request.UserAgent), ip);
            
            return View();
        }

        [Compress]
        public String List(string searchKey, int pageIndex = 0, int pageSize = 10, int baiduCacheIndex = 0)
        {
			HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
            ISearchManager searchManager = PlayNowManagerCreator.GetSearchManager();
            SearchContent sc = searchManager.GetSearchList(searchKey, UserAgentParser.GetMachineType(HttpContext.Request.UserAgent), pageIndex * pageSize, pageSize, baiduCacheIndex);

            return JSONHelper.JsonSerializer_to_Json<SearchContent>(sc);
        }

    }
}
