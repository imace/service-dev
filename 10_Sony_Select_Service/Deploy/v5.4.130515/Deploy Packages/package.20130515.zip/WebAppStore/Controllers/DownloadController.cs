﻿using PlayNow.Models.BLL;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PlayNow.Controllers
{
    public class DownloadController : Controller
    {
        //
        // GET: /Download/

        public string Index(string appId, string pageName = "首页", string intentFromId = "2", string contendId = "0", string userName = "匿名用户")
        {
            IAppInfoManager appInfoManager = PlayNowManagerCreator.GetAppInfoManager();
            string machineType = UserAgentParser.GetMachineType(HttpContext.Request.UserAgent);
            return appInfoManager.GetDownloadUrl(appId, machineType, pageName, intentFromId, contendId, userName);
        }
    }
}
