﻿using PlayNow.Models;
using PlayNow.Models.BLL;
using PlayNow.Models.DAL;
using PlayNow.Models.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PlayNow.Controllers
{
    public class LawClauseController : Controller
    {
        //
        // GET: /Static/

        [Compress]
        public ActionResult Index()
        {
            IAppInfoManager appInfoManager = PlayNowManagerCreator.GetAppInfoManager();
            string machineType = UserAgentParser.GetMachineType(HttpContext.Request.UserAgent);
            LawClause lawClause = appInfoManager.GetLawClause(machineType);

            return View(lawClause);
        }

    }
}
