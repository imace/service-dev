USE [PlayNow]
GO
/****** start Fix Issue CR00017, by Wei,Devin. ******/
/****** start update FK FK_PN_AppRecommendationOrder_PN_AppInfo ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_PN_AppRecommendationOrder_PN_AppInfo') and type = N'F'))
ALTER TABLE [dbo].[PN_AppRecommendationOrder] DROP CONSTRAINT FK_PN_AppRecommendationOrder_PN_AppInfo
ALTER TABLE [dbo].[PN_AppRecommendationOrder]  WITH CHECK ADD  CONSTRAINT [FK_PN_AppRecommendationOrder_PN_AppInfo] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
GO
ALTER TABLE [dbo].[PN_AppRecommendationOrder] CHECK CONSTRAINT [FK_PN_AppRecommendationOrder_PN_AppInfo]
GO
/****** end update FK FK_PN_AppRecommendationOrder_PN_AppInfo ******/
/****** start update FK FK_APPCATEGORY_APPID ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_APPCATEGORY_APPID') and type = N'F'))
ALTER TABLE [dbo].[PN_AppCategory] DROP CONSTRAINT FK_APPCATEGORY_APPID
ALTER TABLE [dbo].[PN_AppCategory]  WITH NOCHECK ADD  CONSTRAINT [FK_APPCATEGORY_APPID] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
GO
ALTER TABLE [dbo].[PN_AppCategory] CHECK CONSTRAINT [FK_APPCATEGORY_APPID]
GO
/****** end update FK FK_APPCATEGORY_APPID ******/
/****** start update FK FK_ZONEDETAIL_APPID ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_ZONEDETAIL_APPID') and type = N'F'))
ALTER TABLE [dbo].[PN_ZoneDetail] DROP CONSTRAINT FK_ZONEDETAIL_APPID
ALTER TABLE [dbo].[PN_ZoneDetail]  WITH NOCHECK ADD  CONSTRAINT [FK_ZONEDETAIL_APPID] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
GO
ALTER TABLE [dbo].[PN_ZoneDetail] NOCHECK CONSTRAINT [FK_ZONEDETAIL_APPID]
GO
/****** end update FK FK_ZONEDETAIL_APPID ******/
/****** start update FK FK_APPRECOMMDETAIL_APPID ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_APPRECOMMDETAIL_APPID') and type = N'F'))
ALTER TABLE [dbo].[PN_AppRecommendationDetail] DROP CONSTRAINT FK_APPRECOMMDETAIL_APPID
ALTER TABLE [dbo].[PN_AppRecommendationDetail]  WITH NOCHECK ADD  CONSTRAINT [FK_APPRECOMMDETAIL_APPID] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
GO
ALTER TABLE [dbo].[PN_AppRecommendationDetail] CHECK CONSTRAINT [FK_APPRECOMMDETAIL_APPID]
GO
/****** end update FK FK_APPRECOMMDETAIL_APPID ******/
/****** start update FK FK_APPCOMMENT_APPID ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_APPCOMMENT_APPID') and type = N'F'))
ALTER TABLE [dbo].[PN_AppComment] DROP CONSTRAINT FK_APPCOMMENT_APPID
ALTER TABLE [dbo].[PN_AppComment]  WITH NOCHECK ADD  CONSTRAINT [FK_APPCOMMENT_APPID] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
NOT FOR REPLICATION
GO
ALTER TABLE [dbo].[PN_AppComment] NOCHECK CONSTRAINT [FK_APPCOMMENT_APPID]
GO
/****** end update FK FK_APPCOMMENT_APPID ******/
/****** start update FK FK_PRELOADEDAPP_APPID ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_PRELOADEDAPP_APPID') and type = N'F'))
ALTER TABLE [dbo].[PN_PreloadedApp] DROP CONSTRAINT FK_PRELOADEDAPP_APPID
ALTER TABLE [dbo].[PN_PreloadedApp]  WITH CHECK ADD  CONSTRAINT [FK_PRELOADEDAPP_APPID] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
GO
ALTER TABLE [dbo].[PN_PreloadedApp] CHECK CONSTRAINT [FK_PRELOADEDAPP_APPID]
GO
/****** end update FK FK_PRELOADEDAPP_APPID ******/
/****** start update FK FK_APPBANNER_APPID ******/
if(exists(select * from sys.sysobjects where id = object_id(N'FK_APPBANNER_APPID') and type = N'F'))
ALTER TABLE [dbo].[PN_AppBanner] DROP CONSTRAINT FK_APPBANNER_APPID
ALTER TABLE [dbo].[PN_AppBanner]  WITH CHECK ADD  CONSTRAINT [FK_APPBANNER_APPID] FOREIGN KEY([AppId])
REFERENCES [dbo].[PN_AppInfo] ([Id])
GO
ALTER TABLE [dbo].[PN_AppBanner] CHECK CONSTRAINT [FK_APPBANNER_APPID]
GO
/****** end update FK FK_APPBANNER_APPID ******/
/****** end Fix Issue CR00017, by Wei,Devin. ******/
/****** start Fix Issue CR00016, by Wei,Devin. ******/
/****** Object:  Trigger [dbo].[trInsertAppPublish]    Script Date: 07/02/2013 14:21:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Trigger [dbo].[trInsertAppPublish]
On [dbo].[PN_AppInfo] for insert
As
--����AppInfo����ͬʱҲ����AppPublish
INSERT INTO dbo.PN_AppPublish(
AppId, ManualTime, UpdateTime, Status
)
SELECT
Id AS AppId,
UpdateTime AS ManualTime,
--������¼��������Ч
UpdateTime AS UpdateTime,
1 AS Status
FROM inserted
GO
/****** Object:  Trigger [dbo].[trUpdateAppPublish]    Script Date: 06/19/2013 11:03:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Trigger [dbo].[trUpdateAppPublish]
On [dbo].[PN_AppInfo] for update
As
--����AppInfo����ͬʱҲ����AppPublish
UPDATE dbo.PN_AppPublish
--ֻ����ManualTime������һ��Ч
SET ManualTime = (
SELECT inserted.UpdateTime
FROM inserted
WHERE Appid = inserted.Id)
WHERE Appid in (SELECT Id FROM inserted)
GO
/****** end Fix Issue CR00016, by Wei,Devin. ******/
