﻿USE [PlayNow]
GO

/**start rollback for adding music download in PN_Module by Hu Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
begin
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='音乐下载和收费' and ModulePath='Music/MusicDownAndOrder.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='音乐购买按日期统计' and ModulePath='Music/MusicOrderCountByDate.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='我的音乐页面下载完成按日期统计' and ModulePath='Music/MyMusicDownCountByDate.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='专辑详情页面下载完成按日期统计' and ModulePath='Music/AlbumDetailDownCountByDate.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='音乐收入统计' and ModulePath='Music/MusicIncomingCountByDate.aspx'
end
/**end rollback for adding music download in PN_Module by Hu Jingzhi**/

/**start rollback for adding Music-PV in PN_Module by Wei, Devin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
begin
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='Music-PV' and ModulePath='Statistic/MusicPV.aspx'
delete from PN_Module where MenuId = 3 and ModuleName = 'Music-PVByDate' and ModulePath = 'Statistic/MusicPVByDate.aspx'
end
/**end rollback for adding Music-PV in PN_Module by Wei, Devin**/
/**start rollback For create table PN_MusicOrder by Hu,Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_MusicOrder'))
drop table PN_MusicOrder
/**end rollback For create table PN_MusicOrder by Hu,Jingzhi**/

/**start rollback For create table PN_AlbumDetail by Hu,Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_AlbumDetail'))
drop table PN_AlbumDetail
/**end rollback For create table PN_AlbumDetail by Hu,Jingzhi**/

/**start rollback For create table PN_MusicInfo by Hu,Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_MusicInfo'))
drop table PN_MusicInfo
/**end rollback For create table PN_MusicInfo by Hu,Jingzhi**/

/**start rollback For create table PN_AlbumCategoryDetail by Wei,Devin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_AlbumCategoryDetail'))
drop table PN_AlbumCategoryDetail
/**end rollback For create table PN_AlbumCategoryDetail by Wei,Devin**/

/**start rollback For create table PN_Album by Wei,Devin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Album'))
drop table PN_Album
/**end rollback For create table PN_Album by Wei,Devin**/

/**start rollback For create table PN_AlbumCategory by Nie, Kevin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_AlbumCategory'))
drop table PN_AlbumCategory
/**end rollback For create table PN_AlbumCategory by Nie, Kevin**/

/**start rollback For delete album in PN_Module by Nie, Kevin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
DELETE FROM [dbo].[PN_Module] WHERE MenuId=7 and ModuleName='专辑分类管理' and ModulePath='Music/AlbumCategory.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=7 and ModuleName='专辑管理' and ModulePath='Music/Album.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=7 and ModuleName='专辑/类型关系管理' and ModulePath='Music/AlbumCategoryDetail.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=7 and ModuleName='音乐管理' and ModulePath='Music/MusicInfo.aspx'
DELETE FROM [dbo].[PN_Module] WHERE MenuId=7 and ModuleName='专辑/音乐关系管理' and ModulePath='Music/AlbumDetail.aspx'
/**end rollback For delete album in PN_Module by Nie, Kevin**/

/**start rollback For delete MusicDownloadDetail in PN_Module by Nie, Kevin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
DELETE FROM [dbo].[PN_Module] WHERE MenuId=3 and ModuleName='音乐下载和收费明细' and ModulePath='Statistic/MusicDownloadDetail.aspx'
/**end rollback For delete MusicDownloadDetail in PN_Module by Nie, Kevin**/