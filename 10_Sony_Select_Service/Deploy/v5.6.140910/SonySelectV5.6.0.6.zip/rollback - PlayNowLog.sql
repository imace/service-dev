﻿USE [PlayNowLog]
GO
/**start For rollback V_PN_MusicOrder by Hu, Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'V_PN_MusicOrder'))
drop view V_PN_MusicOrder
GO
/**end For rollback V_PN_MusicOrder by Hu, Jingzhi**/
/**start for rollback modifying table SP_MessageStatistic by Wei,Devin**/
IF(EXISTS(SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_MessageStatistic'))
DROP PROCEDURE SP_MessageStatistic
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	消息统计 分析 其中在做分析插入之前要做一次删除
-- =============================================
CREATE PROCEDURE [dbo].[SP_MessageStatistic]
	-- Add the parameters for the stored procedure here
	@BeginTime Datetime, 
	@EndTime Datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--declare @errorCount int=0 --错误的累加
--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点
--2013/7/4 jiaoxuhuan 在获取数量时添加MachineType过滤条件（例:and A.MachineType=C.MachineType）

declare @errorCount int 
set @errorCount=0 

begin  tran --开始事务


--set @BeginTime=CAST(@BeginTime as date) --开始时间
--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间


-- 分析前先删除 某一时间段的数据
delete from  dbo.PN_S_Message where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- 消息统计 分析
	insert into dbo.PN_S_Message(
	 MessageID, MachineType, GetMessage,
	 ReadMessage, DownCount,  
	 DownCompleteCount, InstallCount, CreateTime
	)


		SELECT  MessageId, MachineType, 
				(
				select COUNT(*) from [PN_Log_Message] as A 
				 where C.MessageId=A.MessageId and IsValid=1 and   
				--CAST(A.CreateTime as date)=cast(C.CreateTime as date) ) as GetCount, 
				cast( convert(varchar(10),A.CreateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime) 
				and A.MachineType=C.MachineType
				) as GetCount, 
				(select COUNT(*) from [PN_Log_PageViewInfo] as B 

				where C.MessageId=B.ContentId AND IntentFromId=4 and

				-- CAST(B.DateTime as date)=cast(C.CreateTime as date) ) as PVCount,
				cast( convert(varchar(10),B.DateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
				and B.MachineType=C.MachineType
				 )as PVCount,
				(
				select COUNT(*) from [PN_Order] as D 

				where C.MessageId=D.ContentId and IntentFromId=4 and

				 --CAST(D.StartTime as date)=cast(C.CreateTime as date) ) as DownCount,
				 cast( convert(varchar(10),D.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
				 and D.MachineType=C.MachineType
				  )as DownCount,
				 (select COUNT(*) from [PN_Order] as G 

				   where C.MessageId=G.ContentId and IntentFromId=4 and

				  -- CAST(G.StartTime as date)=cast(C.CreateTime as date)  
					cast( convert(varchar(10),G.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
					and G.MachineType=C.MachineType
				   and EndTime is not null) as DownCompleteCount
				,
				 (select COUNT(*) from [PN_Order] as H
				   where C.MessageId=H.ContentId and IntentFromId=4 and 
					cast( convert(varchar(10),H.InstallTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
					and H.MachineType=C.MachineType
				   and IsInstalled = 1) as InstallCount
				,cast( convert(varchar(10),CreateTime,120)as datetime) dTime
		FROM [PN_log_Message] as C

		where  CreateTime>=@BeginTime AND CreateTime<@EndTime    
		and MessageId>0 
		AND	IsValid=1 
		--group by CAST(CreateTime as date),MessageId,MachineType	
          group by cast( convert(varchar(10),CreateTime,120)as datetime),MessageId,MachineType	




set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

	begin

		rollback --如果有错，就回滚事务

	end

else

	begin

		commit tran --如果没有错，就提交事务

	
	end

END
GO
/**end for rollback modifying table SP_MessageStatistic by Wei,Devin**/
/**start for rollback adding table SP_MusicMessageStatistic by Wei,Devin**/
IF(EXISTS(SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_MusicMessageStatistic'))
DROP PROCEDURE SP_MusicMessageStatistic
GO
/**end for rollback adding table SP_MusicMessageStatistic by Wei,Devin**/
/**start for rollback adding table PN_S_Message_Music by Wei,Devin**/
IF(EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_S_Message_Music'))
drop table PN_S_Message_Music
/**start for rollback adding table  PN_S_MusicPV by Wei,Devin**/
IF  EXISTS (SELECT * FROM information_schema.tables where table_name = 'PN_S_MusicPV')
DROP TABLE [dbo].[PN_S_MusicPV]
/**end for rollback adding table  PN_S_MusicPV by Wei,Devin**/
/**start for rollback adding procedure SP_MusicPVStatistic by Wei,Devin**/
if(exists(select * from INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_MusicPVStatistic'))
DROP PROCEDURE SP_MusicPVStatistic
/**end for rollback adding procedure SP_MusicPVStatistic by Wei,Devin**/
/**start rollback For PN_MusicDownload by Hu, Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_MusicDownload'))
drop table PN_MusicDownload
/**end rollback For PN_MusicDownload by Hu, Jingzhi**/
/**start For PN_S_MusicDownSource by Hu, Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_S_MusicDownSource'))
drop table PN_S_MusicDownSource
/**end For PN_S_MusicDownSource by Hu, Jingzhi**/
/**start For SP_MusicDownSourceStatistic by Hu, Jingzhi**/
if(exists(select * from dbo.sysobjects where OBJECTPROPERTY(id, N'IsProcedure') = 1 AND name = 'SP_MusicDownSourceStatistic'))
drop PROCEDURE SP_MusicDownSourceStatistic
/**end For SP_MusicDownSourceStatistic by Hu, Jingzhi**/
/**start rollback for adding MusicBatchUpLoad in PN_Module by Hu, Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
DELETE FROM [dbo].[PN_Module] WHERE ModuleName='音乐批量上传'
/**end rollback for adding MusicBatchUpLoad in PN_Module by Hu, Jingzhi**/
/**start for rollback adding table PN_Log_PageViewInfo_Music by Wei,Devin**/
if( exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Log_PageViewInfo_Music'))
drop table PN_Log_PageViewInfo_Music

/**end for rollback adding table PN_Log_PageViewInfo_Music by Wei,Devin**/