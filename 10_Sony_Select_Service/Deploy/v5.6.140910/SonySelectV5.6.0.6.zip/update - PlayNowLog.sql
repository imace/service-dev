﻿USE [PlayNowLog]
GO
/**start for adding table PN_Log_PageViewInfo_Music by Wei,Devin**/
if(not exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Log_PageViewInfo_Music'))
begin
/****** 对象:  Table [dbo].[PN_Log_PageViewInfo_Music]    脚本日期: 07/01/2014 05:35:36 ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE TABLE [dbo].[PN_Log_PageViewInfo_Music](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IMSI] [nvarchar](20) NULL,
	[IMEI] [nvarchar](50) NULL DEFAULT (''),
	[AndroidVer] [nvarchar](20) NULL DEFAULT (''),
	[EdreamVer] [nvarchar](50) NULL DEFAULT (''),
	[ClientVer] [nvarchar](20) NULL DEFAULT (''),
	[PageName] [nvarchar](300) NULL,
	[UserName] [nvarchar](100) NULL,
	[MachineType] [nvarchar](50) NULL,
	[ContentId] [nvarchar](20) NULL DEFAULT (''),
	[ContentName] [nvarchar](300) NULL,
	[IntentFromId] [nvarchar](20) NULL,
	[Operation] [nvarchar](20) NULL,
	[MessageId] [nvarchar](20) NULL,
	[CreateTime] [datetime] NULL CONSTRAINT [DF_PN_Log_PageViewInfo_Music_CreateTime]  DEFAULT (getdate())
CONSTRAINT [PK_PN_Log_PageViewInfo_Music] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'移动用户识别码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'IMSI'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'移动设备识别码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'IMEI'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Android版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'AndroidVer'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Edream平台版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'EdreamVer'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'客户端版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'ClientVer'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'页面名称，主要包括：音乐，专辑详情，我的音乐' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'PageName'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'用户名，不存在则为匿名用户' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'UserName'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'访问机型' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'MachineType'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容Id，包括：专辑Id，如不存在则为空' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'ContentId'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容名称，包括：专辑名称，如不存在则为空' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'ContentName'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'playnow客户端的PV标志：1表示widget,2表示playnow,3表示百度,4表示消息推送' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'IntentFromId'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'当IntentFromId为playnow时，赋值Operation，否则置为空,1表示“点击音乐频道”2表示“点击首页音乐推荐链接”3表示“点击左侧滑动菜单中我的音乐”4表示“其他操作"' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'Operation'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'当IntentFromId为消息推送时，赋值MessageId，否则置为空' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'MessageId'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Log_PageViewInfo_Music', @level2type=N'COLUMN',@level2name=N'CreateTime'
end

/**end for adding table PN_Log_PageViewInfo_Music by Wei,Devin**/
/**start For PN_MusicDownload by Hu, Jingzhi**/
/****** Object:  Table [dbo].[PN_MusicDownload]    Script Date: 07/03/2014 14:57:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_MusicDownload'))
drop table PN_MusicDownload

CREATE TABLE [dbo].[PN_MusicDownload](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PageName] [nvarchar](300) NULL,
	[MediaId] [int] NULL,
	[MediaName] [nvarchar](100) NULL,
	[AppType] [int] NULL,
	[AlbumId] [int] NULL,
	[AlbumName] [nvarchar](100) NULL,
	[Price] [float] NULL,
	[MachineType] [nvarchar](50) NULL,
	[IMSI] [nvarchar](20) NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[ContentId] [nvarchar](20) NULL,
	[IntentFromId] [nvarchar](20) NULL,
	[IMEI] [nvarchar](50) NULL,
	[AndroidVer] [nvarchar](20) NULL,
	[EdreamVer] [nvarchar](50) NULL,
	[ClientVer] [nvarchar](20) NULL,
	[UserName] [nvarchar](100) NULL,
	[GUID] [nvarchar](50) NULL,
 CONSTRAINT [PK_PN_MusicDownload] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'自增id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'Id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载来源页面' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'PageName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐内容id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'MediaId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐内容名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'MediaName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'类型：3-音乐' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'AppType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'AlbumId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'AlbumName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'价格' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'Price'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'机型' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'MachineType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'用户唯一标志' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'IMSI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载开始时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'StartTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载结束时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'EndTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Android版本号' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'AndroidVer'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'客户端版本' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'ClientVer'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'用户名' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'UserName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载的order id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicDownload', @level2type=N'COLUMN',@level2name=N'GUID'
GO
/**end For PN_MusicDownload by Hu, Jingzhi**/
/**start For PN_S_MusicDownSource by Hu, Jingzhi**/
/****** Object:  Table [dbo].[PN_S_MusicDownSource]    Script Date: 07/03/2014 14:58:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_S_MusicDownSource'))
drop table PN_S_MusicDownSource

CREATE TABLE [dbo].[PN_S_MusicDownSource](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MediaName] [nvarchar](100) NULL,
	[AlbumName] [nvarchar](200) NULL,
	[Artist] [nvarchar](100) NULL,
	[Price] [float] NULL,
	[MusicAlbumDownCount] [int] NULL,
	[MyMusicDownCount] [int] NULL,
	[MusicAlbumDownCompleteCount] [int] NULL,
	[MyMusicDownCompleteCount] [int] NULL,
	[ContentSource] [nvarchar](20) NULL,
	[MachineType] [nvarchar](50) NULL,
	[TotalDownCount] [int] NULL,
	[TotalDownCompleteCount] [int] NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_S_MusicDownSource] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'MediaName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'AlbumName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'艺人名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'Artist'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'价格' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'Price'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐专辑下载统计' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'MusicAlbumDownCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'我的音乐下载统计' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'MyMusicDownCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐专辑下载成功统计' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'MusicAlbumDownCompleteCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'我的音乐下载成功统计' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'MyMusicDownCompleteCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载总数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'TotalDownCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'成功下载总数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'TotalDownCompleteCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建日期' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicDownSource', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

ALTER TABLE [dbo].[PN_S_MusicDownSource] ADD  CONSTRAINT [DF_PN_S_MusicDownSource_CreateTime]  DEFAULT (getdate()) FOR [CreateTime]
GO

/**end For PN_S_MusicDownSource by Hu, Jingzhi**/
/**start For SP_MusicDownSourceStatistic by Hu, Jingzhi**/
/****** Object:  StoredProcedure [dbo].[SP_MusicDownSourceStatistic]    Script Date: 07/15/2014 13:32:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: 下载来源 分析 只包括PlayNow，其中在做分析插入之前要做一次删除
-- =============================================
CREATE PROCEDURE [dbo].[SP_MusicDownSourceStatistic]
 -- Add the parameters for the stored procedure here
 @BeginTime Datetime, 
 @EndTime Datetime
AS
BEGIN
 -- SET NOCOUNT ON added to prevent extra result sets from
 -- interfering with SELECT statements.
 SET NOCOUNT ON;

declare @errorCount int 
set @errorCount=0 

begin  tran --开始事务

set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as date) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as date)) --结束时间


-- 分析前先删除 某一时间段的数据
delete from  PN_S_MusicDownSource where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- PlayNow 音乐下载来源 分析
insert into PN_S_MusicDownSource(
  MediaName, AlbumName, Artist, Price, MusicAlbumDownCount, MyMusicDownCount, 
  MusicAlbumDownCompleteCount, MyMusicDownCompleteCount, ContentSource, 
  MachineType, TotalDownCount, TotalDownCompleteCount, CreateTime
)

SELECT  pmd.MediaName AS 音乐名称,
  pmd.AlbumName AS 专辑名称, 
  pmi.Artist AS Artist,
  pmd.Price AS 价格,
  SUM(CASE WHEN  (pmd.pageName='专辑详情') THEN 1 ELSE 0 END) 专辑详情下载统计,
  SUM(CASE WHEN  (pmd.pageName='我的音乐') THEN 1 ELSE 0 END) 我的音乐下载统计,
  SUM(CASE WHEN  (pmd.pageName='专辑详情') and (pmd.EndTime is not null) THEN 1 ELSE 0 END) 专辑详情下载完成统计,
  SUM(CASE WHEN  (pmd.pageName='我的音乐') and (pmd.EndTime is not null) THEN 1 ELSE 0 END) 我的音乐下载完成统计,
  'PlayNow',
  pmd.MachineType, 
  COUNT(pmd.StartTime) as 下载数,
  SUM(CASE WHEN pmd.EndTime is not null   THEN 1 else 0 end) 成功下载数,
  cast( convert(varchar(10),pmd.StartTime,120)as datetime) CreateTime
FROM dbo.PN_MusicDownload pmd LEFT JOIN PlayNow.dbo.PN_MusicInfo pmi ON pmd.MediaId = pmi.ID

WHERE pmd.StartTime>= @BeginTime  AND pmd.StartTime < @EndTime

 Group by  cast( convert(varchar(10),pmd.StartTime,120)as datetime), pmd.MachineType,pmd.MediaName,pmd.AlbumName,pmd.Price,pmi.Artist

set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

 begin

  rollback --如果有错，就回滚事务

 end

else

 begin

  commit tran --如果没有错，就提交事务

 
 end

END
GO
/**end For SP_MusicDownSourceStatistic by Hu, Jingzhi**/

/**start for adding procedure SP_MusicPVStatistic by Wei,Devin**/
if(exists(select * from INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_MusicPVStatistic'))
DROP PROCEDURE SP_MusicPVStatistic

/****** 对象:  StoredProcedure [dbo].[SP_MusicPVStatistic]    脚本日期: 07/07/2014 02:57:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: Music-PV  分析 包括PlayNow，其中在做分析插入之前要做一次删除
-- =============================================

CREATE PROCEDURE [dbo].[SP_MusicPVStatistic]
 -- Add the parameters for the stored procedure here
 @BeginTime Datetime,
 @EndTime Datetime
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;
--错误的累加
declare @errorCount int
set @errorCount=0


begin  tran --开始事务

--declare @BeginTime datetime
--declare @EndTime datetime
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as datetime)) --结束时间

-- 分析前先删除某一时间段的数据
delete from  dbo.PN_S_MusicPV where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- PlayNow Client-pv 分析
insert into dbo.PN_S_MusicPV(
  MusicChannel,MusicAlbum,MyMusic,ContentId,ContentOrigin, MachineType,CreateTime
)

SELECT
SUM(CASE WHEN PageName = '音乐' THEN 1 ELSE 0 END) 音乐频道,
SUM(CASE WHEN PageName = '专辑详情' THEN 1 ELSE 0 END) 音乐专辑,
SUM(CASE WHEN PageName = '我的音乐' THEN 1 ELSE 0 END) 我的音乐,
ContentId,
'playnow',
MachineType,
cast( convert(varchar(10),CreateTime,120) as datetime)
from dbo.PN_Log_PageViewInfo_Music
where (IntentFromId !=3 or IntentFromId is null) and  CreateTime>=@BeginTime and  CreateTime<@EndTime
Group by cast( convert(varchar(10),CreateTime,120) as datetime),MachineType,ContentId
set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

 begin

  rollback --如果有错，就回滚事务

 end

else

 begin

  commit tran --如果没有错，就提交事务

 end

END
GO
/**end for adding procedure SP_MusicPVStatistic by Wei,Devin**/
/**start for adding table PN_S_MusicPV by Wei,Devin**/
if(not exists(select * from information_schema.tables where table_name = 'PN_S_MusicPV'))
begin
/****** 对象:  Table [dbo].[PN_S_MusicPV]    脚本日期: 07/07/2014 03:05:43 ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[PN_S_MusicPV](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MusicChannel] [int] NULL,
	[MusicAlbum] [int] NULL,
	[MyMusic] [int] NULL,
	[ContentId] [nvarchar](20) NULL,
	[ContentOrigin] [nvarchar](20) NULL,
	[MachineType] [nvarchar](50) NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_S_MusicPV] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'ID'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐频道' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'MusicChannel'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐专辑' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'MusicAlbum'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'我的音乐' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'MyMusic'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容Id，包括：专辑Id，如不存在则为空' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'ContentId'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'内容来源：（playNow,百度等等）' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'ContentOrigin'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'机型' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'MachineType'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建日期' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_MusicPV', @level2type=N'COLUMN',@level2name=N'CreateTime'
end
GO
/**end for adding table PN_S_MusicPV by Wei,Devin**/
/**start for adding table PN_S_Message_Music by Wei,Devin**/
IF(NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_S_Message_Music'))
BEGIN
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[PN_S_Message_Music](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MessageID] [int] NULL,
	[MachineType] [nvarchar](50) NULL,
	[GetMessage] [int] NULL,
	[ReadMessage] [int] NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_S_Message_Music] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message_Music', @level2type=N'COLUMN',@level2name=N'ID'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'消息ID ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message_Music', @level2type=N'COLUMN',@level2name=N'MessageID'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'机型' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message_Music', @level2type=N'COLUMN',@level2name=N'MachineType'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'获取消息数量' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message_Music', @level2type=N'COLUMN',@level2name=N'GetMessage'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'阅读消息次数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message_Music', @level2type=N'COLUMN',@level2name=N'ReadMessage'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建日期' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_S_Message_Music', @level2type=N'COLUMN',@level2name=N'CreateTime'
END
GO
/**end for adding table PN_S_Message_Music by Wei,Devin**/
/**start for adding table SP_MusicMessageStatistic by Wei,Devin**/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF(EXISTS(SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_MusicMessageStatistic'))
DROP PROCEDURE SP_MusicMessageStatistic
GO

CREATE PROCEDURE [dbo].[SP_MusicMessageStatistic]
			-- Add the parameters for the stored procedure here
			@BeginTime Datetime, 
			@EndTime Datetime
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;

		--declare @errorCount int=0 --错误的累加
		declare @errorCount int 
		set @errorCount=0 
		begin  tran --开始事务

		set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
		set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间


		-- 分析前先删除 某一时间段的数据
		delete from  dbo.PN_S_Message_Music where CreateTime>=@BeginTime and  CreateTime<@EndTime

		-- 消息统计 分析
			insert into dbo.PN_S_Message_Music(
			 MessageID, MachineType, GetMessage,
			 ReadMessage, CreateTime
			)


				SELECT  MessageId, MachineType, COUNT(*) as GetCount, 
						(select COUNT(*) from [PN_Log_PageViewInfo_Music] as B 
						where C.MessageId=B.MessageId AND IntentFromId=4 and
						cast( convert(varchar(10),B.CreateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
						and B.MachineType=C.MachineType
						 )as PVCount, 
						cast( convert(varchar(10),CreateTime,120)as datetime) dTime
				FROM 
				(
				select plm.* 
				from [PN_log_Message] as plm,[PlayNow].[dbo].[PN_Message] pm
				where  CreateTime>=@BeginTime AND CreateTime<@EndTime    
				and MessageId>0 
				AND	IsValid=1
				and plm.MessageId = pm.Id
				and pm.Type in (3,4)
				) as C
				group by cast( convert(varchar(10),CreateTime,120) as datetime),MessageId,MachineType		
				
		set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加
		if(@errorCount>0)
			begin
				rollback --如果有错，就回滚事务
			end
		else
			begin
				commit tran --如果没有错，就提交事务
			end
		END
GO
/**end for adding table SP_MusicMessageStatistic by Wei,Devin**/
/**start for  modifying table SP_MessageStatistic by Wei,Devin**/
IF(EXISTS(SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_MessageStatistic'))
DROP PROCEDURE SP_MessageStatistic
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	消息统计 分析 其中在做分析插入之前要做一次删除
-- =============================================
CREATE PROCEDURE [dbo].[SP_MessageStatistic]
	-- Add the parameters for the stored procedure here
	@BeginTime Datetime, 
	@EndTime Datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--declare @errorCount int=0 --错误的累加
--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点
--2013/7/4 jiaoxuhuan 在获取数量时添加MachineType过滤条件（例:and A.MachineType=C.MachineType）

declare @errorCount int 
set @errorCount=0 

begin  tran --开始事务


--set @BeginTime=CAST(@BeginTime as date) --开始时间
--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间


-- 分析前先删除 某一时间段的数据
delete from  dbo.PN_S_Message where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- 消息统计 分析
	insert into dbo.PN_S_Message(
	 MessageID, MachineType, GetMessage,
	 ReadMessage, DownCount,  
	 DownCompleteCount, InstallCount, CreateTime
	)


		SELECT  MessageId, MachineType, 
				(
				select COUNT(*) from [PN_Log_Message] as A 
				 where C.MessageId=A.MessageId and IsValid=1 and   
				--CAST(A.CreateTime as date)=cast(C.CreateTime as date) ) as GetCount, 
				cast( convert(varchar(10),A.CreateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime) 
				and A.MachineType=C.MachineType
				) as GetCount, 
				(select COUNT(*) from [PN_Log_PageViewInfo] as B 

				where C.MessageId=B.ContentId AND IntentFromId=4 and

				-- CAST(B.DateTime as date)=cast(C.CreateTime as date) ) as PVCount,
				cast( convert(varchar(10),B.DateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
				and B.MachineType=C.MachineType
				 )as PVCount,
				(
				select COUNT(*) from [PN_Order] as D 

				where C.MessageId=D.ContentId and IntentFromId=4 and

				 --CAST(D.StartTime as date)=cast(C.CreateTime as date) ) as DownCount,
				 cast( convert(varchar(10),D.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
				 and D.MachineType=C.MachineType
				  )as DownCount,
				 (select COUNT(*) from [PN_Order] as G 

				   where C.MessageId=G.ContentId and IntentFromId=4 and

				  -- CAST(G.StartTime as date)=cast(C.CreateTime as date)  
					cast( convert(varchar(10),G.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
					and G.MachineType=C.MachineType
				   and EndTime is not null) as DownCompleteCount
				,
				 (select COUNT(*) from [PN_Order] as H
				   where C.MessageId=H.ContentId and IntentFromId=4 and 
					cast( convert(varchar(10),H.InstallTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
					and H.MachineType=C.MachineType
				   and IsInstalled = 1) as InstallCount
				,cast( convert(varchar(10),CreateTime,120)as datetime) dTime
		FROM 
				(
				select plm.* 
				from [PN_log_Message] as plm,[PlayNow].[dbo].[PN_Message] pm
				where  CreateTime>=@BeginTime AND CreateTime<@EndTime    
				and MessageId>0 
				AND	IsValid=1
				and plm.MessageId = pm.Id
				and pm.Type = 1
				) as C
				group by cast( convert(varchar(10),CreateTime,120) as datetime),MessageId,MachineType	




set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

	begin

		rollback --如果有错，就回滚事务

	end

else

	begin

		commit tran --如果没有错，就提交事务

	
	end

END
GO
/**end for  modifying table SP_MessageStatistic by Wei,Devin**/
/**start For V_PN_MusicOrder by Hu, Jingzhi**/
/****** Object:  View [dbo].[V_PN_MusicOrder]    Script Date: 07/15/2014 14:37:40 ******/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'V_PN_MusicOrder'))
drop view V_PN_MusicOrder

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[V_PN_MusicOrder]
AS
SELECT pa.Name AS AlbumName, pmi.Name AS MusicName, pmi.Artist as Artist, pmo.Price AS Price, cast( convert(varchar(10),pmo.CreateTime,120)as datetime) AS CreateTime
FROM PlayNow.dbo.PN_MusicOrder pmo
     LEFT JOIN PlayNow.dbo.PN_Album pa ON pmo.AlbumId = pa.ID
     LEFT JOIN PlayNow.dbo.PN_MusicInfo pmi ON pmo.MusicId = pmi.ID
where pmo.AcquistionTime is not null

GO
/**end For V_PN_MusicOrder by Hu, Jingzhi**/