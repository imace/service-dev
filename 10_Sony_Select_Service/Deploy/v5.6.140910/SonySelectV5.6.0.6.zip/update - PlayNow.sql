﻿USE [PlayNow]
GO
/**start For create table PN_Album by Wei,Devin**/
if(not exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Album'))
begin
CREATE TABLE [dbo].[PN_Album](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](200) NULL,
	[Artist] [nvarchar](100) NULL,
	[SmallIcon] [nvarchar](150) NULL,
	[LargeIcon] [nvarchar](150) NULL,
	[Description] [ntext] NULL,
	[IsHiRes] [bit] NULL,
	[Format] [nvarchar](50) NULL,
	[Bitrate] [nvarchar](50) NULL,
	[Corporation] [nvarchar](200) NULL,
	[ReleaseTime] [datetime] NULL,
	[IsDeleted] [bit] NULL CONSTRAINT [DF_PN_Album_IsDeleted]  DEFAULT ((0)),
	[CreateTime] [datetime] NULL CONSTRAINT [DF_PN_Album_CreateTime]  DEFAULT ((getdate()))
 CONSTRAINT [PK_PN_Album] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'自增ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'ID'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'Name'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'艺人名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'Artist'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'小图标' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'SmallIcon'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'大图标' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'LargeIcon'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'描述' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'Description'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'是否HiRes,0:否；1:是' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'IsHiRes'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐格式' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'Format'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'码率' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'Bitrate'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'发行公司' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'Corporation'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑发布时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'ReleaseTime'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'是否删除的专辑' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'IsDeleted'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Album', @level2type=N'COLUMN',@level2name=N'CreateTime'
end

/**end For create table PN_Album by Wei,Devin**/		
/****/

/**start For create table PN_AlbumCategory by Nie, Kevin**/
if(not exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_AlbumCategory'))
begin
CREATE TABLE [dbo].[PN_AlbumCategory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[IsDeleted] [bit] NULL CONSTRAINT [DF_PN_AlbumCategory_IsDeleted]  DEFAULT ((0)),
	[CreateTime] [datetime] NULL CONSTRAINT [DF_PN_AlbumCategory_CreateTime]  DEFAULT (getdate())
CONSTRAINT [PK_PN_AlbumCategory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'主键, 自增ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategory', @level2type=N'COLUMN',@level2name=N'ID'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑分类名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategory', @level2type=N'COLUMN',@level2name=N'Name'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'是否删除的分类(0:否；1:是)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategory', @level2type=N'COLUMN',@level2name=N'IsDeleted'

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategory', @level2type=N'COLUMN',@level2name=N'CreateTime'

end
/**end For create table PN_AlbumCategory by Nie, Kevin**/

/**start For create table PN_AlbumCategoryDetail by Wei, Devin**/
if(not exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_AlbumCategoryDetail'))
begin
CREATE TABLE [dbo].[PN_AlbumCategoryDetail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AlbumId] [int] NOT NULL,
	[AlbumCategoryId] [int] NOT NULL,
	[CreateTime] [datetime] NULL CONSTRAINT [DF_PN_AlbumCategoryDetail_CreateTime]  DEFAULT (getdate())
) ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'主键, 自增ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategoryDetail', @level2type=N'COLUMN',@level2name=N'ID'
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑Id;外键，PN_Album的id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategoryDetail', @level2type=N'COLUMN',@level2name=N'AlbumId'
ALTER TABLE [dbo].[PN_AlbumCategoryDetail]  WITH NOCHECK ADD  CONSTRAINT [FK_ALBUMCATEGORYDETAIL_ALBUMID] FOREIGN KEY([AlbumId])
REFERENCES [dbo].[PN_Album] ([ID])
ON UPDATE CASCADE
ON DELETE CASCADE
ALTER TABLE [dbo].[PN_AlbumCategoryDetail] CHECK CONSTRAINT [FK_ALBUMCATEGORYDETAIL_ALBUMID]
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑分类Id;外键，PN_AlbumCategory的id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategoryDetail', @level2type=N'COLUMN',@level2name=N'AlbumCategoryId'
ALTER TABLE [dbo].[PN_AlbumCategoryDetail]  WITH NOCHECK ADD  CONSTRAINT [FK_ALBUMCATEGORYDETAIL_ALBUMCATEGORYID] FOREIGN KEY([AlbumCategoryId])
REFERENCES [dbo].[PN_AlbumCategory] ([ID])
ON UPDATE CASCADE
ON DELETE CASCADE
ALTER TABLE [dbo].[PN_AlbumCategoryDetail] CHECK CONSTRAINT [FK_ALBUMCATEGORYDETAIL_ALBUMCATEGORYID]
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumCategoryDetail', @level2type=N'COLUMN',@level2name=N'CreateTime'
end

/**end For create table PN_AlbumCategoryDetail by Wei, Devin**/


/**begin insert album in PN_Module by Nie, Kevin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
INSERT INTO [dbo].[PN_Module]([MenuId] ,[ModuleName] ,[ModulePath]) VALUES (7 , '专辑分类管理', 'Music/AlbumCategory.aspx')
INSERT INTO [dbo].[PN_Module]([MenuId] ,[ModuleName] ,[ModulePath]) VALUES (7 , '专辑管理', 'Music/Album.aspx')
INSERT INTO [dbo].[PN_Module]([MenuId] ,[ModuleName] ,[ModulePath]) VALUES (7 , '专辑/类型关系管理', 'Music/AlbumCategoryDetail.aspx')
INSERT INTO [dbo].[PN_Module]([MenuId] ,[ModuleName] ,[ModulePath]) VALUES (7 , '音乐管理', 'Music/MusicInfo.aspx')
INSERT INTO [dbo].[PN_Module]([MenuId] ,[ModuleName] ,[ModulePath]) VALUES (7 , '专辑/音乐关系管理', 'Music/AlbumDetail.aspx')
/**end for insert album in PN_Module by Nie, Kevin**/


/**begin insert MusicDownloadDetail in PN_Module by Nie, Kevin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
INSERT INTO [dbo].[PN_Module]([MenuId] ,[ModuleName] ,[ModulePath]) VALUES (3 , '音乐下载和收费明细', 'Statistic/MusicDownloadDetail.aspx')
/**end for insert MusicDownloadDetail in PN_Module by Nie, Kevin**/


/**start For PN_MusicInfo by Hu,Jingzhi**/
/****** Object:  Table [dbo].[PN_MusicInfo]    Script Date: 06/13/2014 16:29:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_MusicInfo'))
drop table PN_MusicInfo

CREATE TABLE [dbo].[PN_MusicInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Artist] [nvarchar](100) NULL,
	[Size] [decimal](10, 2) NULL,
	[Description] [ntext] NULL,
	[Icon] [nvarchar](300) NULL,
	[Duration] [nvarchar](10) NULL,
	[Price] [decimal](5, 2) NULL,
	[DownloadUrl] [nvarchar](300) NULL,
	[IsDeleted] [bit] NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_MusicInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'主键, 自增ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'歌曲名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'艺人名称' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Artist'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'歌曲大小' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Size'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'描述' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'歌曲图标' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Icon'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐长度,如”05:30”代表5分30秒' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Duration'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'价格' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'Price'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'下载地址' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'DownloadUrl'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'是否删除的音乐, 0表示未删除, 1表示已删除' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'IsDeleted'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicInfo', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

ALTER TABLE [dbo].[PN_MusicInfo] ADD  CONSTRAINT [DF_PN_MusicInfo_Price]  DEFAULT ((0)) FOR [Price]
GO

ALTER TABLE [dbo].[PN_MusicInfo] ADD  CONSTRAINT [DF_PN_MusicInfo_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
GO

ALTER TABLE [dbo].[PN_MusicInfo] ADD  CONSTRAINT [DF_PN_MusicInfo_CreateTime]  DEFAULT (getdate()) FOR [CreateTime]
GO

/**end For PN_MusicInfo by Hu,Jingzhi**/
/**start For PN_AlbumDetail by Hu,Jingzhi**/
/****** Object:  Table [dbo].[PN_AlbumDetail]    Script Date: 06/13/2014 16:31:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_AlbumDetail'))
drop table PN_AlbumDetail

CREATE TABLE [dbo].[PN_AlbumDetail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AlbumId] [int] NOT NULL,
	[MusicId] [int] NOT NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_AlbumDetail] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [PN_AlbunDetail_AlbumId_MusicId] UNIQUE NONCLUSTERED 
(
	[AlbumId] ASC,
	[MusicId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'主键, 自增ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumDetail', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑Id,外键,PN_Album的id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumDetail', @level2type=N'COLUMN',@level2name=N'AlbumId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'音乐Id,外键,PN_MusicInfo的id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumDetail', @level2type=N'COLUMN',@level2name=N'MusicId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AlbumDetail', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

ALTER TABLE [dbo].[PN_AlbumDetail]  WITH CHECK ADD  CONSTRAINT [FK_PN_AlbumDetail_PN_Album] FOREIGN KEY([AlbumId])
REFERENCES [dbo].[PN_Album] ([ID])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[PN_AlbumDetail] CHECK CONSTRAINT [FK_PN_AlbumDetail_PN_Album]
GO

ALTER TABLE [dbo].[PN_AlbumDetail]  WITH CHECK ADD  CONSTRAINT [FK_PN_AlbumDetail_PN_MusicInfo] FOREIGN KEY([MusicId])
REFERENCES [dbo].[PN_MusicInfo] ([ID])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[PN_AlbumDetail] CHECK CONSTRAINT [FK_PN_AlbumDetail_PN_MusicInfo]
GO

ALTER TABLE [dbo].[PN_AlbumDetail] ADD  CONSTRAINT [DF_PN_AlbumDetail_CreateTime]  DEFAULT (getdate()) FOR [CreateTime]
GO

/**end For PN_AlbumDetail by Hu,Jingzhi**/

/**start For PN_MusicOrder by Hu, Jingzhi**/
/****** Object:  Table [dbo].[PN_MusicOrder]    Script Date: 06/16/2014 15:51:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_MusicOrder'))
drop table PN_MusicOrder

CREATE TABLE [dbo].[PN_MusicOrder](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[OrderId] [nvarchar](50) NULL,
	[Uid] [int] NOT NULL,
	[IMEI] [nvarchar](50) NULL,
	[AlbumId] [int] NOT NULL,
	[MusicId] [int] NOT NULL,
	[Price] [decimal](5, 2) NULL,
	[AcquistionTime] [datetime] NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_MusicOrder] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'主键, 自增ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'订单Id, GUID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'OrderId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'系统内部的用户ID, 外键，PN_UserInfo的ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'Uid'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'IMEI' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'IMEI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'专辑Id, 外键，PN_Album的ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'AlbumId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'歌曲Id, 外键，PN_MusicOrder的ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'MusicId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'价格' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'Price'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'购买时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'AcquistionTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'创建时间' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_MusicOrder', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

ALTER TABLE [dbo].[PN_MusicOrder]  WITH CHECK ADD  CONSTRAINT [FK_PN_MusicOrder_PN_Album] FOREIGN KEY([AlbumId])
REFERENCES [dbo].[PN_Album] ([ID])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[PN_MusicOrder] CHECK CONSTRAINT [FK_PN_MusicOrder_PN_Album]
GO

ALTER TABLE [dbo].[PN_MusicOrder]  WITH CHECK ADD  CONSTRAINT [FK_PN_MusicOrder_PN_MusicInfo] FOREIGN KEY([MusicId])
REFERENCES [dbo].[PN_MusicInfo] ([ID])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[PN_MusicOrder] CHECK CONSTRAINT [FK_PN_MusicOrder_PN_MusicInfo]
GO

ALTER TABLE [dbo].[PN_MusicOrder] ADD  CONSTRAINT [DF_PN_MusicOrder_Uid]  DEFAULT ((-1)) FOR [Uid]
GO

ALTER TABLE [dbo].[PN_MusicOrder] ADD  CONSTRAINT [DF_PN_MusicOrder_CreateTime]  DEFAULT (getdate()) FOR [CreateTime]
GO
/**end For PN_MusicOrder by Hu, Jingzhi**/

/**start for adding MusicBatchUpLoad in PN_Module by Hu, Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
INSERT INTO [dbo].[PN_Module] ([MenuId], [ModuleName], [ModulePath]) VALUES (4, N'音乐批量上传', N'Batch/MusicBatchUpLoad.aspx')
/**end for adding MusicBatchUpLoad in PN_Module by Hu, Jingzhi**/

/**start for adding Music-PV in PN_Module by Wei, Devin**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
begin
insert into PN_Module([MenuId],[ModuleName],[ModulePath]) values(3,'Music-PV','Statistic/MusicPV.aspx')
insert into PN_Module([MenuId],[ModuleName],[ModulePath]) values(3,'Music-PVByDate','Statistic/MusicPVByDate.aspx')
end
/**end for adding Music-PV in PN_Module by Wei, Devin**/

/**start for adding music download in PN_Module by Hu Jingzhi**/
if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'PN_Module'))
begin
INSERT INTO [dbo].[PN_Module] ([MenuId], [ModuleName], [ModulePath]) VALUES (3, N'音乐下载和收费', N'Music/MusicDownAndOrder.aspx')
INSERT INTO [dbo].[PN_Module] ([MenuId], [ModuleName], [ModulePath]) VALUES (3, N'音乐购买按日期统计', N'Music/MusicOrderCountByDate.aspx')
INSERT INTO [dbo].[PN_Module] ([MenuId], [ModuleName], [ModulePath]) VALUES (3, N'我的音乐页面下载完成按日期统计', N'Music/MyMusicDownCountByDate.aspx')
INSERT INTO [dbo].[PN_Module] ([MenuId], [ModuleName], [ModulePath]) VALUES (3, N'专辑详情页面下载完成按日期统计', N'Music/AlbumDetailDownCountByDate.aspx')
INSERT INTO [dbo].[PN_Module] ([MenuId], [ModuleName], [ModulePath]) VALUES (3, N'音乐收入统计', N'Music/MusicIncomingCountByDate.aspx')
end
/**end for adding music download in PN_Module by Hu Jingzhi**/