USE [PlayNow]
GO

/****** ����:  Table [dbo].[PN_WidgeUpdateStatus]    �ű�����: 03/31/2014 21:22:47 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PN_WidgeUpdateStatus]') AND type in (N'U'))
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PN_WidgeUpdateStatus](
                [ID] [int] IDENTITY(1,1) NOT NULL,
                [IMEI] [nvarchar](50) NOT NULL,
                [IsAppUpdated] [int] NULL DEFAULT ((0)),
                [IsGameUpdated] [int] NULL DEFAULT ((0)),
                [IsAdUpdated] [int] NULL DEFAULT ((0))
) ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IDX_PN_WidgeUpdateStatus_IMEI] ON [dbo].[PN_WidgeUpdateStatus] 
(
                [IMEI] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_WidgeUpdateStatus', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ֻ�IMEI��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_WidgeUpdateStatus', @level2type=N'COLUMN',@level2name=N'IMEI'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ʶWidgetӦ���б��Ƿ��ѱ����£�
0��δ����
1���Ѹ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_WidgeUpdateStatus', @level2type=N'COLUMN',@level2name=N'IsAppUpdated'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ʶWidget��Ϸ�б��Ƿ��ѱ����£�
0��δ����
1���Ѹ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_WidgeUpdateStatus', @level2type=N'COLUMN',@level2name=N'IsGameUpdated'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ʶWidget����б��Ƿ��ѱ����£�
0��δ����
1���Ѹ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_WidgeUpdateStatus', @level2type=N'COLUMN',@level2name=N'IsAdUpdated'
GO
/**End    For Flow Control Issue by Wei,Devin**/
