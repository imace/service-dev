﻿(function ($) {
    $.fn.loadHtml = function (option) {
        var self = this;
        $(self).data('loadcount', 1);
        $(self).data('no_need_scroll', 0);
        $(self).data('baiduCacheIndex',0);
        var _option = {
            url:'',
            loading: 'remote',
            pageSize: 10,
            keywords: '',
            totalSearchTimes:10,
            templateId: 'template',
            iframe:false,
            onDownloadImgClicked: function (data) { },
            onSuccess: function (data) { },
            onError: function () { },
            onNoMoreData: function () { },
            onBeforeScroll: function () { },
            onPostRenderAppList: function (objData,html,isNewItem) { },
            onPostRenderBaiduAppList: function (objData, html, isNewItem) { },
            onPostRenderRecommendList: function (objData, html, isNewItem) { },
            onDetailDivClicked: function (data) { },
            onNoResultFound: function () { },
            onPerCompleted: function (id) { }
        };
        $.extend(_option, option || {});
        var sc = new Scroller();

        function scroll() {
            if ($(self).data('no_need_scroll') == 1) {
                return;
            }
            sc.scroll(function () {
                loadDataByHitBottom();
            }, function () {
                return isAjaxBusy();
            }, function () {
                onBeforeScroll();
            });
        }
        loadData(0);
        $(window).bind('scroll', function () {
            scroll();
        });
        document.body.onscroll = scroll;
        //加载数据
        function loadData(startIndex) {
            var ps = [];
            ps.push('searchKey=' + _option.keywords);
            ps.push('pageIndex=' + startIndex);
            ps.push('pageSize=' + _option.pageSize);
            var baiduCacheIndex = $(self).data('baiduCacheIndex');
            ps.push('baiduCacheIndex='+ baiduCacheIndex);
            var params = ps.join('&');
            //alert(params);
            $.Process({
                loading: _option.loading,
                id: $(self).attr('id'),
                params: params,
                iframe:_option.iframe,
                url: _option.url,
                onSuccess: function (id, data) { /*$('#loading').hide();*/ _option.onSuccess(data); $(self).data('isLoading', false);  },
                onError: function () {  $(self).data('no_need_scroll', 1); _option.onError(); },
                onRender: function (id, data) {
                    var BaiduCacheIndex = data.BaiduCacheIndex;
                    if (BaiduCacheIndex == null || isNaN(BaiduCacheIndex)) {
                        BaiduCacheIndex = 0;
                    }
                    $(self).data('baiduCacheIndex', BaiduCacheIndex);
                    //$('#loading').hide();
                    appendToHtml(data);
                    _option.onPerCompleted(id);
                },
            });
        }

        function appendToHtml(data) {
            //var renderer = new Renderer();
            if (data == null || parseInt(data.TotalCount) <= 0) {
                $(self).data('no_need_scroll',1);
                _option.onNoMoreData();
                return false;
            }
            //alert(data.RecommendedAppInfoList);
            if (data.PlayNowAppInfoList != 'undefined' && data.PlayNowAppInfoList != null && data.PlayNowAppInfoList.length>0) {
                renderPlayNowAppList(data.PlayNowAppInfoList);
            }
            if (data.BaiduAppInfoList != 'undefined' && data.BaiduAppInfoList != null && data.BaiduAppInfoList.length>0) {
                renderBaiduAppList(data.BaiduAppInfoList);
            }

            if (data.RecommendedAppInfoList != 'undefined' && data.RecommendedAppInfoList != null && data.RecommendedAppInfoList.length > 0) {
                renderRecommendAppList(data.RecommendedAppInfoList);
            }
        }

        

        function renderPlayNowAppList(data) {
            var renderer = new Renderer(_option.templateId, data);
            if ($(self).data('loadPlayNow') ==true) {
                renderer.renderOnlyNest(function (objData,html) {
                    _option.onPostRenderAppList(objData,html, false);
                },
                function (rowHtml, rowData) {
                    return convertRow(rowHtml, rowData);
                });
            } else {
                $(self).data('loadPlayNow',true);
                renderer.render(function (objData,html) {
                    html = html.replace(/__GLOBAL_TITLE__/, 'PlayNow搜索结果');
                    _option.onPostRenderAppList(objData,html,true);
                },
                function (rowHtml, rowData) {
                    return convertRow(rowHtml, rowData);
                });
            }
           
        }

        function renderBaiduAppList(data) {
            var renderer = new Renderer(_option.templateId, data);
            if ($(self).data('loadBaidu')==true) {
                renderer.renderOnlyNest(function (objData, html) {
                    //alert(html);
                    _option.onPostRenderBaiduAppList(objData,html,false);
                },
                function (rowHtml, rowData) {
                    return convertRow(rowHtml, rowData);
                });
            } else {
                $(self).data('loadBaidu', true);
                renderer.render(function (objData, html) {
                    html = html.replace(/__GLOBAL_TITLE__/, '站外搜索结果[百度提供]');
                    _option.onPostRenderBaiduAppList(objData,html,true);
                },
                function (rowHtml, rowData) {
                    return convertRow(rowHtml, rowData);
                });
            }
           
        }

        function renderRecommendAppList(data) {
            $(self).data('no_need_scroll', 1);
            if (typeof _option.onNoResultFound == 'function') {
                _option.onNoResultFound();
            }
            var renderer = new Renderer(_option.templateId, data);
            renderer.render(function (objData, html) {
                html = html.replace(/__GLOBAL_TITLE__/, 'PlayNow推荐');
                _option.onPostRenderRecommendList(objData,html,true);
            },
            function (rowHtml, rowData) {
                return convertRow(rowHtml, rowData);
            }

            );
        }

        function convertRow(rowHtml, rowData) {
            //alert(rowHtml);
            var goodStar = 11 * parseInt(rowData.Grade);
            var badStar = 11 * (5 - parseInt(rowData.Grade));
            var row = rowHtml.replace(/__GOOD_STAR__/, goodStar).replace(/__BAD_STAR__/, badStar);
            
           /* $('.download', rowObj).live('click', function (event) {
                alert('clicked');
                _option.onDownloadImgClicked(rowData);
            });
            $('.content-row', rowObj).live('click', function (event) {
                _option.onDetailDivClicked(rowData);
            });*/
            return row;
        }

        function isAjaxBusy() {
            var isBusy = $(self).data('isLoading');
            if (isBusy == null || isBusy == false) {
                return false;
            } else {
                return true;
            }
        }

        function onBeforeScroll() {
            if (typeof _option.onBeforeScroll == 'function') {
                _option.onBeforeScroll();
            }
        }

        function loadDataByHitBottom() {
            if ($(self).data('isLoading') == true) {
                return false;
            }
            if ($(self).data('no_need_scroll') == 1 || $(self).data('loadcount') > _option.totalSearchTimes ) {
                if (typeof _option.onNoMoreData == 'function') {
                    _option.onNoMoreData();
                }
                return;
            }
            $(self).data('isLoading', true);
            var loadcount = $(self).data('loadcount');
            $(self).data('loadcount', parseInt(loadcount + 1));
            //var startIndex = loadcount * _option.pageSize + 1;
            loadData(loadcount);
        }

    };
})(jQuery);

