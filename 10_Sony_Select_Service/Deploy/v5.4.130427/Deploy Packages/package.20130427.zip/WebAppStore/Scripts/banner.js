﻿/***
 * banner 动态拖动效果
 * Author：Chris Cheng（程天亮）
 */

(function ($) {
    var Tween = {
        Quart: {
            /*
             * t: current time（当前时间）；
                b: beginning value（初始值）；
                c: change in value（变化量）；
                d: duration（持续时间）。
             */
            easeOut: function (t, b, c, d) {
                //alert('called');
                return -c * ((t = t / d - 1) * t * t * t - 1) + b;
            }
        },
        Back: {
            easeOut: function (t, b, c, d, s) {
                if (s == undefined) s = 1.70158;
                return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
            }
        },
        Bounce: {
            easeOut: function (t, b, c, d) {
                if ((t /= d) < (1 / 2.75)) {
                    return c * (7.5625 * t * t) + b;
                } else if (t < (2 / 2.75)) {
                    return c * (7.5625 * (t -= (1.5 / 2.75)) * t + .75) + b;
                } else if (t < (2.5 / 2.75)) {
                    return c * (7.5625 * (t -= (2.25 / 2.75)) * t + .9375) + b;
                } else {
                    return c * (7.5625 * (t -= (2.625 / 2.75)) * t + .984375) + b;
                }
            }
        }
    };
    var Bind = function (object, fun) {
        var args = Array.prototype.slice.call(arguments).slice(2);
        return function () {
            return fun.apply(object, args.concat(Array.prototype.slice.call(arguments)));
        };
    };
    $.Banner = {
        _buildTemplate: function () {
            if (arguments.length >= 2) {
                $callBack = arguments[1];
                if (typeof $callBack == 'function') {
                    $tmplate = $callBack.call(arguments[0]);
                    return $tmplate;
                }
            }
            return '<div id="inbanner" class="inbanner"><div id="banner1" class="left"></div><div id="banner2" class="left"></div></div> <div><div class="left-banner-controller"></div><div class="left-banner-bg"></div></div><div><div class="right-banner-controller"></div><div class="right-banner-bg"></div></div>';
        },
        _setObjectId: function () {
            if (arguments.length == 0) {
                return false;
            }
            var obj = arguments[0];
            var id = $(obj).attr('id');
            if (id == 'undefined' || id == null) {
                var myDate = new Date();
                id = 'wrapper' + myDate.getSeconds();
                $(obj).attr('id', id);
            }
        },
        init: function () {
            if (arguments.length == 0) {
                return false;
            }
            var obj = arguments[0];
            $(obj).css('overflow', 'hidden');
            $(obj).empty();
            var template = this._buildTemplate.apply(this, arguments);
            $(obj).append(template);
            $(obj).data('hasLoaded', false);
            this._setObjectId(obj);
        }
    };
    $.fn.banner = function (option) {
        var _option = {
            loading: 'local', /*数据加载方式:local,remote*/
            url: '',
            countPerRow: 3, /*没有行排列数*/ 
            cls: "bannerImgCls",//img上的class name,主要定义width与height 
            iframe:false,
            data: [], /*本地数据*/
            useJsonMini: false,
            imgStyle:'',
            defaultImg: '',
            duration:50,
            delayTime:8,
            onItemClicked: function (row) { },
            onImageLoaded: function (img,width,height) { },
            convertData: function (row) {
                return row;
            }
        };
        $.extend(_option, option || {});
        var self = this;
        $.Banner.init(self);
        var t=0, b=0, c=0, d=_option.duration;
        var wrapperId = $(self).attr('id');
        var _timer = null;
        
        loadData();
        
        function loadData() {
            if ($(self).data('hasLoaded') == true) {
                return false;
            }
            if (_option.loading == 'local') {
                var data = _option.convertData(_option.data);
                render(data);
                $(self).data('hasLoaded', true);
            } else {
                $.Process({
                    loading: 'remote',
                    id: wrapperId,
                    url: _option.url,
                    onError:function(){},
                    onRender: function (id, data) { render(_option.convertData(data)); }
                });
            }
            return true;
        }

        function render(data) {
            var banner1 = $('#banner1', self);
            banner1.empty();
            for (var i = 0; i < data.length; i++) {
                var img = '<img src="'+_option.defaultImg+'" onerror="javascript:this.src=\''+_option.defaultImg+'\';"  index=' + i + ' id="banner_' + data[i].ContentId + '" style="z-index: 100;margin: 0 2px;padding: 0;';
                if (_option.imgStyle != '') {
                    img += _option.imgStyle;
                }
                img += '" class="banner_img left';
                if (_option.cls != '') {
                    img += ' ';
                    img += _option.cls;
                }
                img += ' image_' + i + '"';
                img +=' />';
                $(img).appendTo(banner1);
            }
            var banner2 = $('#banner2', self);
            banner2.html(banner1.html());
            $('img', banner1).on('click', function () {

                var index = $(this).attr('index');
                if (_option.onItemClicked) {
                    _option.onItemClicked(data[index]);
                }
            });
            $('img', banner2).on('click', function () {

                var index = $(this).attr('index');
                if (_option.onItemClicked) {
                    _option.onItemClicked(data[index]);
                }
            });
            bindEvent(self);
            $('img', self).each(function () {
                var index = $(this).attr('index');
                $(this).preLoadImg(data[index].BannerIcon, {
                    loaded: function (ele, src, width, height) {
                        ele.attr('src', src);
                        if (typeof _option.onImageLoaded == 'function') {
                            _option.onImageLoaded(ele,width,height);
                        }
                        ele.data('hasLoadedImg', true);
                        checkAndResetEvent(data.length);
                    }
                });
            });
            var imgWidth = $('img', banner1).width();
            //alert(imgWidth);
            move((-1) * imgWidth / 2);
            t = 0;
            b = imgWidth / 2;
            c = imgWidth;
        }

        function checkAndResetEvent(len) {
            var totalLenght = 0;
            for (var i = 0; i < len;i++) {
                var img = $('.image_' + i, self);
                if (img.data('hasLoadedImg') != true) {
                    return false;
                }
                totalLenght = totalLenght + parseInt(img.width());
            }
            if (totalLenght <= $(self).width()) {
                unBindEvent();
                $('#banner2').hide();
            }
        }

        var banner1 = $('#banner1', self).get(0);
        var banner2 = $('#banner2', self).get(0);
        var losing = 0;
        function move(duration) {
            //alert(duration);
            
            var banner1 = $('#banner1', self).get(0);
            var banner2 = $('#banner2', self).get(0);
            if (duration < 0) {
                //往左移动
                var dur = (-1) * duration;
                //self.get(0).scrollLeft -= dur;
                if (banner2.offsetWidth - self.get(0).scrollLeft <= 0)
                    self.get(0).scrollLeft -= banner1.offsetWidth
                else {
                    self.get(0).scrollLeft += dur;
                }
            } else {
                //往右移动
                if (self.get(0).scrollLeft <= 0)
                    self.get(0).scrollLeft += banner2.offsetWidth
                else {
                    self.get(0).scrollLeft -= duration;
                }
            }
            
        };

        function _Run(target) {
            t = 0;
            b = 0;
            c = target;
            losing = 0;
            //alert(c);
            _move();
        }

        function _move() {
            clearTimeout(_timer);
            //未到达目标继续移动否则进行下一次滑动
            //alert(_option.duration)
            
            if (c && t <= _option.duration) {
                //alert(c);
                //var rn = Math.abs();
                var duration = Math.round(Tween.Quart.easeOut(t++, b, c - losing, _option.duration));
                losing += duration;
                move(duration);
                //alert('after');
                _timer = setTimeout(_move, _option.delayTime);
            } 
        }

        function bindEvent() {
            /*$(self).get(0).addEventListener('touchstart', touchstart, false);
            $(self).get(0).addEventListener('touchmove', touchmove, false);
            $(self).get(0).addEventListener('touchend', touchend, false);*/
            $('.left-banner-controller', self).bind('click', function () {
                var imgWidth = $('img', self).width();
                _Run(imgWidth);
                //alert(imgWidth);
                //move((-1) * imgWidth);
            });
            $('.right-banner-controller', self).bind('click', function () {
                var imgWidth = $('img', self).width();
                //alert(imgWidth);
                _Run((-1) * imgWidth);
            });
            $('.left-banner-bg', self).bind('click', function () {
                var imgWidth = $('img', self).width();
                _Run(imgWidth);
            });
            $('.right-banner-bg', self).bind('click', function () {
                var imgWidth = $('img', self).width();
                _Run((-1) * imgWidth);
            });
        }

    }
})(jQuery)
