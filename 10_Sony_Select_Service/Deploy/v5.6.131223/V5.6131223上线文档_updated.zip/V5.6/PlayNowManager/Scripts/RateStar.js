﻿function __start() {
    var initialize_width = 0;
    if (document.getElelmentById) { return false };
    if (document.getElementsByTagName == null) { return false; }
    var startLevelObj = document.getElementById("divratestar")
    if (startLevelObj == null) { return false; }
    //初始宽度-图标宽度变动调整处★★★★★
    //initialize_width = parseInt(startLevelObj.getAttribute("star_width"), 10);
    initialize_width = 30;
    if (isNaN(initialize_width) || initialize_width == 0) { return false; }
    var ul_obj = startLevelObj.getElementsByTagName("ul");
    if (ul_obj.length < 1) { return false; }
    var length = ul_obj.length;
    var li_length = 0;
    var a_length = 0;
    var li_obj = null;
    var a_obj = null;
    var defaultInputObj = null;
    var defaultValue = null;
    for (var i = 0; i < length; i++) {
        li_obj = ul_obj[i].getElementsByTagName("li");
        li_length = li_obj.length;
        if (li_length < 0) { return false; }
        //获取默认值
        defaultInputObj = li_obj[0].getElementsByTagName("input"); 
        if (!defaultInputObj) { return false; }
        defaultValue = parseInt(defaultInputObj[0].value, 10);
        //alert(defaultValue);//初始值
        if (!isNaN(defaultValue) && defaultValue != 0) {
            //alert(defaultValue); //初始值
            li_obj[1].style.width = initialize_width * defaultValue + "px";
            defaultValue = 0;
        }
        for (var j = 0; j < li_length; j++) {
            a_obj = li_obj[j].getElementsByTagName("a");
            if (a_obj.length < 1) { continue; }
            if (a_obj[0].className.indexOf("star") > 0) {
                a_obj[0].onclick = function () {
                    return give_value(this);
                }
                a_obj[0].onfocus = function () {
                    this.blur();
                }
            }
        }
    }
} 

function give_value(obj) {
    var status = true;
    var parent_obj = obj.parentNode;
    var i = 0;
    while (status) {
        i++;
        if (parent_obj.nodeName == "UL") { break; }
        parent_obj = parent_obj.parentNode;
        if (i > 1000) { break; } //防止找不到ul发生死循环
    }
    var hidden_input = parent_obj.getElementsByTagName("input")[0];
    if (hidden_input.length < 1) { /*alert("sorry?\nprogram error!")*/; }
    var txt = obj.firstChild.nodeValue; //确保不能存在空格哦，因为这里用的firstChild
    if (isNaN(parseInt(txt, 10))) { /*alert('level error!')*/; return false; }
    //alert(txt.toString());//选择值
    hidden_input.setAttribute("value", txt.toString());
    //固定选中状态,先找到初始化颜色那个li
    var current_li = parent_obj.getElementsByTagName("li");
    var length = current_li.length;
    var ok_li_obj = null;
    for (var i = 0; i < length; i++) {
        if (current_li[i].className.indexOf("current_rating") >= 0) {
            ok_li_obj = current_li[i]; break; //找到
        }
    }
    //图标宽度变动调整处★★★★★
    __current_width = txt * 30;
    ok_li_obj.style.width = __current_width + "px";
    return false;
} 
__start();
