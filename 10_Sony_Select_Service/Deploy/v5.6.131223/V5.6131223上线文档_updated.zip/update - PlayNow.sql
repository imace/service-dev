USE [PlayNow]
GO

/****** For SSO feature, by Cai Tony. ******/
/****** Object:  Table [dbo].[PN_OAuthPlatform]    Script Date: 10/11/2013 14:28:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PN_OAuthPlatform](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OAuthPlatformID] [int] NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Enable] [bit] NULL,
	[PlatformLogoUri] [nvarchar](300) NULL,
	[AuthorizationReqUri] [nvarchar](300) NULL,
	[AccessTokenReqUri] [nvarchar](300) NULL,
	[RefreshTokenReqUri] [nvarchar](300) NULL,
	[GetUserIdReqUri] [nvarchar](300) NULL,
	[GetUserInfoReqUri] [nvarchar](300) NULL,
	[Client_id] [nvarchar](50) NULL,
	[Client_secret] [nvarchar](50) NULL,
 CONSTRAINT [PK_PN_OAuthPlatform] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[OAuthPlatformID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'֧�ֵĵ�������¼ƽ̨ID 1, QQ ; 2, Sina; 3, Baidu ;' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'OAuthPlatformID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������¼ƽ̨����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'Name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ�֧��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'Enable'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ƽ̨Logo��ַ (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'PlatformLogoUri'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������Ȩ��ַ (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'AuthorizationReqUri'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����������Ƶ�ַ (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'AccessTokenReqUri'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ˢ�����Ƶ�ַ (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'RefreshTokenReqUri'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����û�ID��ַ (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'GetUserIdReqUri'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����û���Ϣ��ַ (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'GetUserInfoReqUri'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ͻ�ID (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'Client_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Secret key (For solution 2)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_OAuthPlatform', @level2type=N'COLUMN',@level2name=N'Client_secret'
GO

insert PN_OAuthPlatform (OAuthPlatformID,Name,Enable,PlatformLogoUri,AuthorizationReqUri,AccessTokenReqUri,RefreshTokenReqUri,GetUserIdReqUri,GetUserInfoReqUri,Client_id,Client_secret)  values ( 2,'����΢��',1,'http://sonyselectdownload.baidu.com/SSC/accountIcon/dialog_sina_btn_icn.png','https://api.weibo.com/oauth2/authorize','https://api.weibo.com/oauth2/access_token','','https://api.weibo.com/2/account/get_uid.json','https://api.weibo.com/2/users/show.json','3659450228','d798a966e34fc7b1f7f5c3ba0a8ecd02')
insert PN_OAuthPlatform (OAuthPlatformID,Name,Enable,PlatformLogoUri,AuthorizationReqUri,AccessTokenReqUri,RefreshTokenReqUri,GetUserIdReqUri,GetUserInfoReqUri,Client_id,Client_secret)  values ( 3,'�ٶ��˻�',1,'http://sonyselectdownload.baidu.com/SSC/accountIcon/dialog_baidu_btn_icn.png','https://openapi.baidu.com/oauth/2.0/authorize','https://openapi.baidu.com/oauth/2.0/token','https://openapi.baidu.com/oauth/2.0/token','https://openapi.baidu.com/rest/2.0/passport/users/getLoggedInUser','https://openapi.baidu.com/rest/2.0/passport/users/getInfo','Xhv0xz1Yy19u9qM8oz4fVuye','G0HaHhlekNnElHNpFenir9GEeBpnZIFu')

GO
/****** For SSO feature, by Cheng,Chris. ******/
/****** Object:  Table [dbo].[PN_UserInfo]    Script Date: 10/17/2013 15:12:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PN_UserInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SonySelectID] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_PN_UserInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'SonySelect�ڲ�ΨһID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserInfo', @level2type=N'COLUMN',@level2name=N'SonySelectID'
GO
/****** Object:  Table [dbo].[PN_UserLoginInfo]    Script Date: 10/17/2013 15:12:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PN_UserLoginInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[LoginType] [int] NOT NULL,
	[AccessToken] [nvarchar](100) NULL,
	[RefreshToken] [nvarchar](100) NULL,
	[Expires] [datetime] NULL,
	[LoginTime] [datetime] NULL,
	[DeviceID] [nvarchar](100) NULL,
	[LoginIP] [nvarchar](100) NULL,
 CONSTRAINT [PK_PN_UserLoginInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PN_UserBindInfo]    Script Date: 10/17/2013 15:12:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PN_UserBindInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Uid] [int] NOT NULL,
	[OAuthPlatformID] [int] NOT NULL,
	[ThirdUserId] [nvarchar](50) NOT NULL,
	[NickName] [nvarchar](100) NULL,
	[Icon] [nvarchar](300) NULL,
 CONSTRAINT [PK_PN_UserBindInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ڲ��û���ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserBindInfo', @level2type=N'COLUMN',@level2name=N'Uid'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������¼ƽ̨��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserBindInfo', @level2type=N'COLUMN',@level2name=N'OAuthPlatformID'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���������˺�ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserBindInfo', @level2type=N'COLUMN',@level2name=N'ThirdUserId'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������˺ŵ��ǳ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserBindInfo', @level2type=N'COLUMN',@level2name=N'NickName'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������˺ŵ�ͷ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserBindInfo', @level2type=N'COLUMN',@level2name=N'Icon'
GO
/****** Object:  ForeignKey [FK_PN_UserBindInfo_PN_UserInfo]    Script Date: 10/17/2013 15:12:49 ******/
ALTER TABLE [dbo].[PN_UserBindInfo]  WITH CHECK ADD  CONSTRAINT [FK_PN_UserBindInfo_PN_UserInfo] FOREIGN KEY([Uid])
REFERENCES [dbo].[PN_UserInfo] ([ID])
GO
ALTER TABLE [dbo].[PN_UserBindInfo] CHECK CONSTRAINT [FK_PN_UserBindInfo_PN_UserInfo]
GO

/**Start For PlayNow5.6 Backup&Restore Feature DB desion by Wei,Devin**/
/****** Object:  Table [dbo].[PN_BaiduDownloadList]    Script Date: 10/21/2013 10:15:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PN_BaiduDownloadList](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AppID] [nvarchar](50) NULL,
	[Name] [nvarchar](50) NULL,
	[PackageName] [nvarchar](100) NULL,
	[Size] [decimal](10, 2) NULL,
	[Grade] [decimal](5, 2) NULL,
	[SmallIcon] [nvarchar](300) NULL,
	[IsFree] [bit] NULL,
	[Price] [decimal](5, 2) NULL,
	[VersionCode] [int] NULL,
	[VersionName] [nvarchar](20) NULL,
	[Publisher] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[UpdateTime] [datetime] NULL,
	[CreateTime] [datetime] NOT NULL DEFAULT GETDATE(),
	 CONSTRAINT [PK_PN_BaiduDownloadList] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����,����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ӧ��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'AppID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ӧ������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'Name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ӧ�ð���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'PackageName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��С' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'Size'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'Grade'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Сͼ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'SmallIcon'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ����
   1�����
   0���շ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'IsFree'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�۸�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'Price'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�汾��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'VersionCode'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�汾����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'VersionName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��Ӧ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'Publisher'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'Description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'UpdateTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��¼����ʱ��,���ݿ��Զ�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_BaiduDownloadList', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

/****** Object:  Table [dbo].[PN_UserDownloadList]    Script Date: 10/21/2013 15:15:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PN_UserDownloadList](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Uid] [int] NULL,
	[PackageName] [nvarchar](100) NULL,
	[CreateTime] [datetime] NOT NULL DEFAULT GETDATE(),
	 CONSTRAINT [PK_PN_UserDownloadList] PRIMARY KEY NONCLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����,����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserDownloadList', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�û�ID,PN_UserInfo��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserDownloadList', @level2type=N'COLUMN',@level2name=N'Uid'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ӧ�ð���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserDownloadList', @level2type=N'COLUMN',@level2name=N'PackageName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��¼����ʱ��,���ݿ��Զ�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_UserDownloadList', @level2type=N'COLUMN',@level2name=N'CreateTime'
GO

ALTER TABLE [dbo].[PN_UserDownloadList]  WITH CHECK ADD  CONSTRAINT [FK_PN_UserDownloadList_PN_UserInfo] FOREIGN KEY([Uid])
REFERENCES [dbo].[PN_UserInfo] ([ID])
GO

ALTER TABLE [dbo].[PN_UserDownloadList] CHECK CONSTRAINT [FK_PN_UserDownloadList_PN_UserInfo]
GO

CREATE CLUSTERED INDEX	IDX_PN_UserDownloadList_Uid ON [dbo].[PN_UserDownloadList](Uid)
GO

/****** Create Index(PackageName_index)  on PN_AppInfo   Script Date: 10/30/2013 09:52:39 ******/
CREATE INDEX PackageName_index ON PN_AppInfo(PackageName)
GO
/**End   For PlayNow5.6 Backup&Restore Feature DB desion by Wei,Devin**/

/**Start   For PlayNow5.6 AD Feature DB desion by Wei,Devin**/

ALTER TABLE [dbo].[PN_AdInfo] add [Description] [nvarchar](500) NULL;
ALTER TABLE [dbo].[PN_AdInfo] add [ExpiryDate] [datetime] NULL;
 
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AdInfo', @level2type=N'COLUMN',@level2name=N'Description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ֹ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_AdInfo', @level2type=N'COLUMN',@level2name=N'ExpiryDate'
GO

/**End   For PlayNow5.6 AD Feature DB desion by Wei,Devin**/

/**Start   For PlayNow5.6 Widget Feature DB desion by Wei,Devin**/
CREATE TABLE [dbo].[PN_Widget](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ContentId] [int] NULL,
	[ContentType] [int] NULL,
	[UpdateTime] [datetime] NULL,
 CONSTRAINT [PK_PN_Widget] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����,����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Widget', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ݶ�Ӧ��Ӧ�û���ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Widget', @level2type=N'COLUMN',@level2name=N'ContentId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'1,Ӧ��;2,���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Widget', @level2type=N'COLUMN',@level2name=N'ContentType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PN_Widget', @level2type=N'COLUMN',@level2name=N'UpdateTime'
GO

/**End    For  PlayNow5.6 Widget Feature DB desion by Wei,Devin**/

/****** Start For Update SSO, by Zhang Bo ******/
/****** Add the OAuth platform management module   Script Date: 11/05/2013 16:44:51 ******/
INSERT INTO [dbo].[PN_Module]
           ([MenuId]
           ,[ModuleName]
           ,[ModulePath])
     VALUES
           (6
           ,'��¼��ʽ����'
           ,'Account/OAuthPlatformManagement.aspx')
GO
/******End For Update SSO, by Zhang Bo ******/
/****** Add the User Info management module   Script Date: 11/05/2013 16:44:51 ******/
INSERT INTO [dbo].[PN_Module]
           ([MenuId]
           ,[ModuleName]
           ,[ModulePath])
     VALUES
           (6
           ,'�û���Ϣ'
           ,'Account/UserInfo.aspx')
GO
/******End For Update SSO, by Zhang Bo ******/
/**Start    For  PlayNow5.6 Widget Feature DB desion by Wei,Devin**/

insert into PN_Module(MenuId,ModuleName,ModulePath) values(1,'Widget���ݹ���','Widget/WidgetInfo.aspx')
GO

/**End  For  PlayNow5.6 Widget Feature DB desion by Wei,Devin**/
/**Start  For  PlayNow5.6 Banner AD Feature DB desion by Wei,Devin**/
update PN_AdInfo set ExpiryDate = '9999-12-31'
GO
/**End    For  PlayNow5.6 Banner AD Feature DB desion by Wei,Devin**/

/****** Start For AdHit statistic, by Zhang Bo ******/
/****** Add the AdHit statistic module   Script Date: 11/05/2013 16:44:51 ******/
INSERT INTO [dbo].[PN_Module]
           ([MenuId]
           ,[ModuleName]
           ,[ModulePath])
     VALUES
           (3
           ,'���ͳ��'
           ,'Statistic/AdHit.aspx')
GO
/******End For AdHit statistic, by Zhang Bo ******/
