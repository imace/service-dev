USE [PlayNow]
go
/****** Start For AdHit Statistic, by Zhang Bo ******/
/****** Remove the AdHit Statistic module   Script Date: 11/05/2013 16:44:51 ******/
DELETE FROM [PN_Module]
      WHERE ModulePath='Statistic/AdHit.aspx'
GO
/******End For AdHit Statistic, by Zhang Bo ******/

/**Start  For  PlayNow5.6 Banner AD Feature DB desion by Wei,Devin**/
update PN_AdInfo set ExpiryDate = NULL
GO
/**End    For  PlayNow5.6 Banner AD Feature DB desion by Wei,Devin**/

/**Start    For  PlayNow5.6 Widget Feature DB desion by Wei,Devin**/
delete from PN_Module where ModulePath = 'Widget/WidgetInfo.aspx'
GO
/**End    For  PlayNow5.6 Widget Feature DB desion by Wei,Devin**/

/****** Start For Update SSO, by Zhang Bo ******/
/****** Delete the OAuth platform management module   Script Date: 11/05/2013 16:44:51 ******/
DELETE FROM [PN_Module]
      WHERE ModulePath='Account/OAuthPlatformManagement.aspx'
GO
/******End For Update SSO, by Zhang Bo ******/
/****** Delete the user info management module   Script Date: 11/05/2013 16:44:51 ******/
DELETE FROM [PN_Module]
      WHERE ModulePath='Account/UserInfo.aspx'
GO
/******End For Update SSO, by Zhang Bo ******/

/**Start For PlayNow5.6 Backup&Restore Feature DB desion by Wei,Devin**/

DROP INDEX PackageName_index ON PN_AppInfo
GO

drop table [dbo].[PN_UserDownloadList]
GO

drop table [dbo].[PN_BaiduDownloadList]
GO

/**End  For PlayNow5.6 Backup&Restore Feature DB desion by Wei,Devin**/

/**Start   For PlayNow5.6 Widget Feature DB desion by Wei,Devin**/

drop table PN_Widget;
GO

/**End   For PlayNow5.6 Widget Feature DB desion by Wei,Devin**/

/**Start   For PlayNow5.6 AD Feature DB desion by Wei,Devin**/

ALTER TABLE [dbo].[PN_AdInfo] drop column [Description];
GO

ALTER TABLE [dbo].[PN_AdInfo] drop column [ExpiryDate];
GO

/**End   For PlayNow5.6 AD Feature DB desion by Wei,Devin**/

/****** For SSO feature, by Cheng,Chris. ******/
ALTER TABLE [dbo].[PN_UserBindInfo] drop constraint [FK_PN_UserBindInfo_PN_UserInfo]
GO
DROP TABLE [dbo].[PN_UserBindInfo]
GO
DROP TABLE [dbo].[PN_UserInfo]
GO
DROP TABLE [dbo].[PN_UserLoginInfo]
GO

/****** For SSO feature, by Cai Tony. ******/
/****** Object:  Table [dbo].[PN_OAuthPlatform]    Script Date: 10/11/2013 14:28:16 ******/
DROP TABLE [dbo].[PN_OAuthPlatform]
Go