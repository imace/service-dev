﻿USE [PlayNowLog]
GO
/**start rollback update procedure on SP_MessageStatistic**/

/****** 对象:  StoredProcedure [dbo].[SP_MessageStatistic]    脚本日期: 05/29/2014 04:37:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	消息统计 分析 其中在做分析插入之前要做一次删除
-- =============================================
ALTER PROCEDURE [dbo].[SP_MessageStatistic]
	-- Add the parameters for the stored procedure here
	@BeginTime Datetime, 
	@EndTime Datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--declare @errorCount int=0 --错误的累加
--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点
--2013/7/4 jiaoxuhuan 在获取数量时添加MachineType过滤条件（例:and A.MachineType=C.MachineType）

declare @errorCount int 
set @errorCount=0 

begin  tran --开始事务


--set @BeginTime=CAST(@BeginTime as date) --开始时间
--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime) --开始时间
set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --结束时间


-- 分析前先删除 某一时间段的数据
delete from  dbo.PN_S_Message where CreateTime>=@BeginTime and  CreateTime<@EndTime

-- 消息统计 分析
	insert into dbo.PN_S_Message(
	 MessageID, MachineType, GetMessage,
	 ReadMessage, DownCount,  
	 DownCompleteCount, InstallCount, CreateTime
	)


		SELECT  MessageId, MachineType, 
				(
				select COUNT(*) from [PN_Log_Message] as A 
				 where C.MessageId=A.MessageId and IsValid=1 and   
				--CAST(A.CreateTime as date)=cast(C.CreateTime as date) ) as GetCount, 
				cast( convert(varchar(10),A.CreateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime) 
				and A.MachineType=C.MachineType
				) as GetCount, 
				(select COUNT(*) from [PN_Log_PageViewInfo] as B 

				where C.MessageId=B.ContentId AND IntentFromId=4 and

				-- CAST(B.DateTime as date)=cast(C.CreateTime as date) ) as PVCount,
				cast( convert(varchar(10),B.DateTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
				and B.MachineType=C.MachineType
				 )as PVCount,
				(
				select COUNT(*) from [PN_Order] as D 

				where C.MessageId=D.ContentId and IntentFromId=4 and

				 --CAST(D.StartTime as date)=cast(C.CreateTime as date) ) as DownCount,
				 cast( convert(varchar(10),D.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
				 and D.MachineType=C.MachineType
				  )as DownCount,
				 (select COUNT(*) from [PN_Order] as G 

				   where C.MessageId=G.ContentId and IntentFromId=4 and

				  -- CAST(G.StartTime as date)=cast(C.CreateTime as date)  
					cast( convert(varchar(10),G.StartTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
					and G.MachineType=C.MachineType
				   and EndTime is not null) as DownCompleteCount
				,
				 (select COUNT(*) from [PN_Order] as H
				   where C.MessageId=H.ContentId and IntentFromId=4 and 
					cast( convert(varchar(10),H.InstallTime,120)as datetime)=cast( convert(varchar(10),C.CreateTime,120)as datetime)
					and H.MachineType=C.MachineType
				   and IsInstalled = 1) as InstallCount
				,cast( convert(varchar(10),CreateTime,120)as datetime) dTime
		FROM [PN_log_Message] as C

		where  CreateTime>=@BeginTime AND CreateTime<@EndTime    
		and MessageId>0 
		AND	IsValid=1 
		--group by CAST(CreateTime as date),MessageId,MachineType	
          group by cast( convert(varchar(10),CreateTime,120)as datetime),MessageId,MachineType	




set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

if(@errorCount>0)

	begin

		rollback --如果有错，就回滚事务

	end

else

	begin

		commit tran --如果没有错，就提交事务

	
	end

END
GO

/**end rollback update procedure on SP_MessageStatistic**/

/**start rollback add index on PN_Log_PageViewInfo**/
if exists(select * from sysindexes where name = 'IX_DATE_TIME_PN_LOG_PAGEVIEWINFO')
DROP INDEX [IX_DATE_TIME_PN_LOG_PAGEVIEWINFO] ON [dbo].[PN_Log_PageViewInfo]
GO
CREATE NONCLUSTERED INDEX [DateTime_Index] ON [dbo].[PN_Log_PageViewInfo] ([DateTime])
GO

if exists(select * from sysindexes where name = 'PageName_Index')
DROP INDEX [PageName_Index] ON [dbo].[PN_Log_PageViewInfo]
GO
CREATE CLUSTERED INDEX [PageName_Index] ON [dbo].[PN_Log_PageViewInfo] ([PageName])

if exists(select * from sysindexes where name = 'Id_Index')
DROP INDEX [Id_Index] ON [dbo].[PN_Log_PageViewInfo]
GO
CREATE NONCLUSTERED INDEX [Id_Index] ON [dbo].[PN_Log_PageViewInfo] ([Id])
/**end rollback add index on PN_Log_PageViewInfo**/

/**start rollback add index on PN_Order**/
if exists(select * from sysindexes where name = 'IX_START_TIME_PN_ORDER')
DROP INDEX [IX_START_TIME_PN_ORDER] ON [dbo].[PN_Order]
GO

if exists(select * from sysindexes where name = 'IX_GUID_PN_ORDER')
DROP INDEX [IX_GUID_PN_ORDER] ON [dbo].[PN_Order]
GO
CREATE CLUSTERED INDEX [PK_PN_ORDER_GUID] ON [dbo].[PN_Order] ([GUID])
GO
/**end rollback add index on PN_Order**/

/**start rollback add index on PN_Log_Message**/
if exists(select * from sysindexes where name = 'IX_CREATETIME_PN_LOG_MESSAGE')
DROP INDEX [IX_CREATETIME_PN_LOG_MESSAGE] ON [dbo].[PN_Log_Message]
GO

if exists(SELECT * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS where CONSTRAINT_NAME = 'PK_PN_LOG_MESSAGE')
ALTER TABLE [dbo].[PN_Log_Message] DROP CONSTRAINT [PK_PN_LOG_MESSAGE]
GO
ALTER TABLE [dbo].[PN_Log_Message] ADD  CONSTRAINT [PK_PN_LOG_MESSAGE] PRIMARY KEY CLUSTERED ([Id])
GO
/**end rollback add index on  PN_Log_Message**/

/****** Object:  StoredProcedure [dbo].[SP_DownSourceStatistic]    Script Date: 09/15/2014 16:41:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
	-- =============================================
	-- Author:  <Author,,Name>
	-- Create date: <Create Date,,>
	-- Description: 下载来源 分析 包括PlayNow, 百度，其中在做分析插入之前要做一次删除
	-- =============================================
	ALTER PROCEDURE [dbo].[SP_DownSourceStatistic]
	 -- Add the parameters for the stored procedure here
	 @BeginTime Datetime, 
	 @EndTime Datetime
	AS
	BEGIN
	 -- SET NOCOUNT ON added to prevent extra result sets from
	 -- interfering with SELECT statements.
	 SET NOCOUNT ON;

	-- declare @errorCount int=0 --错误的累加
	--2013/4/18 Rui 为了保证向下兼容 sqlserver 2005, 修改此文件 想查看其中变化, 使用文件比较工具与2008脚本进行对比
	-- 变化包括, 变量的定义, 日期的转换 日期类型变为datetime, 并全部转换为零点

	declare @errorCount int 
	set @errorCount=0 

	begin  tran --开始事务

	--set @BeginTime=CAST(@BeginTime as date) --开始时间
	--set @EndTime= DATEADD(DD,1, CAST(@EndTime as date)) --结束时间
	set @BeginTime= cast( convert(varchar(10),@BeginTime,120)as datetime)-- CAST(@BeginTime as date) --开始时间
	set @EndTime= cast( convert(varchar(10),DATEADD(DD,1, CAST(@EndTime as datetime)),120)as datetime) --DATEADD(DD,1, CAST(@EndTime as date)) --结束时间


	-- 分析前先删除 某一时间段的数据
	delete from  PN_S_DownSource where CreateTime>=@BeginTime and  CreateTime<@EndTime

	-- PlayNow 下载来源 分析
	insert into PN_S_DownSource(
	  AppName, Publisher, Price, AppId,Home, AppDetail, AppRelate,
	  SearchResult, Recommend, RankApp, RankGame, ZoneDetail,
	  CategoryDetail, WapDown,NewApp,NewGame,UpdateApp, MyApps,
	  WidgetApp, WidgetGame, WidgetAppList, WidgetGameList, DownCount, DownCompleteCount,
	  ContentSource, MachineType, CreateTime
	)

	SELECT  pa.Name 应用名称,
	  pa.Publisher AS 供应商, 
	  pa.Price AS 单价,
	  AppId, 
	  sum(CASE pageName WHEN '首页'     THEN 1 else 0 end) 首页, 
	  sum(CASE pageName WHEN '应用详情'     THEN 1 else 0 end) 应用详情, 
	  sum(CASE pageName WHEN '应用相关'     THEN 1 else 0 end) 应用相关, 
	  sum(CASE pageName WHEN '搜索结果'     THEN 1 else 0 end) 搜索结果, 
	  sum(CASE pageName WHEN '推荐'     THEN 1 else 0 end) 推荐, 
	  sum(CASE pageName WHEN '排行应用'     THEN 1 else 0 end) 排行应用, 
	  sum(CASE pageName WHEN '排行游戏'     THEN 1 else 0 end) 排行游戏, 
	  sum(CASE pageName WHEN '专区详情'     THEN 1 else 0 end) 专区详情, 
	  sum(CASE pageName WHEN '分类详情'     THEN 1 else 0 end) 分类详情, 
	  sum(CASE pageName WHEN 'Wap下载'     THEN 1 else 0 end) Wap下载,
	  
	  sum(CASE pageName WHEN '新品应用'     THEN 1 else 0 end) 新品应用, 
	  sum(CASE pageName WHEN '新品游戏'     THEN 1 else 0 end) 新品游戏,
	  sum(case pageName WHEN '应用升级'     THEN 1 else 0 end) 应用升级, 
	  sum(case pageName WHEN '我的应用'     THEN 1 else 0 end) 我的应用, 
	  sum(case pageName WHEN 'Widget应用'   THEN 1 else 0 end) Widget应用,
	  sum(case pageName WHEN 'Widget游戏'   THEN 1 else 0 end) Widget游戏,
	  sum(case pageName WHEN 'Widget应用列表'   THEN 1 else 0 end) Widget应用列表,
	  sum(case pageName WHEN 'Widget游戏列表'   THEN 1 else 0 end) Widget游戏列表,
	  
	  COUNT(StartTime) as 下载数,
	  sum(CASE  WHEN EndTime is not null   THEN 1 else 0 end) 成功下载数,
	  'PlayNow',
	  MachineType,
	 -- cast(StartTime as date) CreateTime
		cast( convert(varchar(10),StartTime,120)as datetime) CreateTime
	from dbo.PN_Order,[PlayNow].[dbo].[PN_AppInfo] pa

	WHERE  (IntentFromId !=3 or IntentFromId is null )   

	AND StartTime>= @BeginTime  AND StartTime < @EndTime
	AND (ClientVer !='web' or ClientVer is null)
	AND AppId = pa.Id
	AND IsInstalled is null
	--and  PageName in('首页','应用详情','应用相关','搜索结果','推荐','排行应用','排行游戏',
	--'专区详情','分类详情','Wap下载')

	-- Group by  cast(StartTime as date), MachineType,AppName,Publisher,Price
	 Group by  cast( convert(varchar(10),StartTime,120)as datetime), MachineType,AppId,pa.Name,pa.Publisher,pa.Price

	--playnow 成功安装次数 统计 start

	 create table #T_PN_Order_AllInstallCount(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllInstallCount] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL,
	)

	insert into #T_PN_Order_AllInstallCount(MachineType,CreateTime,AllInstallCount,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),InstallTime,120)as datetime) CreateTime
		  ,count(InstallTime) AllInstallCount
		  ,'PlayNow'
		  ,AppId
	  FROM [PN_Order] where IsInstalled =1 and (InstallTime >= @BeginTime and InstallTime < @EndTime)
	and (IntentFromId !=3 or IntentFromId is null ) 
	and (ClientVer !='web' or ClientVer is null)
	Group by  cast( convert(varchar(10),InstallTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllInstallCount = tpoa.AllInstallCount
	from #T_PN_Order_AllInstallCount tpoa, PN_S_DownSource
	where tpoa.CreateTime = PN_S_DownSource.CreateTime and tpoa.MachineType = PN_S_DownSource.MachineType 
	and tpoa.AppId = PN_S_DownSource.AppId and tpoa.ContentSource = PN_S_DownSource.ContentSource

	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllInstallCount,ContentSource,AppId,Price)
	select pa.Name,poa.MachineType,pa.Publisher,poa.CreateTime,poa.AllInstallCount,poa.ContentSource,poa.AppId,pa.Price
	from #T_PN_Order_AllInstallCount poa,[PlayNow].[dbo].[PN_AppInfo] pa
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poa.CreateTime = psd.CreateTime and poa.MachineType = psd.MachineType 
	and poa.AppId = psd.AppId and poa.ContentSource = psd.ContentSource )
	and  poa.AppId = pa.Id

	drop table #T_PN_Order_AllInstallCount

	--playnow 成功安装次数 统计 end

	--playnow 应用详情PV 统计 start
	create table #T_PN_Order_AllAppDetailPV(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllAppDetailPV] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL,
	)

	insert into #T_PN_Order_AllAppDetailPV(MachineType,CreateTime,AllAppDetailPV,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),DateTime,120)as datetime) CreateTime
		  ,count(DateTime) AllAppDetailPV
		  ,'PlayNow'
		  ,AppId
	  FROM [PN_Log_PageViewInfo] 
	where (DateTime >= @BeginTime and DateTime < @EndTime)
	and (IntentFromId!='1' and IntentFromId !=3 or IntentFromId is null)  
	and (ContentName is not null and ContentName !='')
	Group by  cast( convert(varchar(10),DateTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllAppDetailPV = tpoa.AllAppDetailPV
	from #T_PN_Order_AllAppDetailPV tpoa ,PN_S_DownSource
	where tpoa.CreateTime = PN_S_DownSource.CreateTime and tpoa.MachineType = PN_S_DownSource.MachineType 
	and tpoa.AppId = PN_S_DownSource.AppId and tpoa.ContentSource = PN_S_DownSource.ContentSource

	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllAppDetailPV,ContentSource,AppId,Price)
	select pa.Name,poa.MachineType,pa.Publisher,poa.CreateTime,poa.AllAppDetailPV,poa.ContentSource,poa.AppId,pa.Price
	from #T_PN_Order_AllAppDetailPV poa,[PlayNow].[dbo].[PN_AppInfo] pa
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poa.CreateTime = psd.CreateTime and poa.MachineType = psd.MachineType 
	and poa.AppId = psd.AppId and poa.ContentSource = psd.ContentSource )
	and  poa.AppId = pa.Id

	drop table #T_PN_Order_AllAppDetailPV

	--playnow 应用详情PV 统计 end

	set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

	--百度下载来源 分析

	insert into PN_S_DownSource(
	  Home, AppRelate,
	  Recommend, RankApp, RankGame, ZoneDetail,
	  CategoryDetail, WapDown, NewApp,NewGame,
	 AppName, Publisher, Price,AppId,AppDetail, SearchResult,DownCount,DownCompleteCount,
	 ContentSource,MachineType, CreateTime
	)
	SELECT 
	0,0,0,0,0,0,0,0,0,0,
	  pb.Name,pb.Publisher,pb.Price,pb.AppId,
	  SUM(CASE WHEN pageName='应用详情' THEN 1 ELSE 0 END) 应用详情, 
	  sum(CASE pageName WHEN '搜索结果'     THEN 1 else 0 end) 搜索结果,

	  COUNT(StartTime) as 下载数,
	  sum(CASE  WHEN EndTime is not null   THEN 1 else 0 end) 成功下载数,

	  '百度', 
	  MachineType,
	 -- cast(StartTime as date )
	cast( convert(varchar(10),StartTime,120)as datetime)
	from dbo.PN_Order ,[PlayNow].[dbo].[PN_BaiduDownloadList] pb
	where IntentFromId =3  and  StartTime>=@BeginTime and  StartTime<@EndTime
	and  PageName in('应用详情','搜索结果')
	and (ClientVer !='web' or ClientVer is null)
	and PN_Order.AppId = pb.AppId
	AND IsInstalled is null
	-- Group by cast(StartTime as date), MachineType,AppName,Publisher,Price
	Group by cast( convert(varchar(10),StartTime,120)as datetime), MachineType,pb.AppId,pb.Name,pb.Publisher,pb.Price

	--baidu 成功安装次数 统计 start

	create table #T_PN_Order_AllInstallCount_BD(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllInstallCount] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL
	)

	insert into #T_PN_Order_AllInstallCount_BD(MachineType,CreateTime,AllInstallCount,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),InstallTime,120)as datetime) CreateTime
		  ,count(InstallTime) AllInstallCount
		  ,'百度' 
		  ,AppId
	  FROM [PN_Order] where IsInstalled =1 and (InstallTime >= @BeginTime and InstallTime < @EndTime)
	and IntentFromId =3 
	and  PageName in('应用详情','搜索结果')
	and (ClientVer !='web' or ClientVer is null)
	Group by  cast( convert(varchar(10),InstallTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllInstallCount = tpoabd.AllInstallCount
	from #T_PN_Order_AllInstallCount_BD tpoabd 
	where tpoabd.CreateTime = PN_S_DownSource.CreateTime 
	and tpoabd.MachineType = PN_S_DownSource.MachineType 
	and tpoabd.AppId = PN_S_DownSource.AppId
	and tpoabd.ContentSource = PN_S_DownSource.ContentSource


	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllInstallCount,ContentSource,AppId,Price)
	select pb.Name,poabd.MachineType,pb.Publisher,poabd.CreateTime,poabd.AllInstallCount,poabd.ContentSource,poabd.AppId,pb.Price
	from #T_PN_Order_AllInstallCount_BD poabd,[PlayNow].[dbo].[PN_BaiduDownloadList] pb
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poabd.CreateTime = psd.CreateTime 
	and poabd.MachineType = psd.MachineType 
	and poabd.AppId = psd.AppId 
	and poabd.ContentSource = psd.ContentSource 
	)

	--baidu 成功安装次数 统计 end

	--baidu 应用详情PV 统计 start

		create table #T_PN_Order_AllAppDetailPV_BD(
		[MachineType] [nvarchar](50) NULL,
		[CreateTime] [datetime] NULL,
		[AllAppDetailPV] [int] NULL,
		[ContentSource] [nvarchar](20) NULL,
		[AppId] [nvarchar](20) NULL
	)

	insert into #T_PN_Order_AllAppDetailPV_BD(MachineType,CreateTime,AllAppDetailPV,ContentSource,AppId)
	SELECT [MachineType]
		  ,cast( convert(varchar(10),DateTime,120)as datetime) CreateTime
		  ,count(DateTime) AllAppDetailPV
		  ,'百度'
		  ,AppId
	  FROM [PN_Log_PageViewInfo] 
	where (DateTime >= @BeginTime and DateTime < @EndTime)
	and IntentFromId =3
	and PageName in('应用详情','搜索结果') 
	and (ContentName is not null and ContentName !='')
	Group by  cast( convert(varchar(10),DateTime,120)as datetime), MachineType,AppId

	update PN_S_DownSource set PN_S_DownSource.AllAppDetailPV = tpoadb.AllAppDetailPV
	from #T_PN_Order_AllAppDetailPV_BD tpoadb 
	where tpoadb.CreateTime = PN_S_DownSource.CreateTime and tpoadb.MachineType = PN_S_DownSource.MachineType 
	and tpoadb.AppId = PN_S_DownSource.AppId and tpoadb.ContentSource = PN_S_DownSource.ContentSource

	insert into PN_S_DownSource(AppName,MachineType,Publisher,CreateTime,AllAppDetailPV,ContentSource,AppId,Price)
	select pb.Name,poadb.MachineType,pb.Publisher,poadb.CreateTime,poadb.AllAppDetailPV,poadb.ContentSource,poadb.AppId,pb.Price
	from #T_PN_Order_AllAppDetailPV_BD poadb,[PlayNow].[dbo].[PN_BaiduDownloadList] pb
	where not exists 
	(select NULL from PN_S_DownSource psd
	where poadb.CreateTime = psd.CreateTime and poadb.MachineType = psd.MachineType 
	and poadb.AppId = psd.AppId and poadb.ContentSource = psd.ContentSource ) 
	and poadb.AppId = pb.AppID
	--baidu 应用详情PV 统计 end

	set @errorCount=@errorCount+@@ERROR --查看是否有错误,做累加

	if(@errorCount>0)

	 begin

	  rollback --如果有错，就回滚事务

	 end

	else

	 begin

	  commit tran --如果没有错，就提交事务

	 
	 end

	END
GO

if(exists(select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'V_PN_AppInfo'))
begin
DROP VIEW [dbo].[V_PN_AppInfo]
end
