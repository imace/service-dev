﻿/// <reference path="jquery-1.7.2.min.js" />

//自定义下拉多选、单选列表隐现
function ShowList(id) {
    $("#" + id).show();
}
function HideList(id) {
    $("#" + id).hide();
}

//全选-被选list的id字符串包含全选CheckBox的id
function CheckAll(obj) {
    var idstr = $(obj).attr("id");
    $("input[type='checkbox']").each(function () {
        if ($(obj).attr("checked")) {
            if ($(this).attr("id").indexOf(idstr) >= 0) {
                $(this).attr("checked", true);
            }
        }
        else {
            if ($(this).attr("id").indexOf(idstr) >= 0) {
                $(this).attr("checked", false);
            }
        }
    });
}

//机型选择后赋值
function CheckedVal(chkid,txtid) {
    var types = "";
    $("#" + chkid + " input[type='checkbox']").each(function () {
        if ($(this).attr("checked")) {
            types += $(this).val() + ";";
        }
    });
    types = types.substring(0, types.length - 1);
    $("#" + txtid).val(types);
}

//机型选择后赋值
function CheckedValNew(chkid, txtid, valueid) {
    var types = "";
    var ids = "";
    $("#" + chkid + " input[type='checkbox']").each(function () {
        if ($(this).attr("checked")) {
            ids += $(this).val() + ";";
            var checkboxid = $(this).attr('id');
            types += $("#" + chkid + " label[for=" + checkboxid + "]").html()+";";
        }
    });
    types = types.substring(0, types.length - 1);
    ids = ids.substring(0, ids.length - 1);
    $("#" + txtid).val(types);//机型
    $("#" + valueid).val(ids);//机型ID
}

//CP选择后赋值
function RadioShow(chkid, txtid) {
    selectval = "";
    $("#" + chkid + " input[type='radio']").each(function () {
        if ($(this).attr("checked")) {
            selectval = $(this).val();
        }
    });
    $("#" + txtid).val(selectval);
}

//开启新窗口
function OpenWindowS(URL, Width, Height) {
    window.open(URL, '', 'width=' + Width + ',height=' + Height + ',resizable=1,scrollbars=1,status=no,toolbar=no,location=no,menu=no,left=60,top=60');
}

//提示不为空
function IsNoVal(checkid, alertid) {
    checkobj = $("#" + checkid);
    alertobj = $("#" + alertid);

    if (checkobj == null || checkobj.val() == "") {
        checkobj.focus();
        alertobj.html("内容不能为空！");
        return true;
    }
    return false;
}


//--通用判断方法-----------------------------------------------------------------------------------------------------

//判断对象是否为空或空格
function IsEmpty(obj) {
    if (obj == null || obj == "" || obj.replace(/(^\s*)|(\s*$)/g, "") == "") {
        return true;
    }
    else
        return false;
}
//判断对象是否不为空或空格
function IsNotEmpty(obj) {
    if (obj != null && obj != "" && obj.replace(/(^\s*)|(\s*$)/g, "") != "") {
        return true;
    }
    return false;
}

//判断小数 
function IsFloat(s) {
    if (!/^[+\-]?\d+(.\d+)?$/.test(s))
        return false;
    else
        return true;
}
//判断正小数
function IsPlusFloat(s) {
    if (!/^[+]?\d+(.\d+)?$/.test(s))
        return false;
    else
        return true;
}
//判断正整数
function IsPlusInt(s) {
    if (!/^\d*$/.test(s))
        return false;
    else
        return true;
}
//判断是否为字母和数字
function CheckName(s) {
    if (!/^[A-Za-z0-9._-]+$/.test(s))
        return false;
    else
        return true;
}
//检测Email格式
function IsEmail(s) {
    var pattern = /^([a-zA-Z0-9._-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
    flag = pattern.test(s);
    if (!flag) {
        return false;
    }
    return (true);
}
//比较两个数是否相同
function CompValue(s1, s2) {
    if (s1 != s2) {
        return false;
    }
    else
        return true;
}

//验证日期的合法性-对象值
function IsDateLegal(obj) {
    var reg = /^((((1[6-9]|[2-9]\d)\d{2})-(0?[13578]|1[02])-(0?[1-9]|[12]\d|3[01]))|(((1[6-9]|[2-9]\d)\d{2})-(0?[13456789]|1[012])-(0?[1-9]|[12]\d|30))|(((1[6-9]|[2-9]\d)\d{2})-0?2-(0?[1-9]|1\d|2[0-8]))|(((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29-))$/;
    if (!reg.test(obj)) {
        return false;
    }
    return true;
}