﻿/// <reference path="../jquery-1.6-vsdoc.js" />

$(window).ready(function () {
    //初始进度条
    $('#LogProgressBar').progressBar(0);
});

//不能为空
function CheckNull(id) {
    if (IsEmpty($("#" + id).val())) {
        $("#" + id).focus();
        $("#lblAlert").html("文件夹名称不能为空");
        $("#txtFolderName").attr("class", "alertbg");
        return false;
    }
    return true;
}
//Excel文件选择
function OnlyCheck() {
    if (IsEmpty($("#radlFiles input[type='radio']:checked").val())) {
        $("#lblAlert1").html(" * 请选择要上传的Excel");
        return false;
    }
    else {
        $("#lblAlert1").html("");
    }
    return true;
}

//校验提示输出-异步所有结果请求
function CheckMessage() {
    //请求标识
    var source = "checkmsg";
    //初始
    $('#LogProgressBar').progressBar(0);
    $("#ShowLog").html("<img src='../Images/loading.gif' />Loading......");
    BtnEnable(false);
    //逐数据行结果输出延时
    var showdelay = 10;

    //异步请求提示
    $.post("MusicBatchUpLoad.aspx",
        { from: source, folder: $("#txtFolderName").val(), checked: $("#radlFiles input[type='radio']:checked").val() },
        function (callback) {
            var strarr = new Array();
            //数据行提示分隔标识"|"
            strarr = callback.split('|');
            $("#ShowLog").html("");
            //初始请求序号及总数据行
            $("#txthiClient").val(0);
            $("#txthiServer").val(0);
            $("#txthiRowsum").val(strarr.length - 1);

            //延时迭代-遍历并输出行提示
            var row = 0;
            chkinterval = setInterval(function () {
                if (row < strarr.length) {
                    //追加输出//IE9下jq1.5 .append bug
                    $("#ShowLog").append(strarr[row]);
                    //百分比
                    percent = (100.00 * row) / (strarr.length - 1);
                    //百分比显示
                    $('#LogProgressBar').progressBar(percent);
                    //滚动条延时置底
                    $("#ShowLog").animate({ scrollTop: 999999 }, showdelay);
                    //提示汇总
                    MessageSum();
                    //按钮状态
                    BtnState(strarr.length, row);
                }
                //中止线程
                else {
                    clearInterval(chkinterval);
                }
                row++;
            }, showdelay);
        },
        "html"
        );
    }

//设置按钮状态
function BtnState(arrlength, rowindex) {
    if (rowindex == arrlength - 1) {
        var errsum = parseInt($("#ErrSum").html());
        if (errsum == 0) {
            BtnEnable(true);
        }
    }
}
//按键是否可用
function BtnEnable(bln) {
    if (bln) {
        $("#btnPreView").removeAttr("disabled");
        $("#btnPreView").removeAttr("title");
        $("#btnSaveDb").removeAttr("disabled");
        $("#btnSaveDb").removeAttr("title");
    }
    else {
        $("#btnPreView").attr("disabled", true);
        $("#btnPreView").attr("title", "不可用");
        $("#btnSaveDb").attr("disabled", true);
        $("#btnSaveDb").attr("title", "不可用");
    }
}

//保存数据提示输出-异步队列结果请求
function ProcessMessage(cindex) {
    //逐数据行异步请求延时
    var showdelay = 10;
    //最大可处理序号
    var maxindex = $("#txthiRowsum").val();
    //初始
    $('#LogProgressBar').progressBar(0);

    //延时轮询线程-进阶请求
    var prointerval = setInterval(function () {
        //上次请求结束后server可进行的下一次请求
        var sindex = parseInt($("#txthiServer").val());
        //百分比
        var percent = (100.00 * sindex) / maxindex;
        $('#LogProgressBar').progressBar(percent);
        //可做server请求的条件
        if (cindex < maxindex && cindex == sindex) {
            //请求执行当前序号
            GetSaveLog(cindex);
            //下一client请求序号-造成client与server的差异用于向server下次请求的触发
            cindex++;
            $("#txthiClient").val(cindex);
            //滚动条延时置底
            $("#ShowLog").animate({ scrollTop: 999999 }, showdelay);
        }
        if (sindex <= maxindex) {
            //提示汇总
            MessageSum();
            //按钮状态
            $("#btnSaveDb").attr("disabled", true);
            $("#btnSaveDb").attr("title", "不可用");
        }
        //中止线程
        if (cindex == sindex && cindex == maxindex && cindex != 0) {
            clearInterval(prointerval);
            $("#ShowLog").animate({ scrollTop: 999999 }, showdelay);
        }
    }, showdelay);
}
//单条数据保存结果提示输出
function GetSaveLog(index) {
    $("#ShowLog").append("<div id='loading'>Saving......</div>");
    //请求保存数据库-请求服务端当前序号
    var jqxhr = $.post("MusicBatchUpLoad.aspx", { from: "dbmsg", folder: $("#txtFolderName").val(), rowindex: index },
            function (callback) {
                $("#loading").remove();
                //返回提示信息
                $("#ShowLog").append(callback);
            }, "html")
            .complete(function (XHR, TS) {
                //异步请求完成后请求序号加1
                $("#txthiServer").val(parseInt(index + 1));
                //对象回收
                XHR = null;
            });
}

//提示分类汇总
function MessageSum() {
    $("#PassSum").html(0); $("#WarnSum").html(0); $("#ErrSum").html(0);
    $("#PassSum").html($(".Pass").length);
    $("#WarnSum").html($(".Warning").length);
    $("#ErrSum").html($(".Error").length);
}

//弹窗预览
function Open() {
    OpenWindowS("MusicPreview.aspx", 800, 680);
}